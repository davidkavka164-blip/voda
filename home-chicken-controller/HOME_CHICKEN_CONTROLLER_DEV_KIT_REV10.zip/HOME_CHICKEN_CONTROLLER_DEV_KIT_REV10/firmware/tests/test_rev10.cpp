#include <cassert>
#include <iostream>
#include <cstdint>
#include <limits>
#include "../HCC_CONTROLLER_REV10/door_safety.hpp"
#include "../HCC_CONTROLLER_REV10/policy.hpp"
using namespace hcc;
using namespace hcc7;
int main(){
  long n=0;
  DoorController d(12000,80,1800);
  DoorInput x{};x.raw_closed=true;x.power_ok=true;x.movement_authorized=true;
  for(int t=0;t<300;t+=25){x.now_ms=t;d.tick(x);++n;}
  assert(d.result().state==DoorState::CLOSED);++n;
  x.command=DoorCommand::OPEN;x.now_ms=325;
  auto r=d.tick(x); assert(r.motor_open && !r.motor_close);++n;
  x.command=DoorCommand::NONE;
  // Simulated NC edge trip: motor must be off immediately and fault retained.
  x.now_ms=350;x.obstruction=true;x.movement_authorized=false;r=d.tick(x);
  assert(r.state==DoorState::FAULT && r.fault==DoorFault::OBSTRUCTION && !r.motor_open && !r.motor_close);++n;
  x.obstruction=false;x.movement_authorized=true;x.acknowledge_fault=true;x.now_ms=375;
  r=d.tick(x);assert(r.state==DoorState::CLOSED && !r.motor_open);++n;
  // Battery disconnect during movement => latched failure
  x.acknowledge_fault=false;x.command=DoorCommand::OPEN;x.now_ms=400;r=d.tick(x);
  assert(r.motor_open);++n;
  x.command=DoorCommand::NONE;x.power_ok=false;x.now_ms=425;r=d.tick(x);
  assert(r.state==DoorState::FAULT && r.fault==DoorFault::POWER_INVALID && !r.motor_open);++n;
  // Conflict NC wiring: cannot recover
  x.power_ok=true;x.raw_open=true;x.now_ms=450;x.acknowledge_fault=true;
  r=d.tick(x);assert(r.state==DoorState::FAULT && !r.motor_open);++n;
  // Driver fault at rest must latch and block the next scheduled movement.
  DoorController idle;
  DoorInput y{};
  y.raw_closed=true;y.movement_authorized=true;
  idle.tick(y);
  y.now_ms=100;
  assert(idle.tick(y).state==DoorState::CLOSED);++n;
  y.now_ms=125;y.driver_fault=true;
  r=idle.tick(y);
  assert(r.fault==DoorFault::DRIVER_FAULT && !r.motor_open);++n;
  y.now_ms=150;y.driver_fault=false;y.command=DoorCommand::OPEN;
  assert(idle.tick(y).state==DoorState::FAULT);++n;
  y.now_ms=175;y.command=DoorCommand::NONE;y.acknowledge_fault=true;
  r=idle.tick(y);
  assert(r.state==DoorState::CLOSED && !r.motor_open);++n;
  y.now_ms=200;y.acknowledge_fault=false;y.command=DoorCommand::OPEN;
  assert(idle.tick(y).motor_open);++n;
  y.now_ms=225;y.raw_closed=false;y.command=DoorCommand::NONE;
  assert(idle.tick(y).motor_open);++n;
  y.now_ms=325;y.raw_open=true;
  r=idle.tick(y);
  assert(r.state==DoorState::OPENING && !r.motor_open && !r.motor_close);++n;
  y.now_ms=425;
  assert(idle.tick(y).state==DoorState::OPEN);++n;
  y.now_ms=450;y.command=DoorCommand::CLOSE;
  assert(idle.tick(y).motor_close);++n;
  y.now_ms=475;y.hard_stop=true;
  r=idle.tick(y);
  assert(r.fault==DoorFault::HARD_STOP && !r.motor_close);++n;

  // Heating outside user window always OFF; thermostat hysteresis uses 2/5C
  EggHeaterPolicy heater;
  HeatInputs z{};z.installed=true;z.armed=true;z.rtc_ok=true;z.sensor_ok=true;
  z.battery_ok=true;z.hard_thermal_ok=true;z.start_min=420;z.end_min=960;z.temp_c=0;
  for(uint16_t m=0;m<1440;++m){
    z.local_min=m;
    bool heating=heater.tick(z);
    assert(heating==(m>=420 && m<960));++n;
  }
  z.local_min=600;z.temp_c=1;assert(heater.tick(z));++n;
  z.temp_c=3;assert(heater.tick(z));++n;
  z.temp_c=5;assert(!heater.tick(z));++n;
  z.temp_c=0;z.sensor_ok=false;assert(!heater.tick(z));++n;
  z.sensor_ok=true;z.battery_ok=false;assert(!heater.tick(z));++n;
  z.battery_ok=true;z.hard_thermal_ok=false;assert(!heater.tick(z));++n;
  z.hard_thermal_ok=true;z.temp_c=1;
  assert(heater.tick(z));++n;
  z.temp_c=std::numeric_limits<float>::quiet_NaN();
  assert(!heater.tick(z));++n;
  assert(batteryCanDrive(HCC_MOTOR_CUTOFF_V) && !batteryCanDrive(HCC_MOTOR_CUTOFF_V-0.01f));++n;
  assert(batteryCanHeat(HCC_HEAT_CUTOFF_V) && !batteryCanHeat(HCC_HEAT_CUTOFF_V-0.01f));++n;
  std::cout<<"REV10 PASS: "<<n<<" deterministic safety+schedule checks\n";
}
