#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
test_binary=$(mktemp)
trap 'rm -f "$test_binary"' EXIT
"${CXX:-g++}" -std=c++11 -O1 -g -Wall -Wextra -pedantic \
  -fsanitize=address,undefined -fno-omit-frame-pointer test_rev10.cpp -o "$test_binary"
"$test_binary"
"${CXX:-g++}" -std=c++11 -O1 -g -Wall -Wextra -pedantic \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  -Irtc_stubs -I../HCC_CONTROLLER_REV10 test_rtc.cpp -o "$test_binary"
"$test_binary"
