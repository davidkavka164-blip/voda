// HCC REV10 | ESP32 core 1.0.6 | commissioning build, LAN/VPN only.
#include <Arduino.h>
#include <string.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <time.h>
#include <sntp.h>
#include <esp_adc_cal.h>
#include "config.h"
#include "secrets.h"
#include "door_safety.hpp"
#include "policy.hpp"
#include "rtc_ds3231.hpp"

static WebServer web(80);
static Preferences prefs;
static OneWire oneWire(PIN_ONEWIRE);
static DallasTemperature temperatures(&oneWire);
static hcc::DoorController door(HCC_MOTOR_TIMEOUT_MS,80,1800);
static hcc7::EggHeaterPolicy heater;
static hcc::DoorOutput lastDoor={hcc::DoorState::UNKNOWN,hcc::DoorFault::NONE,false,false,false};
static hcc::DoorCommand pending=hcc::DoorCommand::NONE;
static bool pendingAck=false, manualHold=false, webConfigured=false;
static bool heaterOutput=false, batteryOk=false, eggTempOk=false, waterTempOk=false;
static bool alarmActive=true, startupGraceElapsed=false;
static bool motorDriverFault=false, thermalLoopOk=false, safetyLoopOk=false;
static bool batteryReadingOk=false, prefsReady=false;
static esp_adc_cal_characteristics_t batteryAdc;
static const bool batteryCalibrated=(HCC_BATTERY_ADC_CALIBRATED!=0);
static float batteryV=0, eggC=0, waterC=0;
static uint32_t lastDoorTime=0,lastTempReq=0,lastBattery=0,lastWifi=0;
static bool tempPending=false, ntpStarted=false, rtcBackupPending=false;
static const char LOCAL_TZ[]="CET-1CEST,M3.5.0/2,M10.5.0/3";
static uint32_t lastRtcBackupAttempt=0;
static uint16_t openMin=HCC_OPEN_TIME_DEFAULT,closeMin=HCC_CLOSE_TIME_DEFAULT;
static uint16_t eggStart=HCC_EGG_START_DEFAULT,eggEnd=HCC_EGG_END_DEFAULT;
static uint32_t manualHoldDay=0;
static uint32_t csrf=0;
static String events[16];
static unsigned eventPtr=0;
static hcc::Debouncer openButtonFilter(60), closeButtonFilter(60);
static bool buttonsReady=false, buttonOpenPrev=false, buttonClosePrev=false;
static bool ackTiming=false, localAckIssued=false;
static uint32_t bothPressedSince=0;
static const uint32_t HOLD_DISABLED=UINT32_MAX;
struct Schedule { uint16_t open, close, heatStart, heatEnd; };
static unsigned char eggRom[8]={0}, waterRom[8]={0};

static void record(const String& s) { events[eventPtr++%16]=String(millis()/1000)+"s "+s; Serial.println(s); }
static bool authenticated(){
  if(web.authenticate(HCC_WEB_USER,HCC_WEB_PASS)) return true;
  web.requestAuthentication();return false;
}
static bool formAuthorized(){return web.hasArg("token") && web.arg("token")==String(csrf,HEX);}
static void moveOutputs(bool open,bool close){
  // Preserve DIR when braking. Changing DIR with PWM still high can reverse the drive.
  if(!HCC_ACTUATORS_ARMED || !batteryOk || open==close){
    ledcWrite(0,0);
    return;
  }
  digitalWrite(PIN_MOTOR_DIR,open?HIGH:LOW);
  ledcWrite(0,HCC_MOTOR_PWM_DUTY);
}
static bool configuredRom(const unsigned char* rom){
  if(rom[0]!=0x28)return false;
  unsigned char r[8]; for(unsigned i=0;i<8;++i)r[i]=rom[i];
  return OneWire::crc8(r,7)==r[7];
}
static void sampleTemperature(){
  if(configuredRom(eggRom)) {
    float t=temperatures.getTempC(eggRom);
    eggTempOk=(t>-45 && t<85 && t!=85 && t!=DEVICE_DISCONNECTED_C);
    if(eggTempOk)eggC=t;
  }else eggTempOk=false;
  if(configuredRom(waterRom)){
    float t=temperatures.getTempC(waterRom);
    waterTempOk=(t>-45&&t<85&&t!=85&&t!=DEVICE_DISCONNECTED_C);
    if(waterTempOk)waterC=t;
  }else waterTempOk=false;
}
static void measureBattery(){
  uint32_t sum=0;
  bool inRange=true;
  for(int i=0;i<32;++i){
    const int raw=analogRead(PIN_BAT_ADC);
    inRange &= raw>0 && raw<4095;
    sum+=raw;
  }
  batteryReadingOk=inRange;
  batteryV=esp_adc_cal_raw_to_voltage(sum/32,&batteryAdc)*0.001f*
    HCC_BATTERY_DIVIDER_RATIO*HCC_BATTERY_ADC_CORRECTION;
  batteryOk=batteryCalibrated && batteryReadingOk && hcc7::voltageValid(batteryV);
}
static void updateHeat(uint16_t minute,bool clockOk){
  hcc7::HeatInputs i={};
  i.installed=(HCC_EGG_HEATER_INSTALLED!=0);
  i.armed=(HCC_ACTUATORS_ARMED!=0);
  i.rtc_ok=clockOk;
  i.sensor_ok=eggTempOk;
  i.battery_ok=batteryOk&&hcc7::batteryCanHeat(batteryV);
  thermalLoopOk=digitalRead(PIN_EGG_THERMAL_NC)==LOW;
  i.hard_thermal_ok=thermalLoopOk;
  i.local_min=minute;i.start_min=eggStart;i.end_min=eggEnd;i.temp_c=eggC;
  heaterOutput=heater.tick(i);
  digitalWrite(PIN_EGG_HEATER,heaterOutput?HIGH:LOW);
}
static const char* yn(bool x){return x?"true":"false";}
static String statusJson(){
  uint16_t mi=0;uint32_t d=0;bool clockOk=hcc7::localClock(mi,d);
  String s="{\"project\":\"HCC\",\"rev\":10,\"armed\":";
  s+=yn(HCC_ACTUATORS_ARMED!=0);s+=",\"motor_web_enabled\":";
  s+=yn(HCC_ALLOW_WEB_MOTOR_COMMANDS!=0);s+=",\"door\":\"";
  s+=hcc::doorStateName(lastDoor.state);s+="\",\"fault\":\"";
  s+=hcc::doorFaultName(lastDoor.fault);s+="\",\"position_verified\":";
  s+=yn(lastDoor.position_valid);s+=",\"manual_hold\":";s+=yn(manualHold);
  s+=",\"clock_valid\":";s+=yn(clockOk);
  s+=",\"local_minute\":";s+=String(mi);
  s+=",\"battery_calibrated\":";s+=yn(batteryCalibrated);
  s+=",\"battery_voltage\":";s+=batteryOk?String(batteryV,2):"null";
  s+=",\"battery_voltage_estimate\":";s+=batteryReadingOk?String(batteryV,2):"null";
  s+=",\"battery_soc\":null"; // voltage is NOT % SOC for LiFePO4.
  s+=",\"egg_temp\":";s+=eggTempOk?String(eggC,1):"null";
  s+=",\"water_temp\":";s+=waterTempOk?String(waterC,1):"null";
  s+=",\"water_available_verified\":false";
  s+=",\"egg_heater_output\":";s+=yn(heaterOutput);
  s+=",\"water_heater_output\":false";
  s+=",\"motor_driver_fault\":";s+=yn(motorDriverFault);
  s+=",\"motor_safety_loop_ok\":";s+=yn(safetyLoopOk);
  s+=",\"estop_ok\":";s+=yn(digitalRead(PIN_ESTOP_NC)==LOW);
  s+=",\"limit_open_active\":";s+=yn(digitalRead(PIN_LIMIT_OPEN)==LOW);
  s+=",\"limit_closed_active\":";s+=yn(digitalRead(PIN_LIMIT_CLOSED)==LOW);
  s+=",\"heater_thermal_loop_ok\":";s+=yn(thermalLoopOk);
  s+=",\"settings_storage_ok\":";s+=yn(prefsReady);
  s+=",\"egg_sensor_paired\":";s+=yn(configuredRom(eggRom));
  s+=",\"water_sensor_paired\":";s+=yn(configuredRom(waterRom));
  s+=",\"alarm_active\":";s+=yn(alarmActive);
  s+=",\"wifi_connected\":";s+=yn(WiFi.status()==WL_CONNECTED);
  s+=",\"wifi_ip\":\"";s+=WiFi.localIP().toString();s+="\"}";
  return s;
}
static String htmlHeader(const char* title){
  String s="<!doctype html><html lang='cs'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
  s+="<title>";s+=title;s+="</title><style>body{font:16px Arial,sans-serif;margin:25px auto;max-width:850px;padding:0 14px;line-height:1.5;color:#173035}table{border-collapse:collapse;width:100%}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:left}button{padding:10px;margin:5px}input{padding:8px;max-width:90px}.warn{padding:12px;background:#fff3dd;border-left:4px solid #bb8d00}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f0f3f3;padding:12px}a{margin-right:12px}</style>";
  return s;
}
static void indexPage(){
  if(!authenticated())return;
  String s=htmlHeader("HOME CHICKEN CONTROLLER");
  s+="<h2>HOME CHICKEN CONTROLLER / REV10</h2>";
  s+="<p class='warn'><b>PŘEDREALIZAČNÍ FIRMWARE.</b> Fyzické výstupy ";
  s+=(HCC_ACTUATORS_ARMED?"AKTIVNI GPIO: pohyb vyzaduje koncovy spinac, NC ochrany a napeti. Pred ostrym provozem nutna mechanicka bezpecnost.":"VYPNUTY.");
  s+=" Vodu ani stav slepic software nepotvrzuje. HTTP jen v lokální síti / VPN.</p>";
  s+="<p id='freshness' role='status'>Stav při otevření stránky</p><pre id='st'>"+statusJson()+"</pre>";
  s+="<h3>Ruční příkazy</h3><form method='POST' action='/action'><input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  if(HCC_ALLOW_WEB_MOTOR_COMMANDS)s+="<button name='do' value='open'>OTEVŘÍT</button><button name='do' value='close'>ZAVŘÍT</button>";
  s+="<button name='do' value='stop'>Pozastavit AUTO</button><button name='do' value='ack'>Potvrdit poruchu</button>";
  s+="<button name='do' value='auto'>Zapnout AUTO</button></form>";
  s+="<p>Web je dostupný v místní síti nebo přes VPN. Změna časů či povolení AUTO může spustit pohyb. "
     "Během jízdy web čeká. K okamžitému zastavení použij fyzický E-STOP.</p>";
  if(!hcc7::systemTimeValid()){
    s+="<form method='POST' action='/clock' onsubmit=\"if(!confirm('Použít čas tohoto zařízení?'))return false;"
       "this.elements.epoch.value=Math.floor(Date.now()/1000)\">";
    s+="<input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
    s+="<input type='hidden' name='epoch'><button>Nastavit hodiny podle telefonu nebo počítače</button></form>";
  }
  s+="<h3>Časy (místní, Europe/Prague)</h3><form method='POST' action='/settings'><input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  s+="Otevření min.: <input name='open' type='number' min='0' max='1439' value='"+String(openMin)+"'> ";
  s+="Zavření min.: <input name='close' type='number' min='0' max='1439' value='"+String(closeMin)+"'> ";
  s+="Topení vajec od: <input name='heatstart' type='number' min='0' max='1439' value='"+String(eggStart)+"'> ";
  s+="do: <input name='heatend' type='number' min='0' max='1439' value='"+String(eggEnd)+"'> ";
  s+="<button>Uložit</button></form><p>Časy = počet minut po půlnoci, např. 450=07:30, 1080=18:00.</p>";
  s+="<p><a href='/status'>JSON /status</a><a href='/sensors'>Adresy čidel</a><a href='/events'>Události</a></p>";
  if(String(HCC_CAMERA_LOCAL_URL).length()>0){s+="<p>Kamera: <a href='"+String(HCC_CAMERA_LOCAL_URL)+"'>Fotografie vajec</a> (pouze přes LAN/VPN)</p>";}
  s+="<script>const freshness=document.getElementById('freshness');let last=new Date();"
     "async function poll(){const c=new AbortController();const timer=setTimeout(()=>c.abort(),2500);"
     "try{const r=await fetch('/status',{cache:'no-store',signal:c.signal});if(!r.ok)throw Error(r.status);"
     "document.getElementById('st').textContent=JSON.stringify(await r.json(),null,2);last=new Date();"
     "freshness.textContent='Aktualizováno '+last.toLocaleTimeString();}catch(e){"
     "freshness.textContent='Stav neaktualizován. Poslední údaj '+last.toLocaleTimeString();}"
     "finally{clearTimeout(timer);setTimeout(poll,3000);}}poll();</script></html>";
  web.sendHeader("Cache-Control","no-store"); web.send(200,"text/html; charset=utf-8",s);
}
static void statusPage(){if(!authenticated())return;web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",statusJson());}
static void sensorsPage(){
  if(!authenticated())return;
  String s=htmlHeader("HCC senzory")+"<h3>Adresy DS18B20</h3><pre>";
  uint8_t addr[8];int n=temperatures.getDeviceCount();
  for(int i=0;i<n;++i) {
    if(!temperatures.getAddress(addr,i))continue;
    s+=String(i)+": {";
    for(int j=0;j<8;++j){if(j)s+=",";s+="0x";if(addr[j]<16)s+="0";s+=String(addr[j],HEX);}
    s+="}\n";
  }
  s+="</pre><p>Pořadí sond se může měnit; přiřazení se ukládá podle unikátní ROM adresy. Umístění před párováním ověř termometrem.</p>";
  s+="<form method='POST' action='/pair'><input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  s+="Role: <select name='role'><option value='egg'>VEJCE</option><option value='water'>VODA</option></select>";
  s+="Index: <input name='index' type='number' min='0' max='9' required>";
  s+="<button>Spárovat čidlo</button></form><a href='/'>Zpět</a>";
  web.send(200,"text/html; charset=utf-8",s);
}
static void onPair(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  const String role=web.arg("role");
  const String ix=web.arg("index");
  if(ix.length()!=1 || ix[0]<'0' || ix[0]>'9'){
    web.send(400,"text/plain","Invalid sensor index");return;
  }
  uint8_t addr[8];
  if(!temperatures.getAddress(addr,ix[0]-'0') || !configuredRom(addr)){
    web.send(400,"text/plain","Sensor not found");return;
  }
  if(role=="egg"){
    if(memcmp(addr,waterRom,8)==0){web.send(409,"text/plain","Already assigned to water");return;}
    if(prefs.putBytes("eggrom",addr,8)!=8){web.send(500,"text/plain","Sensor pairing could not be saved");return;}
    memcpy(eggRom,addr,8);
    eggTempOk=false;
    heater.off();heaterOutput=false;digitalWrite(PIN_EGG_HEATER,LOW);
    record("Egg DS18B20 paired");
  }else if(role=="water"){
    if(memcmp(addr,eggRom,8)==0){web.send(409,"text/plain","Already assigned to egg");return;}
    if(prefs.putBytes("waterrom",addr,8)!=8){web.send(500,"text/plain","Sensor pairing could not be saved");return;}
    memcpy(waterRom,addr,8);
    waterTempOk=false;
    record("Water DS18B20 paired");
  }else {web.send(400,"text/plain","Invalid role");return;}
  web.sendHeader("Location","/sensors");web.send(303,"text/plain","Paired");
}
static void eventsPage(){if(!authenticated())return;String s="";for(int i=0;i<16;++i){const String& x=events[(eventPtr+i)%16];if(x.length())s+=x+"\n";}web.send(200,"text/plain; charset=utf-8",s);}
static bool parseMinute(const String& text,uint16_t& minute){
  if(!text.length() || text.length()>4)return false;
  minute=0;
  for(unsigned i=0;i<text.length();++i){
    if(text[i]<'0' || text[i]>'9')return false;
    minute=minute*10+text[i]-'0';
  }
  return minute<1440;
}
static bool validSchedule(const Schedule& v){
  return v.open<v.close && v.close<1440 && v.heatStart<1440 &&
    v.heatEnd<1440 && v.heatStart!=v.heatEnd;
}
static void applySchedule(const Schedule& v){
  openMin=v.open;closeMin=v.close;eggStart=v.heatStart;eggEnd=v.heatEnd;
}
static void onSettings(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  Schedule next;
  if(!parseMinute(web.arg("open"),next.open) || !parseMinute(web.arg("close"),next.close) ||
     !parseMinute(web.arg("heatstart"),next.heatStart) ||
     !parseMinute(web.arg("heatend"),next.heatEnd) || !validSchedule(next)){
    web.send(400,"text/plain","Invalid timing");
    return;
  }
  if(prefs.putBytes("schedule", &next, sizeof next)!=sizeof next){
    web.send(500,"text/plain","Schedule could not be saved");
    return;
  }
  applySchedule(next);
  record("Scheduling updated");web.sendHeader("Location","/");web.send(303,"text/plain","Saved");
}
static bool setHold(uint32_t day){
  const bool persist=prefsReady && prefs.putUInt("holdState",day)==sizeof day;
  if(persist || day!=HOLD_DISABLED){
    manualHold=(day!=HOLD_DISABLED);
    manualHoldDay=manualHold?day:0;
  }
  if(!persist)record("AUTO mode could not be saved");
  return persist;
}
static void onClock(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  if(hcc7::systemTimeValid()){web.send(409,"text/plain","Clock already set");return;}
  const String text=web.arg("epoch");
  int64_t epoch=0;
  if(text.length()==10){
    for(unsigned i=0;i<text.length();++i){
      if(text[i]<'0' || text[i]>'9'){epoch=0;break;}
      epoch=epoch*10+text[i]-'0';
    }
  }
  if(!hcc7::validClockEpoch(epoch)){web.send(400,"text/plain","Invalid browser time");return;}
  if(!hcc7::writeDS3231Utc(static_cast<time_t>(epoch))){
    web.send(503,"text/plain","DS3231 is unavailable");
    return;
  }
  hcc7::restoreClockFromRtc();
  if(!hcc7::systemTimeValid()){web.send(503,"text/plain","DS3231 clock could not be verified");return;}
  record("Browser time saved to DS3231");
  web.sendHeader("Location","/");web.send(303,"text/plain","Clock saved");
}
static void onAction(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  String cmd=web.arg("do");
  uint16_t min=0;uint32_t key=0;const bool validTime=hcc7::localClock(min,key);
  if(cmd=="stop") {
    pending=hcc::DoorCommand::STOP;
    if(!setHold(0)){web.send(500,"text/plain","AUTO paused in RAM only");return;}
    record("Stop requested; AUTO suspended");
  }
  else if(cmd=="ack"){
    if(lastDoor.state!=hcc::DoorState::FAULT){web.send(409,"text/plain","No door fault");return;}
    setHold(0);
    pendingAck=true;
    record("Fault ack requested; AUTO stays paused");
  }
  else if(cmd=="auto"){
    if(lastDoor.state==hcc::DoorState::FAULT){web.send(409,"text/plain","Acknowledge the fault first");return;}
    if(!setHold(HOLD_DISABLED)){web.send(500,"text/plain","AUTO mode could not be saved");return;}
    record("AUTO enabled");
  }
  else if(cmd=="open"||cmd=="close"){
    if(!HCC_ALLOW_WEB_MOTOR_COMMANDS){web.send(403,"text/plain","Web commands disabled in config.h");return;}
    if(!validTime) {web.send(409,"text/plain","Clock invalid");return;}
    if(!setHold(key)){web.send(500,"text/plain","Manual mode could not be saved");return;}
    pending=(cmd=="open"?hcc::DoorCommand::OPEN:hcc::DoorCommand::CLOSE);
    record("Remote door command");
  }else{web.send(400,"text/plain","Unknown command");return;}
  web.sendHeader("Location","/");web.send(303,"text/plain","Requested");
}
static bool doorMoving(){
  return lastDoor.state==hcc::DoorState::OPENING || lastDoor.state==hcc::DoorState::CLOSING;
}
static void readLocalButtons(uint32_t now,uint32_t day){
  openButtonFilter.update(digitalRead(PIN_LOCAL_OPEN)==LOW,now);
  closeButtonFilter.update(digitalRead(PIN_LOCAL_CLOSE)==LOW,now);
  if(!openButtonFilter.ready() || !closeButtonFilter.ready())return;
  const bool open=openButtonFilter.value(), close=closeButtonFilter.value();
  const bool newOpen=buttonsReady && open && !buttonOpenPrev;
  const bool newClose=buttonsReady && close && !buttonClosePrev;
  buttonsReady=true;
  buttonOpenPrev=open;buttonClosePrev=close;

  if(!(open && close)){
    ackTiming=false;
    localAckIssued=false;
  }else if(lastDoor.state==hcc::DoorState::FAULT){
    if(!ackTiming){
      ackTiming=true;
      bothPressedSince=now;
    }else if(!localAckIssued && (uint32_t)(now-bothPressedSince)>=2000){
      localAckIssued=true;
      setHold(0);
      pendingAck=true;
      record("Local fault ack; AUTO stays paused");
    }
  }
  if(doorMoving() || lastDoor.state==hcc::DoorState::FAULT ||
     pending==hcc::DoorCommand::STOP || pendingAck)return;
  if((newOpen && !close) || (newClose && !open)){
    if(setHold(day)){
      pending=open?hcc::DoorCommand::OPEN:hcc::DoorCommand::CLOSE;
      record(open?"Local OPEN":"Local CLOSE");
    }
  }
}
static void tickDoor(uint32_t now,uint16_t minute,uint32_t key,bool clockOk){
  readLocalButtons(now,key);
  if(!doorMoving() && clockOk && manualHold && manualHoldDay!=0 && manualHoldDay!=key){
    // Expiry needs no flash write. The persisted day also expires after reboot.
    manualHold=false;manualHoldDay=0;
  }
  if(clockOk && !manualHold && pending==hcc::DoorCommand::NONE && !pendingAck){
    if(lastDoor.state==hcc::DoorState::CLOSED && hcc7::shouldScheduleOpen(minute,openMin,closeMin)) pending=hcc::DoorCommand::OPEN;
    if(lastDoor.state==hcc::DoorState::OPEN && hcc7::shouldScheduleClose(minute,openMin,closeMin)) pending=hcc::DoorCommand::CLOSE;
  }
  hcc::DoorInput x;
  x.raw_open=(digitalRead(PIN_LIMIT_OPEN)==LOW);
  x.raw_closed=(digitalRead(PIN_LIMIT_CLOSED)==LOW);
  x.hard_stop=(digitalRead(PIN_ESTOP_NC)!=LOW);
  safetyLoopOk=(digitalRead(PIN_OBSTRUCTION_NC)==HIGH);
  x.obstruction=!safetyLoopOk;
  x.driver_fault=motorDriverFault;
  x.power_ok=(HCC_ACTUATORS_ARMED==0) || (batteryOk && hcc7::batteryCanDrive(batteryV));
  x.movement_authorized=HCC_ACTUATORS_ARMED && prefsReady;
  x.acknowledge_fault=pendingAck;
  x.command=pending;
  x.now_ms=now;
  hcc::DoorState old=lastDoor.state;hcc::DoorFault oldFault=lastDoor.fault;
  lastDoor=door.tick(x);
  moveOutputs(lastDoor.motor_open,lastDoor.motor_close);
  if(lastDoor.state==hcc::DoorState::FAULT && old!=hcc::DoorState::FAULT &&
     (lastDoor.fault!=hcc::DoorFault::POWER_INVALID ||
      old==hcc::DoorState::OPENING || old==hcc::DoorState::CLOSING)){
    setHold(0);
  }
  if(old!=lastDoor.state || oldFault!=lastDoor.fault)
    record(String("Door ")+hcc::doorStateName(lastDoor.state)+" / "+hcc::doorFaultName(lastDoor.fault));
  pending=hcc::DoorCommand::NONE;pendingAck=false;
}
void setup(){
  pinMode(PIN_ALARM_HEALTHY,OUTPUT);digitalWrite(PIN_ALARM_HEALTHY,LOW);
  pinMode(PIN_MOTOR_DIR,OUTPUT);digitalWrite(PIN_MOTOR_DIR,LOW);
  pinMode(PIN_MOTOR_PWM,OUTPUT);digitalWrite(PIN_MOTOR_PWM,LOW);
  pinMode(PIN_EGG_HEATER,OUTPUT);digitalWrite(PIN_EGG_HEATER,LOW);
  ledcSetup(0,1000,8);ledcAttachPin(PIN_MOTOR_PWM,0);ledcWrite(0,0);
  pinMode(PIN_LIMIT_OPEN,INPUT_PULLUP);pinMode(PIN_LIMIT_CLOSED,INPUT_PULLUP);
  pinMode(PIN_ESTOP_NC,INPUT_PULLUP);pinMode(PIN_OBSTRUCTION_NC,INPUT);
  pinMode(PIN_DRIVER_FAULT,INPUT_PULLUP);pinMode(PIN_LOCAL_OPEN,INPUT_PULLUP);
  pinMode(PIN_LOCAL_CLOSE,INPUT_PULLUP);pinMode(PIN_EGG_THERMAL_NC,INPUT_PULLUP);
  pinMode(PIN_WATER_LOW,INPUT); // external pull-up required if used
  analogReadResolution(12);analogSetPinAttenuation(PIN_BAT_ADC,ADC_11db);
  esp_adc_cal_characterize(ADC_UNIT_1,ADC_ATTEN_DB_11,ADC_WIDTH_BIT_12,1100,&batteryAdc);
  Serial.begin(115200);delay(80);
  prefsReady=prefs.begin("hcc7",false);
  if(prefsReady){
    Schedule saved;
    if(prefs.getBytes("schedule",&saved,sizeof saved)!=sizeof saved){
      saved={prefs.getUShort("open",HCC_OPEN_TIME_DEFAULT),
             prefs.getUShort("close",HCC_CLOSE_TIME_DEFAULT),
             prefs.getUShort("eggstart",HCC_EGG_START_DEFAULT),
             prefs.getUShort("eggend",HCC_EGG_END_DEFAULT)};
    }
    if(validSchedule(saved))applySchedule(saved);
    const uint32_t legacyHold=prefs.getBool("hold",false)?prefs.getUInt("holdDay",0):HOLD_DISABLED;
    const uint32_t storedHold=prefs.getUInt("holdState",legacyHold);
    manualHold=(storedHold!=HOLD_DISABLED);
    manualHoldDay=manualHold?storedHold:0;
    if(prefs.getBytesLength("eggrom")==8)prefs.getBytes("eggrom",eggRom,8);
    if(prefs.getBytesLength("waterrom")==8)prefs.getBytes("waterrom",waterRom,8);
  }
  Wire.begin(PIN_RTC_SDA,PIN_RTC_SCL); Wire.setClock(100000);
  hcc7::restoreClockFromRtc();
  setenv("TZ",LOCAL_TZ,1);tzset();
  measureBattery();
  lastBattery=millis();
  temperatures.begin();temperatures.setResolution(11);temperatures.setWaitForConversion(false);
  temperatures.requestTemperatures();tempPending=true;lastTempReq=millis();
  csrf=esp_random();
  const bool serviceApConfigured=strlen(HCC_AP_PASS)>=8 &&
    strcmp(HCC_AP_PASS,"CHANGE_THIS_AP_PASSWORD")!=0;
  webConfigured=strlen(HCC_WEB_PASS)>=8 &&
    strcmp(HCC_WEB_PASS,"CHANGE_THIS_WEB_PASSWORD")!=0;
  const bool enableServiceAp=serviceApConfigured && webConfigured;
  WiFi.mode(enableServiceAp?WIFI_AP_STA:WIFI_STA);
  if(enableServiceAp)WiFi.softAP(HCC_AP_SSID,HCC_AP_PASS);
  if(strlen(HCC_WIFI_SSID)>0){WiFi.begin(HCC_WIFI_SSID,HCC_WIFI_PASS);}
  web.on("/",HTTP_GET,indexPage);
  web.on("/status",HTTP_GET,statusPage);
  web.on("/sensors",HTTP_GET,sensorsPage);
  web.on("/events",HTTP_GET,eventsPage);
  web.on("/pair",HTTP_POST,onPair);
  web.on("/action",HTTP_POST,onAction);
  web.on("/clock",HTTP_POST,onClock);
  web.on("/settings",HTTP_POST,onSettings);
  web.onNotFound([](){if(!authenticated())return;web.send(404,"text/plain","Not found");});
  if(webConfigured)web.begin();
  record(HCC_ACTUATORS_ARMED?"REV10 outputs enabled":"REV10 bench mode: outputs disabled");
  if(enableServiceAp)Serial.println(WiFi.softAPIP());
}
void loop(){
  const uint32_t now=millis();
  // Do not block loop with sensor conversion or LTE connectivity operations.
  if(tempPending && (uint32_t)(now-lastTempReq)>=750){sampleTemperature();tempPending=false;}
  if(!tempPending && (uint32_t)(now-lastTempReq)>=HCC_SENSOR_PERIOD_MS){temperatures.requestTemperatures();tempPending=true;lastTempReq=now;}
  if((uint32_t)(now-lastBattery)>=1000){lastBattery=now;measureBattery();}
  uint16_t minute=0;uint32_t dayKey=0;bool clockOk=hcc7::localClock(minute,dayKey);
  if((uint32_t)(now-lastDoorTime)>=25){
    lastDoorTime=now;
    motorDriverFault=(digitalRead(PIN_DRIVER_FAULT)==LOW);
    tickDoor(now,minute,dayKey,clockOk);
    updateHeat(minute,clockOk);
    // HEALTHY optocoupler ON pulls the RUT241 input LOW; any alarm or power
    // loss turns it OFF -> input goes HIGH via external 22k/12V pullup.
    if(now>=120000)startupGraceElapsed=true;
    alarmActive=(lastDoor.state==hcc::DoorState::FAULT) ||
      (startupGraceElapsed && !clockOk) ||
      (startupGraceElapsed && lastDoor.state==hcc::DoorState::UNKNOWN) ||
      !prefsReady || (HCC_ACTUATORS_ARMED && (!batteryOk || batteryV<24.5f)) ||
      (HCC_EGG_HEATER_INSTALLED && (!eggTempOk || !thermalLoopOk)) ||
      motorDriverFault || !safetyLoopOk;
    digitalWrite(PIN_ALARM_HEALTHY,alarmActive?LOW:HIGH);
  }
  // Do not let the synchronous HTTP server postpone travel monitoring.
  // While travelling, use the independent physical E-STOP.
  if(doorMoving()){delay(1);return;}
  if(webConfigured)web.handleClient();

  static IPAddress lastStaIp;
  if(WiFi.status()==WL_CONNECTED && WiFi.localIP()!=lastStaIp){
    lastStaIp=WiFi.localIP();
    Serial.print("HCC LAN IP: ");Serial.println(lastStaIp);
  }
  if((uint32_t)(now-lastWifi)>=30000){
    lastWifi=now;
    if(strlen(HCC_WIFI_SSID)>0 && WiFi.status()!=WL_CONNECTED){WiFi.reconnect();}
  }
  if(!ntpStarted && WiFi.status()==WL_CONNECTED){
    configTzTime(LOCAL_TZ,"pool.ntp.org","time.google.com");
    ntpStarted=true;
  }
  if(ntpStarted && sntp_get_sync_status()==SNTP_SYNC_STATUS_COMPLETED){
    rtcBackupPending=true;
    lastRtcBackupAttempt=now-5000u;
  }
  if(rtcBackupPending && (uint32_t)(now-lastRtcBackupAttempt)>=5000u){
    lastRtcBackupAttempt=now;
    if(hcc7::systemTimeValid() && hcc7::writeDS3231Utc(time(nullptr))){
      rtcBackupPending=false;
      record("Confirmed NTP time saved to DS3231");
    }
  }
  delay(1);
}
