#pragma once
// HOME CHICKEN CONTROLLER — REV02
// Portable door safety logic (C++11); no GPIO or actuation in this file.
// Software logic alone is NOT an anti-crush safety device. Hardware motor
// cut-off, current sensing and emergency manual release are mandatory later.
#include <stdint.h>

namespace hcc {
enum class DoorState : uint8_t { UNKNOWN, CLOSED, OPEN, OPENING, CLOSING, FAULT };
enum class DoorFault : uint8_t {
  NONE, SWITCH_CONFLICT, OBSTRUCTION, DRIVER_FAULT, POWER_INVALID,
  HARD_STOP, PERMISSION_LOST, TIMEOUT, LIMIT_UNSTABLE, SOURCE_STUCK,
  SOURCE_REASSERTED, MANUAL_STOP
};
enum class DoorCommand : uint8_t { NONE, OPEN, CLOSE, STOP };

struct DoorInput {
  bool raw_open = false;
  bool raw_closed = false;
  bool obstruction = false;
  bool driver_fault = false;
  bool power_ok = true;
  bool hard_stop = false;
  bool movement_authorized = false; // fail-closed default
  bool acknowledge_fault = false;
  DoorCommand command = DoorCommand::NONE;
  uint32_t now_ms = 0;
};
struct DoorOutput {
  DoorState state;
  DoorFault fault;
  bool motor_open;
  bool motor_close;
  bool position_valid;
};

// Both end switches are treated as a pair; keep independent debounce state.
class Debouncer {
public:
  explicit Debouncer(uint32_t debounce_ms = 80) : period_(debounce_ms) {}
  void update(bool raw, uint32_t now) {
    if (!started_) {
      started_ = true; last_raw_ = raw; changed_ms_ = now;
      return;
    }
    if (raw != last_raw_) {
      last_raw_ = raw; changed_ms_ = now;
    }
    if ((uint32_t)(now - changed_ms_) >= period_) {
      filtered_ = last_raw_; ready_ = true;
    }
  }
  bool value() const { return filtered_; }
  bool ready() const { return ready_; }
private:
  uint32_t period_;
  uint32_t changed_ms_ = 0;
  bool started_ = false;
  bool ready_ = false;
  bool last_raw_ = false;
  bool filtered_ = false;
};

class DoorController {
public:
  explicit DoorController(uint32_t movement_timeout_ms = 20000,
                          uint32_t debounce_ms = 80,
                          uint32_t source_release_ms = 1800)
      : open_limit_(debounce_ms), closed_limit_(debounce_ms),
        timeout_(movement_timeout_ms), debounce_ms_(debounce_ms),
        source_release_ms_(source_release_ms) {}

  DoorOutput tick(const DoorInput& x) {
    // Require a NEW acknowledgement edge, not an acknowledgement held
    // before a fault occurred.
    const bool ack_pulse = x.acknowledge_fault && !last_ack_;
    last_ack_ = x.acknowledge_fault;
    open_limit_.update(x.raw_open, x.now_ms);
    closed_limit_.update(x.raw_closed, x.now_ms);
    const bool limits_ready = open_limit_.ready() && closed_limit_.ready();
    const bool open = open_limit_.value(), closed = closed_limit_.value();
    input_stable_ = limits_ready && x.raw_open == open && x.raw_closed == closed;

    // Raw conflict, not only debounced conflict: immediately de-energize.
    if ((x.raw_open && x.raw_closed) || (limits_ready && open && closed)) {
      latch(DoorFault::SWITCH_CONFLICT); return result();
    }
    if (x.hard_stop) { latch(DoorFault::HARD_STOP); return result(); }
    if (!x.power_ok) { latch(DoorFault::POWER_INVALID); return result(); }
    if (x.obstruction) { latch(DoorFault::OBSTRUCTION); return result(); }
    if (x.driver_fault) { latch(DoorFault::DRIVER_FAULT); return result(); }

    if (state_ == DoorState::FAULT) {
      if (ack_pulse && x.command == DoorCommand::NONE &&
          input_stable_ &&
          x.raw_open != x.raw_closed) {
        // Condition above is equivalent to one and only one limit active;
        // use debounced state to recover, never start motor on acknowledgement.
        if (open != closed) {
          fault_ = DoorFault::NONE;
          state_ = open ? DoorState::OPEN : DoorState::CLOSED;
        }
      }
      return result();
    }

    if (!limits_ready) return result();
    if (x.command == DoorCommand::STOP) {
      // A stopped moving door may be between end positions, even while a
      // source limit is still asserted. Require physical recovery/ack.
      if (state_ == DoorState::OPENING || state_ == DoorState::CLOSING)
        latch(DoorFault::MANUAL_STOP);
      return result();
    }

    if (state_ == DoorState::UNKNOWN) {
      if (open != closed) state_ = open ? DoorState::OPEN : DoorState::CLOSED;
      else return result();  // unknown travel position: no blind homing
    }

    if (state_ == DoorState::OPENING || state_ == DoorState::CLOSING) {
      if (!x.movement_authorized) { latch(DoorFault::PERMISSION_LOST); return result(); }
      if ((uint32_t)(x.now_ms - started_ms_) >= timeout_) {
        latch(DoorFault::TIMEOUT); return result();
      }
      // A raw destination limit immediately suspends drive; debounce is only
      // used to confirm that it actually reached the end position.
      const bool arriving_raw = (state_ == DoorState::OPENING ? x.raw_open : x.raw_closed);
      const bool arriving_stable = (state_ == DoorState::OPENING ? open : closed);
      const bool source_raw = (state_ == DoorState::OPENING ? x.raw_closed : x.raw_open);
      if (arriving_raw && !stop_pending_) { stop_pending_ = true; stop_at_ms_ = x.now_ms; }
      if (stop_pending_) {
        if (arriving_stable) {
          state_ = state_ == DoorState::OPENING ? DoorState::OPEN : DoorState::CLOSED;
          stop_pending_ = false;
          return result();
        }
        if ((uint32_t)(x.now_ms - stop_at_ms_) > 3u * debounce_ms_ + 50u) {
          latch(DoorFault::LIMIT_UNSTABLE);
        }
        return result();
      }
      if (!source_raw) source_released_ = true;
      if (source_released_ && source_raw) {
        latch(DoorFault::SOURCE_REASSERTED); return result();
      }
      if (source_raw && (uint32_t)(x.now_ms - started_ms_) >= source_release_ms_) {
        latch(DoorFault::SOURCE_STUCK);
      }
      return result();
    }

    if ((state_ == DoorState::OPEN && !open) ||
        (state_ == DoorState::CLOSED && !closed)) {
      state_ = DoorState::UNKNOWN; return result();
    }
    // Only an explicitly authorized, single-shot request can start a drive.
    // Both inputs must agree with their debounced values before a new
    // movement is allowed (reject contact bounce or disconnected wiring).
    if (x.movement_authorized &&
        x.raw_open == open && x.raw_closed == closed) {
      if (state_ == DoorState::CLOSED && x.command == DoorCommand::OPEN) {
        start(DoorState::OPENING, x.now_ms);
      } else if (state_ == DoorState::OPEN && x.command == DoorCommand::CLOSE) {
        start(DoorState::CLOSING, x.now_ms);
      }
    }
    return result();
  }

  DoorOutput result() const {
    const bool motor_open = state_ == DoorState::OPENING && !stop_pending_;
    const bool motor_close = state_ == DoorState::CLOSING && !stop_pending_;
    return {state_, fault_, motor_open, motor_close,
            (state_ == DoorState::OPEN || state_ == DoorState::CLOSED) && input_stable_};
  }
private:
  void start(DoorState direction, uint32_t ms) {
    state_ = direction; started_ms_ = ms; stop_pending_ = false;
    source_released_ = false;
  }
  void latch(DoorFault fault) {
    state_ = DoorState::FAULT; fault_ = fault; stop_pending_ = false;
  }
  Debouncer open_limit_, closed_limit_;
  const uint32_t timeout_, debounce_ms_, source_release_ms_;
  DoorState state_ = DoorState::UNKNOWN;
  DoorFault fault_ = DoorFault::NONE;
  uint32_t started_ms_ = 0, stop_at_ms_ = 0;
  bool stop_pending_ = false;
  bool source_released_ = false, last_ack_ = false, input_stable_ = false;
};
inline const char* doorStateName(DoorState s) {
  switch (s) {
    case DoorState::UNKNOWN: return "UNKNOWN";
    case DoorState::CLOSED: return "CLOSED";
    case DoorState::OPEN: return "OPEN";
    case DoorState::OPENING: return "OPENING";
    case DoorState::CLOSING: return "CLOSING";
    case DoorState::FAULT: return "FAULT";
  } return "INVALID";
}
inline const char* doorFaultName(DoorFault f) {
  switch (f) {
    case DoorFault::NONE: return "NONE";
    case DoorFault::SWITCH_CONFLICT: return "SWITCH_CONFLICT";
    case DoorFault::OBSTRUCTION: return "OBSTRUCTION";
    case DoorFault::DRIVER_FAULT: return "DRIVER_FAULT";
    case DoorFault::POWER_INVALID: return "POWER_INVALID";
    case DoorFault::HARD_STOP: return "HARD_STOP";
    case DoorFault::PERMISSION_LOST: return "PERMISSION_LOST";
    case DoorFault::TIMEOUT: return "TIMEOUT";
    case DoorFault::LIMIT_UNSTABLE: return "LIMIT_UNSTABLE";
    case DoorFault::SOURCE_STUCK: return "SOURCE_STUCK";
    case DoorFault::SOURCE_REASSERTED: return "SOURCE_REASSERTED";
    case DoorFault::MANUAL_STOP: return "MANUAL_STOP";
  } return "INVALID";
}
} // namespace hcc
