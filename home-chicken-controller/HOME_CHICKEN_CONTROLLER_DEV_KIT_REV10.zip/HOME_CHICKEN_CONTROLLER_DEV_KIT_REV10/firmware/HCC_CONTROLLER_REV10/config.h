#pragma once
// HOME CHICKEN CONTROLLER REV10 – commissioning configuration.
// Power outputs enabled for commissioning with independent hardware interlocks.
#define HCC_ACTUATORS_ARMED 1
#define HCC_EGG_HEATER_INSTALLED 1
#define HCC_ALLOW_WEB_MOTOR_COMMANDS 0
#define HCC_BATTERY_ADC_CALIBRATED 0

// Real measured meter-voltage / uncalibrated ADC voltage factor. Never guess.
#define HCC_BATTERY_ADC_CORRECTION 1.000f
// 120 kOhm top / 10 kOhm bottom -> ratio 13.0; 100 nF to GND on ADC.
#define HCC_BATTERY_DIVIDER_RATIO 13.0f

// DC motor drive: Pololu G2 24v13, direct battery via fused NC emergency cutout.
// 24V Pololu 100:1 gearmotor #4685. Hardware independent anti-crush edge,
// mechanical torque slip coupling and manual release REQUIRED. G2 current
// limit defaults to ~30 A (NOT a safe force limit); SW ADC fault is supplementary.
#define HCC_MOTOR_PWM_DUTY 105 // 8-bit, 0..255, tune only during commissioning
#define HCC_MOTOR_TIMEOUT_MS 12000UL
#define HCC_OPEN_TIME_DEFAULT 450 // 07:30 (site-adjustable)
#define HCC_CLOSE_TIME_DEFAULT 1080 // 18:00 (site-adjustable)
#define HCC_EGG_START_DEFAULT 420 // 07:00
#define HCC_EGG_END_DEFAULT 960   // 16:00
#define HCC_HEAT_CUTOFF_V 25.0f  // voltage-only CONSERVATIVE, not a true SOC!
#define HCC_MOTOR_CUTOFF_V 23.8f
#define HCC_MIN_BATTERY_V 21.0f
#define HCC_MAX_BATTERY_V 30.0f
// 12 V 20 W heater via dedicated 12 V DC/DC and DFRobot DFR0457 MOSFET.
// NC thermal switch and independent one-shot fuse MUST be wired IN SERIES with heater.
#define HCC_EGG_HEAT_ON_C 2.0f
#define HCC_EGG_HEAT_OFF_C 5.0f
// Sensor sample period; DS18B20 conversion is asynchronous.
#define HCC_SENSOR_PERIOD_MS 5000UL

// Input pin map: contacts to GND only, 3.3V logic.
#define PIN_LIMIT_OPEN 32
#define PIN_LIMIT_CLOSED 33
#define PIN_ESTOP_NC 18      // normally closed to GND; open = unsafe
#define PIN_OBSTRUCTION_NC 19 // isolated dry-contact safety feedback: HIGH=healthy; external pulldown
#define PIN_DRIVER_FAULT 23 // Pololu G2 /FLT open drain, active LOW (internal pullup)
#define PIN_LOCAL_OPEN 13    // pushbutton NO to GND
#define PIN_LOCAL_CLOSE 14   // pushbutton NO to GND
#define PIN_MOTOR_DIR 25
#define PIN_MOTOR_PWM 26
#define PIN_EGG_HEATER 16
#define PIN_ONEWIRE 4
#define PIN_BAT_ADC 34
#define PIN_RTC_SDA 21
#define PIN_RTC_SCL 22
// GPIO39 input only needs external pull-up, optional water-low float.
#define PIN_ALARM_HEALTHY 27 // optocoupler LED: HIGH=healthy, LOW=alarm/power loss
#define PIN_WATER_LOW 39
#define PIN_EGG_THERMAL_NC 17 // hardwired thermal cutout status: NC to GND
