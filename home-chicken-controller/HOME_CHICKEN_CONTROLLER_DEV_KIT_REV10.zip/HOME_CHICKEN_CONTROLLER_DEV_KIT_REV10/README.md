# HOME CHICKEN CONTROLLER – DEV KIT REV10

Montážní a přejímací sada pro ostrovní kurník pro 10 slepic na zahradě přibližně 500 m od domu. Obsahuje místní automatiku dvířek, vyhřívání sběrného boxu a vzdálený dohled přes LTE/VPN. Dostupnost nezamrzlé vody a stav zvířat se kontrolují osobně.

## Pořadí práce

1. [Stavba a montáž](construction/STAVBA_ROVNY_TEREN_REV10.md), [půdorys](drawings/HCC_PUDORYS_ROVINA_REV10.png) a [aktuální nákupní seznam](components/HCC_NAKUPNI_SEZNAM_REV10.xlsx). Na místě uzavři půdorys, kotvení, mechaniku dvířek a výkonové jištění před nevratnými pracemi a nákupem položek označených jako kandidát.
2. [Elektrické zapojení](docs/ZAPOJENI_A_BEZPECNOST_REV10.md) a [blokové schéma](drawings/HCC_DC_BLOKY_REV10.png) podle jednotlivých svorek a použitých ochran. REV10 používá na GPIO34 dělič **120 kΩ / 10 kΩ**. GPIO35 a výstup CS nejsou pro provoz potřeba. Mechanická ochrana a nezávislé odpojení výkonu motoru jsou součástí návrhu.
3. [Instalace firmwaru](docs/INSTALACE_ARDUINO_REV10.md). V dodaném kódu jsou výstupy povolené a sepnutí čeká na kalibraci a splnění ochranných podmínek. První nahrání a nastavení proveď s fyzicky odpojeným motorem a fólií.
4. [LTE, WireGuard, kamera a SMS](docs/LTE_WIREGUARD_KAMERA_REV10.md). Přístup vyžaduje SIM, vlastní síťové údaje a dosažitelný uzel WireGuard.
5. [Přejímka po montáži](docs/NAVOD_ZKOUSEK_REV10.md) a [protokol ověření](docs/KONTROLA_REV10.md). Zkoušej jednotlivé větve zvlášť, potom celek bez zvířat.

Firmware je pro ESP32 Dev Module a AI Thinker ESP32‑CAM, s lokálním časem Europe/Prague. Automatika dvířek a topení běží místně i při výpadku LTE, pokud má řídicí deska platné hodiny a napájení. Přímo z webu je ve výchozí konfiguraci zakázáno otevřít/zavřít. Změna časů nebo zapnutí AUTO může spustit naplánovaný pohyb.

Původní REV08 je v `REFERENCE/` a předchozí GPIO vydání REV09 zůstává v repozitáři. Pro skutečné zapojení REV10 používej výhradně návod této revize.
