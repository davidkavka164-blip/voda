# Instalace LTE, WireGuard a kamery

RUT241 v kurníku propojuje místní Wi‑Fi s LTE. Dvířka a topení řídí ESP32 místně. Telefon přistupuje přes WireGuard ke stavu zařízení a fotografii vajec. VPN vyžaduje dosažitelný uzel a klíče pro tři zařízení. Nastavení závisí na SIM, adrese uzlu a místních sítích.

## RUT241, Wi‑Fi a adresa zařízení

1. Vlož SIM s daty a odchozími SMS. Připoj LTE antény podle příručky routeru, zapoj počítač do LAN a dokonči úvodní nastavení routeru. Změň heslo správce a nastav zabezpečenou 2,4GHz Wi‑Fi s WPA2‑PSK/AES pro obě ESP32.
2. V části **Network → Mobile** zkontroluj registraci v LTE a datové připojení. Pokud automatický APN nefunguje, nastav hodnotu operátora. Ověř datové připojení z LAN. [Nastavení mobilní sítě RUT241](https://wiki.teltonika-networks.com/view/RUT241_Mobile)
3. Zvol podsíť LAN kurníku, která se nepřekrývá s domácí ani jinou sítí, ze které se připojuješ. Příklad níže používá LAN `192.168.64.0/24` a router `192.168.64.1`. Po změně LAN se znovu připoj k routeru na nové adrese.
4. Zadej SSID, heslo Wi‑Fi a vlastní heslo webu do `secrets.h` řídicí desky. U kamery vyplň síť a vlastní heslo ve zdrojovém kódu kamerového programu. Přístupové údaje ukládej lokálně, mimo sdílené archivy a repozitáře.
5. Po prvním připojení vytvoř v RUT241 **DHCP → Static Leases** rezervace podle MAC adresy Wi‑Fi stanice. Například řídicí ESP32 `192.168.64.20` a kamera `192.168.64.21`. Ověř zachování adres po restartu routeru i desek. Do `HCC_CAMERA_LOCAL_URL` můžeš zadat `http://192.168.64.21/jpg`. [Rezervace DHCP RUT241](https://wiki.teltonika-networks.com/view/RUT241_DHCP)
6. Z místní LAN otevři `http://192.168.64.20/status` a s kamerou `http://192.168.64.21/jpg`. Obě zařízení mají vyžádat přihlášení. Na řídicí desce ověř platný místní čas a uložení synchronizovaného času do RTC podle přejímacího návodu. Přístup k DNS a NTP musí být povolený i pro desku.

Servisní AP použij pro místní nastavení bez routeru. Pro běžný provoz lze ponechat vzorové servisní heslo `HCC_AP_PASS`, čímž AP zůstane vypnutý. Web přes RUT241 vyžaduje nastavené vlastní `HCC_WEB_PASS`.

## WireGuard přes dosažitelný uzel

RUT241 i telefon navazují spojení k jednomu uzlu WireGuard s veřejně dosažitelným UDP portem, například k domácímu routeru nebo jinému spravovanému uzlu. Tento směr funguje i za mobilním CGNAT. Pokud je doma také CGNAT a UDP port z internetu není dosažitelný, použij dosažitelný uzel. Pro připojení je potřeba jeho veřejná IP nebo DNS jméno a UDP port. Na WAN zpřístupni jen zvolený UDP port WireGuard na uzlu. Weby ESP32 a administraci routeru nech dostupné pouze v příslušné místní síti nebo ve VPN. [WireGuard na RUT241](https://wiki.teltonika-networks.com/view/RUT241_VPN#WireGuard)

Každé zařízení má vlastní soukromý klíč. Veřejný klíč uzlu patří do konfigurace RUT241 a telefonu. Uzel má dva peery, z nichž každý má veřejný klíč příslušného zařízení.

| Položka | Příklad hodnoty |
| --- | --- |
| Veřejná adresa uzlu | `<vlastní-dosažitelný-uzel>:51820` |
| Adresa tunelu uzlu | `10.55.241.1/24` |
| Adresa tunelu RUT241 | `10.55.241.2/24` |
| Adresa tunelu telefonu | `10.55.241.3/32` |
| Na uzlu, **AllowedIPs** u peeru RUT241 | `10.55.241.2/32, 192.168.64.20/32, 192.168.64.21/32` |
| Na uzlu, **AllowedIPs** u peeru telefonu | `10.55.241.3/32` |
| Na RUT241, **Allowed IPs** u peeru uzlu | `10.55.241.1/32, 10.55.241.3/32` |
| Na telefonu, **AllowedIPs** u peeru uzlu | `192.168.64.20/32, 192.168.64.21/32` |

Na RUT241 zadej adresu uzlu jako **Endpoint**, zapni **Route Allowed IPs** a nastav **Persistent Keep Alive** na 25 s. Na telefonu nastav stejný endpoint. Na uzlu povol IPv4 forwarding z tunelu zpět do tunelu a ověř směrování adres obou ESP32 přes peer RUT241. Na uzlu i na RUT241 povol průchod pouze z `10.55.241.3` na obě adresy ESP32, TCP 80, a zpět pro navázaná spojení. Na RUT241 pravidlo směřuje ze zóny WireGuard do LAN. Zařízení v kurníku používají jako výchozí bránu RUT241. Jejich adresy musí odpovídat rezervacím DHCP. Když kameru nepoužíváš, vypusť její adresu z povolených tras i pravidel. [Příklad směrování WireGuard](https://wiki.teltonika-networks.com/view/WireGuard_Configuration_Example) · [Firewall RUT241](https://wiki.teltonika-networks.com/view/RUT241_Firewall)

Veřejně dostupný uzel zajišťuje směrování mezi dvěma tunely. HTTP Basic chrání přístup heslem a WireGuard šifruje provoz po cestě mezi klienty a uzlem. K oběma webům proto přistupuj pouze z důvěryhodné LAN nebo přes vlastní důvěryhodný uzel.

## SMS z digitálního vstupu

1. Použij vstup **Input (3)** a referenci GND z RUT241 podle schématu této revize. Nech logiku vstupu bez invertování. Výrobce uvádí LOW 0–6 V a HIGH 8 V až do vlastního napájecího napětí routeru. U RUT241 napájeného 12 V použij pro vstup jeho 12V stranu přes zapojení uvedené v elektrickém návodu. Stav musí být při zdravém ESP32 LOW a při rozepnutí signalizace nebo odpojení napájení ESP32 HIGH. Ověř oba stavy ve webu routeru a multimetrem na vstupu vůči GND RUT241. [Digitální vstup RUT241](https://wiki.teltonika-networks.com/view/RUT241_Input/Output)
2. V **Event Juggler** přidej událost typu **I/O** se vstupem **Input (3)** a hranou **Rising**. Přiřaď akci **Send SMS** s číslem příjemce a textem, například `Kurnik: alarm nebo nedostupny radic, zkontroluj stav.` Nastav krátké zpoždění a **Prevent action execution**, pokud chceš odfiltrovat krátké přechody. Konkrétní názvy položek závisejí na RutOS. [Event Juggler RUT241](https://wiki.teltonika-networks.com/view/RUT241_Event_Juggler)
3. Se zapnutým RUT241 vyvolej přechod LOW → HIGH. Ověř skutečné doručení SMS, návrat do LOW a doručení po dalším přechodu po uplynutí nastavené prodlevy. Samotná detekce hrany může minout stav, který je HIGH už při startu routeru. Ověř tento scénář samostatně. Pokud RutOS nabízí událost **Boot** a podmínku **I/O**, můžeš přidat samostatnou kontrolu HIGH po startu.
4. Alarm ze vstupu je obecný. Podrobnost čti na webu řídicí desky nebo ověř na místě. Doručení SMS vyžaduje napájený router a dostupnou mobilní síť. Výpadek celé napájecí větve zjistíš podle nedostupnosti tunelu nebo osobní kontrolou.

## Přejímka po instalaci

| Zkouška | Očekávaný výsledek |
| --- | --- |
| Telefon, vypnutá Wi‑Fi, zapnutá mobilní data a WireGuard | Na uzlu je aktuální handshake obou peerů. Po přihlášení se načte stav a z kamery nová fotografie. Ověř proměnný obsah snímku změnou před kamerou. |
| Telefon, vypnutý WireGuard | Soukromé adresy zařízení jsou ze vzdálené sítě nedostupné a veřejné přesměrování TCP 80 se nepoužívá. |
| Restart RUT241 a následný návrat LTE | Tunel se znovu sestaví, ESP32 získají stejné rezervované adresy a telefon opět načte stav a fotografii. |
| Výpadek LTE | Stav a kamera jsou vzdáleně nedostupné. Místní automatika vychází z platného času a ochranných vstupů. Po návratu LTE se vrátí vzdálený přístup. |
| Simulace alarmu a vypnutí ESP32 při napájeném RUT241 | Vstup ze zdravého stavu LOW přejde do HIGH a dorazí SMS. |
| Ověření funkcí dostupných z telefonu | Ověř stav, fotografii a provozní přístup podle konfigurace. Příznak `motor_web_enabled=false` blokuje přímé povely OTEVŘÍT a ZAVŘÍT. Oprávněný uživatel může podle nastavení webu měnit časy nebo obnovit AUTO, což může vést k naplánovanému pohybu. |

Při poruše začni místním testem přes LAN. Když funguje LAN a chybí handshake, prověř LTE, adresu a UDP port uzlu, veřejné klíče a keepalive. Když je handshake aktuální a LAN přes tunel neodpovídá, zkontroluj `AllowedIPs`, IP forwarding na uzlu, firewall, DHCP rezervace a výchozí bránu obou desek.
