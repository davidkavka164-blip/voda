# Ověření montážní sady REV10

## Provedené kontroly

- Výchozím bodem byl ZIP REV09 GPIO zveřejněný v repozitáři `davidkavka164-blip/voda`. Lokální kopie odpovídá dříve staženému souboru byte po bytu.
- Oba programy sestaveny na Linuxu s Arduino CLI 1.6.0 a skutečným ESP32 core 1.0.6. Řídicí deska `esp32:esp32:esp32` používá 794 110 B flash, kamera `esp32:esp32:esp32cam` 871 486 B flash. Externí knihovny jsou OneWire 2.3.8 a DallasTemperature 3.9.0.
- Host testy s AddressSanitizer a UndefinedBehaviorSanitizer prošly 1 479 kontrolami stavu dvířek, topení a časového režimu a 22 kontrolami RTC. Zahrnují například okamžitý povel k vypnutí PWM na konci dráhy, poruchu driveru v klidu, potvrzení poruchy bez zahájení pohybu a odmítnutí chybného kalendářního data.
- Montážní podklady používají stejné GPIO a dělič 120 kΩ / 10 kΩ. Nákupní seznam CSV a XLSX uvádí stejné položky. Hodnoty a rozhraní kritických komponent jsme porovnali s odkazy výrobců v návodu k zapojení.

## Změny při přechodu z REV09

- Při zastavení se shodí PWM a DIR se nepřepíná. Ochrana driveru /FLT a fyzické bezpečnostní smyčky vyvolávají poruchu i v klidu. Měření proudu z nesynchronizovaného CS jsme odstranili. K omezení síly a zastavení se používají nezávislé prvky pohonu.
- Hodiny lze při prvním spuštění inicializovat přes NTP nebo na místním webu podle správně nastaveného telefonu či počítače. RTC ukládá UTC. Zvolené jádro používá 32bitový čas, takže známou hranicí této sestavy je 19. 1. 2038, 03:14:07 UTC.
- Časy a režim AUTO se ukládají v jednotlivých souhrnných hodnotách NVS, původní nastavení z platné konfigurace se načte. Potvrzení poruchy ponechá AUTO pozastavené. Web zobrazuje stáří údajů při výpadku spojení nebo během pohybu.

## Co ověřit na skutečné instalaci

- Před nákupem a montáží výkonových částí uzavři výběr mechaniky dvířek, nezávislého odpojení výkonu a tepelných ochran. Průřezy, jištění, kotvení a statiku urči podle konkrétního místa a dílů.
- Po montáži proveď [přejímku](NAVOD_ZKOUSEK_REV10.md), včetně odpojení výkonu motoru, ochrany proti přiskřípnutí, tepelného odpojení, kalibrace baterie, funkce po výpadku LTE a doručení SMS. Dokonči několikadenní zkoušku bez zvířat.
- Pro vzdálený dohled nastav vlastní SIM, přístupové údaje a dosažitelný uzel WireGuard. Fyzické chování desek, mechanismu a LTE na místě v tomto vydání nebylo změřeno.
