# HCC REV10 – otevření v Arduino IDE 1.8.19 / ESP32 core 1.0.6

## Knihovny
V Arduino IDE v **Nástroje → Vývojová deska → ESP32 Dev Module** zvol instalovanou podporu **esp32 by Espressif Systems 1.0.6**. Do **Správce knihoven** přidej **OneWire 2.3.8** a **DallasTemperature 3.9.0**. `WiFi`, `WebServer`, `Wire`, `Preferences`, LEDC a `esp_camera.h` dodává jádro ESP32. Pro kameru vyber **AI Thinker ESP32-CAM**.

Rozbal archiv. V Arduino IDE otevři `firmware/HCC_CONTROLLER_REV10/HCC_CONTROLLER_REV10.ino`. Vedle `.ino` musí zůstat `config.h`, `secrets.h`, `door_safety.hpp`, `policy.hpp`, `rtc_ds3231.hpp`. Arduino IDE normálně ukáže **záložky** pro soubory místo celé složky; to je správně.

## Před zapnutím fyzických výstupů
1. Nejprve sestav program pro **samotný ESP32 bez připojeného motoru a topné fólie**. Uprav `secrets.h`: SSID domácího/route­rového Wi‑Fi, přístupové údaje a nové silné heslo servisního AP. Nepřipojuj webový server přímo do veřejného internetu.
2. Ověř web lokálně přes servisní AP `HCC-SERVICE-REV10`. Heslo určuje `HCC_AP_PASS` v `secrets.h`. Testovací stránka `/status` má přístup HTTP Basic (uživatel/heslo v `secrets.h`).
3. Připoj obě DS18B20 na 3,3 V, GPIO4 a pull-up 4k7; v `/sensors` spáruj skutečné ROM adresy. Pokud je čidlo nedostupné, topení má zůstat OFF.
4. Připoj DS3231 na SDA21/SCL22 a 3,3V pull-up. Zkontroluj čas Evropa/Praha a přechod zimního/letního času; RTC uchovává UTC. Pokud ještě nemá platný čas a NTP není dostupné, lokální web nabídne jednorázové nastavení hodin z počítače nebo telefonu.
5. Zkontroluj dělič 120 kΩ / 10 kΩ multimetrem při různém napětí na vstupu děliče. Měř zvlášť napětí baterie před děličem a nízké napětí na GPIO34. Nikdy nepřipojuj baterii přímo na GPIO34. Zachovej správný poměr děliče a zkontroluj korekci `HCC_BATTERY_ADC_CORRECTION`. Výchozí hodnota 1.000 není skutečná kalibrace.
6. Před motorovým testem připoj a **proměř** hardwarové E-STOP, bezpečnostní hranu, /SLP a skutečnou ochranu proti přiskřípnutí. Bez mechanické/elektrické ochrany dvířka nezkoušej na slepicích.
7. Zkontroluj **dva oddělené tepelné NC kontakty** – výkonový 12V a 3,3V stavový GPIO17. Dolož DC rating teplotní ochrany, tepelnou pojistku a kovovou roznášecí plochu. Bez toho topení nepřipojuj.

Tato konfigurace má v kódu povolený motor i topení. Při prvním nahrání oba fyzicky odpoj. Kalibraci děliče prováděj s odpojenými výkonovými zátěžemi. Položka `battery_voltage_estimate` zobrazuje odhad ještě před potvrzením kalibrace. Při výchozí korekci 1,000 spočítej první odhad korekce jako napětí multimetru na straně baterie dělené hodnotou `battery_voltage_estimate`. Ověř shodu ve více bodech včetně obou spínacích mezí. Jestli jedna korekce nedává použitelný výsledek, nejprve zkontroluj dělič, spojení GND a měření ADC. Po ověření potvrď kalibraci nastavením `HCC_BATTERY_ADC_CALIBRATED=1`. Pro první výkonovou zkoušku připoj jen jednu zátěž a postupuj podle přejímacího návodu.

Servisní AP a web vyžadují nahrazení vzorových hesel. Při pohybu dvířek se HTTP požadavky odloží. Okamžité zastavení zajistí fyzický E‑STOP. Volba **Pozastavit AUTO** v klidu pozastaví AUTO i přes půlnoc a restart. Obnovíš ho tlačítkem **Zapnout AUTO** nebo místním povelem, který nastaví ruční pozastavení do dalšího dne. Po poruše nejdřív ověř známou koncovou polohu, stav ochran a potvrď poruchu z webu nebo podržením obou tlačítek 2 s. AUTO zůstane pozastavené, dokud jej výslovně nepovolíš nebo nezvolíš místní povel.

## Kamera
Otevři **zvlášť** `firmware/HCC_CAM_REV10/HCC_CAM_REV10.ino` s volbou AI Thinker ESP32-CAM a vlastním `WiFi` SSID/heslem a HTTP Basic přístupem. Fotografie `/jpg` jsou dostupné pouze přes zabezpečenou LAN/VPN. Kamera má vlastní stabilní 5V větev. Pro desku bez USB použij programátor nebo USB–UART s 3,3V logikou a společnou zemí. Při nahrávání podrž GPIO0 v LOW při resetu, po úspěšném nahrání ho odpoj od GND a desku resetuj. Napájení 5 V zapoj jen na označený napájecí pin desky. Ve výpisu 115200 Bd ověř IP obou desek nebo použij seznam klientů RUT241.

## Mobilní přístup přes LTE
Postup nastavení routeru, WireGuard, IP kamer a SMS uvádí [síťový návod](LTE_WIREGUARD_KAMERA_REV10.md).

## Překlad přes Arduino CLI

Po instalaci ESP32 core 1.0.6 a uvedených knihoven spusť z kořene rozbaleného ZIPu:

```sh
arduino-cli compile --fqbn esp32:esp32:esp32 firmware/HCC_CONTROLLER_REV10
arduino-cli compile --fqbn esp32:esp32:esp32cam firmware/HCC_CAM_REV10
```

## Stav ověření
Oba programy sestaveny na Linuxu s Arduino CLI 1.6.0, ESP32 core 1.0.6 a výše uvedenými knihovnami. Na Windows a na fyzických deskách zbývá ověřit nahrání a chování sestavy.
