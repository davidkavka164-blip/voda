# HCC REV10 – zapojení a montážní rozhraní

Podklad určuje propojení vodičů a signálů pro ESP32-WROOM DevKit, samostatnou ESP32-CAM, RUT241, Pololu G2 #2992 a topení vajec. Před přivedením výkonu doplň konečné typy ochran, hodnoty jištění, délky a průřezy vodičů podle skutečných komponent a uložení. Čísla u ESP32 označují GPIO. Poloha těchto pinů na liště závisí na desce.

## Napájení a odpojení

| Větev | Propojení svorek | Co potvrdit před připojením |
|---|---|---|
| Panely | Dva shodné panely v sérii → FV DC odpojovač → PV+ a PV− MPPT | Voc, Isc a teplotní koeficient ze štítků, minimální teplota, polarita, hodnoty a vypínací schopnost odpínače. |
| Baterie a MPPT | Baterie + → hlavní DC pojistka co nejblíže baterii → DC odpojovač → kladný rozvod. Baterie − → záporný rozvod. BAT+ MPPT přes vlastní pojistku na kladný rozvod, BAT− na záporný rozvod. | Zkratové parametry, ochrany a BMS. Pořadí připojování a odpojování podle návodu MPPT. |
| Měnič 5 V | Samostatně jištěná 24V větev → DDR-30G-5 IN+/IN−. OUT+ přes dvě oddělená jištění na 5V vstup DevKitu a 5V vstup kamery. OUT− na jejich GND. | Označení napájecího pinu DevKitu, úbytek na kabelu, proudové špičky kamery. |
| Měnič 12 V | Samostatně jištěná 24V větev → DDR-60G-12 IN+/IN−. OUT+ přes oddělené pojistky pro RUT241 a DFR0457. OUT− na GND příslušného zařízení. | Výstup změř před připojením. Jištění a kabely dimenzuj samostatně pro router i topení. |
| Motor | Kladný rozvod → pojistka motorové větve → stejnosměrný výkonový kontakt blokace v klidu rozepnutý → VIN Pololu. GND Pololu na záporný rozvod. OUTA/OUTB na motor. | Kontakt a jištění pro DC napětí, rozběh, zkratový proud a induktivní zátěž. Při první zkoušce ověř směr bez mechanismu. |

Přívody označ na obou koncích. Referenci GND řadiče, děliče a Pololu spoj podle návrhu tak, aby proud motoru netekl signálovou zemí. Návrat topení veď k 12V měniči. Vodiče PWM, I²C, 1‑Wire a ADC veď mimo silové a FV trasy. Ochranu proti přepětí, pospojování rozváděče a rámů panelů a další ochrany určí DC projekt podle místa. Před napájením desky z USB odděl externí 5 V, pokud schéma konkrétní desky výslovně nepovoluje souběh.

Pololu uvádí 40 V jako absolutní maximum a přibližně 34 V jako bezpečnou horní hranici s ohledem na zvlnění. Podle výrobce doplň vhodný kondenzátor na VIN/GND u driveru v řádu stovek µF s rezervou jmenovitého napětí. Ověř špičky a energii, která po rozpojení výkonového kontaktu zůstane v kondenzátoru. Účinnost zastavení a zajištění dvířek ověř nezávisle na firmware.

Pro dva shodné panely v sérii platí **Voc_zima = 2 × Voc_STC × [1 + |βVoc| × (25 − Tmin)]**, je-li teplotní koeficient βVoc vyjádřen desetinným číslem na °C a Tmin ≤ 25 °C. Koeficient v %/°C před výpočtem vyděl 100. Výsledek porovnej s mezemi MPPT, odpínače a dalších FV částí se zohledněním návrhové rezervy. Pro zkratový proud série vycházej z hodnoty jednoho panelu a příslušných návrhových korekcí. Nabíjení v mrazu musí řídit BMS či jiná nezávislá ochrana podle výrobce baterie.

## Zapojení signálů ESP32

| GPIO | Svorka nebo vodič | Stav a provedení |
|---|---|---|
| 32 | Horní koncový spínač NO mezi GPIO32 a GND | LOW při plném otevření. |
| 33 | Spodní koncový spínač NO mezi GPIO33 a GND | LOW při plném zavření. |
| 18 | Oddělený NC kontakt E‑STOP mezi GPIO18 a GND, případně odpovídající bezpotenciálová zpětná vazba E‑STOP | LOW ve zdravém stavu, HIGH při stisku či přerušení vodiče. |
| 19 | Bezpotenciálový NO kontakt nezávislé smyčky mezi 3V3 ESP32 a GPIO19, externí 10 kΩ z GPIO19 na jeho GND | HIGH při skutečném povolení pohonu, LOW při vypnutí či přerušení vodiče. |
| 23 | Pololu /FLT | Otevřený drain, externí 10 kΩ k 3V3 ESP32, LOW při poruše driveru. |
| 25 | Pololu DIR | Směr ověř s odpojeným mechanismem. |
| 26 | Pololu PWM | Externí 10 kΩ k signálové GND u driveru, LOW při vypnutí. |
| 35 | Rezerva | Pololu CS ponech odpojené. |
| 13 / 14 | Dvě samostatná tlačítka NO na GND | LOW při stisku. Označ OTEVŘÍT a ZAVŘÍT. |
| 16 | DFR0457 SIG | HIGH zapne topení, externí 10 kΩ k GND na straně řídicího vstupu. |
| 17 | Samostatný stavový tepelný kontakt NC na GND | LOW ve zdravém stavu, HIGH při rozpojení. Oddělený od 12V výkonového obvodu. |
| 4 | DQ obou DS18B20 | 4,7 kΩ pull‑up k 3V3 u řadiče. Obě sondy mají tři vodiče VDD, GND, DQ. |
| 21 / 22 | DS3231 SDA / SCL | Napájení i pull‑upy na 3V3. Vyber nenabíjecí modul pro CR2032. |
| 34 | Uzel napěťového děliče baterie | Schéma níže. |
| 27 | Vstup optočlenu alarmu | HIGH rozsvítí optočlen, RUT241 čte LOW jako zdravý stav. |
| 39 | Rezervovaný vstup hladiny | Ponech odpojený. Teplota sondy sama nedokládá dostupnost vody. |

**Dělič baterie:** Jištěný kladný 24V rozvod za hlavním odpojovačem → **120 kΩ 1 %** → uzel GPIO34 → **10 kΩ 1 %** → GND ESP32. Paralelně k dolnímu odporu připoj 100 nF k signálové GND přímo u ESP32. Poměr je 13:1. Při 21–30 V na baterii odpovídá uzel ADC přibližně 1,62–2,31 V. **Rozsah 21–30 V patří výhradně na vstup děliče. Přímé připojení na GPIO zničí desku.** Před zapojením GPIO změř uzel a ověř polaritu, rozsah i společnou referenci. Kalibruj podle několika napětí v pracovním rozsahu a návodu k instalaci. Starý dělič 100 kΩ / 10 kΩ uprav na poměr 13:1 a znovu kalibruj.

## Motor a nezávislé zastavení

- Hardwarová blokace pracuje nezávisle na ESP32. E‑STOP a bezpečnostní hrana musí v provozní sestavě odebrat napájení motorové větve přes DC výkonový kontakt a zároveň vynutit LOW na **/SLP**. Zapojení /SLP má používat samostatnou bezpotenciálovou vazbu nebo jiné deterministické buzení. Zpětnou vazbu GPIO19 připoj samostatně podle tabulky. Po zásahu ochrany zabraň samočinnému opětovnému spuštění pohonu.
- Pololu uvádí u desky **md31c** interní pull‑up /SLP. Původní **md31a** má pull‑down. Spolehlivé zastavení vyžaduje definovanou nízkou úroveň, kterou ověříš i při přerušení smyčky, výpadku řídicího napájení, přerušené zpětné vazbě a trvale vysokém PWM.
- Typ hrany, relé, výkonového DC kontaktu, ručního resetu a sledování kontaktů vyber podle skutečného mechanismu. Hrana 8,2 kΩ vyžaduje kompatibilní vyhodnocovací jednotku. Stavové kontakty odděl od 12/24V obvodů. E‑STOP umísti dostupně u zařízení.
- Koncové spínače NO předávají polohu. Přerušený vodič se chová jako neaktivní spínač. Nainstaluj nezávislé mechanické omezení dráhy, ochranu proti pádu dvířek, kluzné omezení síly a ruční uvolnění. Ochranu ověř bez zvířat.
- CS Pololu měří jen při aktivním buzení. Během nízké části PWM a brzdění jeho výstup klesá i při proudu motorem. Na CS nepřidávej kondenzátor. Chyba /FLT a časový limit poskytují provozní diagnostiku. Samostatně dimenzuj ochranu vinutí a kabelu před přetížením. Výchozí limit driveru kolem 30 A nemůže chránit motor s blokovacím proudem kolem 3 A ani omezit sílu na hraně.

## Topení vajec a alarm

- Topení: jištěné **+12 V → VIN DFR0457**. Na **VOUT → NC DC termostat výkonu → jednorázová DC tepelná pojistka → kladný vodič fólie**. Druhý vodič fólie a svorku GND modulu veď na 12V OUT−. Řídicí konektor podle označení modulu: SIG na GPIO16, řídicí VCC na 3V3 a řídicí GND na GND ESP32. VOUT je spínaná kladná větev.
- Stavový NC kontakt GPIO17 zapoj samostatně. Výkonový NC termostat a tepelná pojistka musejí odpojit fólii při trvale sepnutém MOSFETu. Obě součásti vyber s doloženým DC vypínacím proudem s rezervou nad 1,67 A jmenovitého proudu fólie. Prahy a umístění ochran urči podle teploty skutečné sestavy. Fólii upevni na kov podle návodu výrobce, bez možnosti styku s dřevem, vejci nebo zvířaty.
- Alarm RUT241: jištěné 12 V na Power a Ground. U PC817 připoj GPIO27 → 470 Ω → anoda LED, katoda → GND ESP32. Na straně RUT241 kolektor → Input, emitor → Ground, z Input na Power tah k 12 V. Při zvoleném 22 kΩ ověř skutečnou úroveň s vypnutým optočlenem. RUT241 požaduje 0–6 V pro LOW a 8 V až do svého napájecího napětí pro HIGH. Pokud 22 kΩ nedosáhne HIGH, zvol ověřené rozhraní či hodnotu podle garantovaného proudu a tolerance optočlenu. Router musí přečíst LOW při zdravém ESP32 a HIGH při alarmu, přerušeném signálu nebo vypnutém ESP32. Při společném výpadku napájení se místní SMS neodešle.

## Údaje pro definitivní montáž

| Vstup | Co doplnit do montážního rozpisu |
|---|---|
| Štítky panelů, baterie a BMS, minimální venkovní teplota | Napětí a proudy FVE, nastavení MPPT, zimní bilance a ochrana nabíjení v mrazu. |
| Trasy, délky, uložení a skutečné proudy | Průřezy, typy kabelů, jištění včetně vstupů měničů, vypínací schopnosti a DC jmenovitá napětí. |
| Hmotnost dvířek, zdvih, rychlost a typ hrany | Motor a převod, uchycení, typ hardwarové smyčky, výkonový kontakt, reset, ruční uvolnění a omezení síly. |
| Rozvaděč tepla, umístění fólie a kontaktů | DC hodnoty termostatu a pojistky, umístění nezávislých ochran, povrchové teploty. |
| Rozváděč, srážky a kondenzace | Rozměry, podkladní deska, průchodky, krytí a servisní přístup. |

## Podklady výrobců

- [Pololu G2 24v13 #2992, svorky, /SLP, CS a napájení](https://www.pololu.com/product/2992)
- [Pololu #4685, hodnoty převodového motoru](https://www.pololu.com/product/4685/specs)
- [DFRobot DFR0457, parametry a pinout](https://wiki.dfrobot.com/dfr0457/)
- [DFRobot DFR0457, schéma](https://dfimg.dfrobot.com/wiki/17549/DFR0457_mosfet-power-control-module_schematics_V1.0.pdf)
- [Teltonika RUT241, parametry digitálního vstupu](https://wiki.teltonika-networks.com/view/RUT241_Input/Output)
- [Mean Well DDR-30](https://www.meanwell.com/Upload/PDF/DDR-30/DDR-30-SPEC.PDF)
- [Mean Well DDR-60](https://www.meanwell.com/Upload/PDF/DDR-60/DDR-60-SPEC.PDF)
- [Victron MPPT 150/35](https://www.victronenergy.com/media/pg/Manual_SmartSolar_MPPT_150-35__150-45/en/technical-specifications.html)
