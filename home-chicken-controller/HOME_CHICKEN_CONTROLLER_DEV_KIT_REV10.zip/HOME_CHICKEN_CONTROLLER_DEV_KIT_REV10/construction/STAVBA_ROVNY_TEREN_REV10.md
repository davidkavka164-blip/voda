# HOME CHICKEN CONTROLLER — STAVBA REV10 / ROVNÝ TERÉN

**Platné zadání:** pro 10 slepic; technický návrh na rovný terén, skutečnou polohu si zajistí uživatel. Vnější pracovní půdorys **2400 × 2400 mm** (hrubých 5,76 m²), zvýšená podlaha **300–400 mm**, vstup pro člověka, tři hnízda, sběr vajec dostupný zvenku, technická skříň mimo vnitřní prostor slepic. Dvě PV 420 Wp mohou být na střeše nebo samostatně — kotvení ještě není povolené k výrobě.

## Rozmístění a pracovní rozměry
- Vnější stěny: pracovní vnější půdorys rámu 2400 × 2400 mm; po opláštění upravit přesné velikosti otvorů.
- Podlaha: 20mm voděodolná překližka na nosnících, navrch vyjímatelná a omyvatelná povrchová vrstva; bez odkrytých spár a ostrých hran.
- Nosný rám: trámky 100×100 mm, pod ním **9 bodových podpor** (rastr 3×3) na rovném pevném podkladu; patky projektant upřesní podle podloží a zatížení.
- Hřady: dvě délky ~1500 mm mimo oblast hnízd a napáječky, s možností vyjmutí.
- Snášková hnízda: světlá šířka 3×360 mm, oddělení 4×20 mm -> 1160 mm bez dalšího opláštění; rozběhový sklon 12 % a 30 testů odvalování dle REV05.
- Sběrná kazeta: celková pracovní šířka modulu ~1160 mm; světlý prostor kazety urči podle bočnic a odvalu, dostupná výklopem zvenku. Izolaci 40mm testovat dle zimního tepelného modelu; nevyhřívat celý kurník.
- Předběžný průlez slepic 300×400 mm; konečné rozměry závisí na plemeni a dvířkovém mechanismu.
- Větrání: dvě nastavitelné chráněné větrací štěrbiny pod stříškou naproti sobě, s pletivem proti predátorům; nesmí vytvářet průvan v úrovni hřadů.
- Střecha: pultová s přesahy (pracovní footprint ~2900×2900 mm), minimální sklon dle zvolené krytiny. **Nosnost FVE, sněhu a větru nemáme staticky doloženou.**

## Materiál z vlastních zásob
Trámky 100×100 mm pro hlavní nosné prvky; desky 25 mm na opláštění; desky 50 mm na detaily; latě 60×40 mm na pomocné rámy; voděodolná překližka 20 mm na podlahu a hnízda. Používat pro návrh a inventuru REV06. **Zákaz finálního rozřezu nosných trámků**, dokud nejsou známy počty/délky a ověřena statika.

## Postup montáže

1. Vyznač půdorys, obslužnou trasu, prostor pro otevírání servisních dveří a prostor pro vysunutí kazety. Zkontroluj odvodnění, terénní výšku, přístup ráno i v zimě a zastínění panelů. Připrav návrh patek, kotvení a střechy podle skutečného podloží, větru, sněhu a dřeva. Teprve s těmito údaji uzavři kusovník nosných prvků.
2. Po výběru patek osadíš nosný rám podle schváleného návrhu. Před opláštěním změř obě úhlopříčky rámu, zkontroluj rovinu a vyzkoušej přístup k ručnímu uvolnění dvířek. Rozměr 2400 × 2400 mm odpovídá teoretické úhlopříčce přibližně 3394 mm. Potřebnou toleranci určuje provedení rámu.
3. Namontuj podlahu, stěny, chráněné větrání, střechu a servisní dveře. Dřevěné plochy chraň před zemní vlhkostí. Zvenčí ponech kontrolovatelné kotvy a přístup k obsluze. Vnitřní stranu zbav odkrytých mezer a hran; napevno připevni ochranu proti predátorům.
4. Nejdřív zhotov zkušební modul jednoho hnízda, ověř odval a zpřístupni kazetu zvenku. Pracovní sklon 12 % znamená pokles 12 mm na 100 mm délky. Po zkoušce odvalu a čištění dimenzuj všechny tři moduly. Zajisti polohu kazety, aby se při vyjmutí nemohla zřítit nebo rozdrtit vejce.
5. Postav zkušební dvířka a namontuj vodítka, dorazy, kryt pohyblivých částí, ruční uvolnění a omezení síly. Změř zdvih i sílu po celé dráze v obou směrech. Z těchto měření a převodu/bubnu vyber pohon, spojku a polohu koncových spínačů. Fyzický E‑STOP umísti na dostupné místo mimo dráhu dvířek.
6. Elektroniku a přístupový kabel ulož mimo dosah slepic. Vedení chraň před mechanickým poškozením, kondenzací a průnikem vody. Zachovej přístup k jištění a odpojovačům. Fólii montuj na nehořlavou roznášecí plochu s nezávislou tepelnou ochranou. Poté přejdi na [elektrický návod](../docs/ZAPOJENI_A_BEZPECNOST_REV10.md) a [přejímku](../docs/NAVOD_ZKOUSEK_REV10.md).

## Co uzavřít pro konkrétní pozemek

| Položka | Zaznamenej před objednáním nebo montáží |
| --- | --- |
| Patky, rám, střecha | Podloží, kotvení, skutečné profily a délky, zatížení sněhem a větrem, zvolenou krytinu a umístění panelů. |
| Dvířka | Čistý otvor, zdvih, sílu za nepříznivých podmínek, zvolený mechanismus, nezávislý omezovač síly a přístup k ručnímu uvolnění. |
| Rozvaděč | Rozmístění prvků, délku a uložení každé větve, průřezy, jištění podle DC parametrů a samostatné odpojení výkonu. |
| FVE | Typ a štítek panelů, nejnižší návrhovou teplotu, Voc za mrazu, zastínění, parametry baterie a BMS. |

Rozměry jsou podkladem pro rozmístění. Konečný řezný plán a kotvení vycházejí z ověření na konkrétním pozemku.
