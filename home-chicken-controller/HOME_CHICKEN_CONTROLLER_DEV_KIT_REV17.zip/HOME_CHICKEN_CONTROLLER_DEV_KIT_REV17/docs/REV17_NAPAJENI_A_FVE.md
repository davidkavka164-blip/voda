# Napájení, nabíjení a zimní rezerva

## Dvířka

Pro základní instalaci stačí výrobcem předepsané **4× AA** v jednotce Kerbl. Dvířka tak mají vlastní napájení při poruše centrálního DC rozvodu nebo vypnutí ESP32. Po výměně článků znovu nastav hodiny a datum Kerbl. Zahrň výměnu článků do pravidelné osobní kontroly.

Pro delší provoz z vnější baterie výrobce nabízí **70557 pro samostatnou nominální 12V automobilovou nebo ohradníkovou baterii**. Použij originální jištěný přívod a postup výrobce. Pro tuto variantu počítej s odděleným uložením baterie, údržbou a vlastním nabíjením podle výrobce baterie. Souběh 70557 s vloženými AA a použití generického DC/DC místo vnější baterie jsou podmíněné potvrzením Kerbl. V návrhu základní sestavy se s nimi nepočítá. Hlavních 24 V vede pouze do společného DC rozvodu, nikoli do konektoru Kerbl. [Návod kabelu 70557](https://www.kerbl.co.uk/ftp/product-doc/176617.pdf) · [Kerbl 70546](https://www.kerbl.com/en/product/automatic-chicken-door-complete-set-16242)

## Hlavní 24V systém

1. Zapiš typ a hodnoty skutečných panelů, limity MPPT, předpokládanou nejnižší teplotu a parametry baterie. Při dvou shodných panelech v sérii počítej `Voc_zima = 2 × Voc_STC × (1 + |βVoc| × (25 − Tmin))`. Koeficient v %/°C nejdřív vyděl 100. Při navržené rezervě musí být zimní Voc v limitech regulátoru, FV odpojovače i kabeláže. U Victron 150/35 platí strop 150 V na FV vstupu. Porovnej také zkratový proud s mezí vstupu.
2. V návrhu hlavní baterie počítej s LiFePO₄ a BMS s ochranou článků proti přepětí a nízké teplotě při nabíjení. Vyplň z dokumentace vybraného kusu povolené nabíjecí napětí, udržovací nastavení, maximální nabíjecí proud a teplotu povolení nabíjení. Regulátor nastav na hodnoty pro tuto baterii. Vypni ekvalizaci. BMS má působit jako nezávislá ochrana, při běžném nabíjení reguluje MPPT. Funkce vypínání nabíjení podle teploty v MPPT vyžaduje dostupnou teplotu baterie z kompatibilního měření.
3. Zvol DC odpojovače, vypínací schopnosti pojistek, délky a průřezy podle skutečných větví. Hlavní jištění je u baterie. Vstup každého měniče, MPPT a jeho příslušné větve mají vlastní jištění. Pro pořadí připojování a odpojování použij návod vybraného MPPT.
4. Podklady pro zvažovanou LiThink 25,6 V / 100 Ah uvádějí odlišné hodnoty. Produktová stránka uvádí pro samoohřev 8 A, zatímco tabulka výrobního návodu na str. 5 uvádí 10 A. Do zimního návrhu proto počítej do potvrzení dodané varianty s **10 A**, tedy jmenovitě **256 W** na bateriové straně ještě před souběžnými zátěžemi a ztrátami. Slabé zimní oslunění může dodávat méně. Ověř, že MPPT umožní výrobcem povolený předehřev a že BMS při něm blokuje nabíjení studených článků. Zachovej ochranu článků a potvrď postup pro konkrétní baterii. [Produktová stránka LiThink](https://lithink.de/products/24v-100ah-lifepo4-batterie-bluetooth-heizung-trolling-wohnmobil-solar) · [Návod LiThink, str. 5–6](https://cdn.shopify.com/s/files/1/0759/1844/2717/files/24V_100Ah_Bluetooth_Product_Manual_EN.pdf.pdf?v=1761285720)
5. Při přejímce odečti nabíjecí napětí a proud ve VictronConnect a porovnej je s limity baterie. Dostupný výkon panelů se po omezení nabíjení dále nemusí odvádět. Funkci přerušení nabíjení za mrazu ověř postupem výrobce baterie. ESP32 používá napětí pro výstupy a signalizaci.

[Technické údaje Victron 150/35](https://www.victronenergy.com/media/pg/Manual_SmartSolar_MPPT_150-35__150-45/en/technical-specifications.html) · [Nastavení Victron MPPT](https://www.victronenergy.com/media/pg/Manual_SmartSolar_MPPT_150-35__150-45/en/configuration-and-settings.html)

## Bilance pro měření po montáži

| Větev | Co změřit a zapsat |
| --- | --- |
| ESP32, RTC, sondy a RUT241 | Průměrný příkon včetně měničů při připojeném LTE i při hledání sítě. |
| Kamera | Napájení běží ve výchozím okně 07:00–16:00. Pracovní údaj 180 mA při 5 V je 0,9 W a za devět hodin přibližně 8,1 Wh před ztrátami měniče. Spínač Pololu #2810 přidá přibližně 0,05 Wh za devět hodin. Samostatně připočti špičky při startu a focení. Změř také skutečný odběr 5V větve po vypnutí. |
| Ohřev vajec | Wh na hlavní baterii za celý chladný den. Fólie 20 W může za 9 h spotřebovat 180 Wh na 12V větvi, k tomu ztráta měniče. |
| BMS, temperování, relé a další spotřeba | Klidový příkon měničů, zimní spotřeba temperování a provozní spotřeba spínacího prvku kamery. Pro mrazový den porovnej poloviční a celodenní výkon v povoleném devítihodinovém okně fólie. |
| Dvířka Kerbl | U 4× AA sleduj odděleně výdrž článků, teplotu a počet cyklů. Vnější baterii měř na její větvi. |

Katalogový příkon kamery je vstup pro návrh. Konečná bilance používá skutečné hodnoty na straně baterie. [Specifikace ESP32‑CAM, § 3](https://d229kd5ey79jzj.cloudfront.net/1205/ESP32-CAM%20Product%20Specification.pdf) · [Specifikace Pololu #2810](https://www.pololu.com/product/2810)

Pro zvolených `N` dnů bez FV musí použitelná energie hlavní baterie v nejnižší uvažované teplotě pokrýt alespoň `N × naměřené Wh/den` a domluvenou rezervu. Nominální 25,6 V × 100 Ah znamená 2 560 Wh před zohledněním provozního okna, chladu, stáří a rezervy. Spotřebu a zimní dobíjení zapiš do přejímky.
