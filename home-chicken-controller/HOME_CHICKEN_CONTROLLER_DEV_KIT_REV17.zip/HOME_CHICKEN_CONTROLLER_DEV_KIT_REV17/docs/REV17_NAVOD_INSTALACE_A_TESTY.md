# Instalace firmware a přejímka po montáži

Před montáží připrav zdrojové soubory, přesný nákupní seznam, kabelové trasy, hodnoty jištění a podklady pro umístění dvířek. Po montáži se zkouší po jednotlivých větvích. Na začátku nech odpojené výkonové větve, napájecí kabel kamery i kontakty Kerbl a proveď kontrolu bez zvířat.

## Zdrojové soubory a překlad

1. Rozbal celý ZIP. Otevři `firmware/HCC_CONTROLLER_REV17/HCC_CONTROLLER_REV17.ino` v Arduino IDE. Hlavičky a `secrets.h` ponech ve složce programu. Při přechodu z REV16 může uložené místní povolení zůstat platné. Před přeflashováním fyzicky odpoj připojené výstupy.
2. Pro řídicí desku vyber **ESP32 Dev Module**, pro kameru **AI Thinker ESP32-CAM**. Použij Espressif ESP32 core **1.0.6**, OneWire **2.3.8** a DallasTemperature **3.9.0**. Kamerový program je samostatně v `firmware/HCC_CAM_REV11/HCC_CAM_REV11.ino`.
3. Nastav vlastní přístupové údaje v řídicím `secrets.h` a samostatně v kamerovém programu. Zvol heslo webu i servisní Wi‑Fi. Se vzorovým heslem zůstává příslušná služba vypnutá. Pro sériový monitor nastav 115200 Bd. Pro nahrávání vyber port a rychlost odpovídající desce.
4. Nech `HCC_KERBL_OUTPUTS_ENABLED=0`, `HCC_EGG_HEATER_OUTPUTS_ENABLED=0`, `HCC_BATTERY_ADC_CALIBRATED=0` a `HCC_ALLOW_WEB_KERBL_COMMANDS=0`. V této variantě první nahrání prováděj bez připojených zátěží.
5. Připoj se lokálně k `HCC-SERVICE-REV17` a otevři `http://192.168.4.1/` nebo použij adresu z DHCP RUT241. V `/status` ověř `rev=16`, vypnuté relé a ohřev, `kerbl_commissioned=false` a `heater_commissioned=false`. Bez připojených smyček je poruchový stav očekávaný. Po zapojení kontaktů poruchu potvrď při stabilním konci dráhy.
6. Pro standardní přeložení z terminálu použij příkazy níže. Význam hesel, nahrání ESP32‑CAM, RTC, rezervaci adres, WireGuard a zkoušky SMS a nastavení denního provozu kamery rozepisuje [síťový návod](REV17_LTE_WIREGUARD_KAMERA.md).

```sh
arduino-cli compile --fqbn esp32:esp32:esp32 firmware/HCC_CONTROLLER_REV17
arduino-cli compile --fqbn esp32:esp32:esp32cam firmware/HCC_CAM_REV11
```

## První zapnutí po montáži bez povelových kontaktů a topné fólie

1. Bez napětí zkontroluj polaritu, jištění, svorky a ochrany. Zapni jednotlivé větve a změř 5 V, 12 V a nízké signálové úrovně. DC odpojovače a fólii připojuj podle elektrického návodu po jednotlivých úsecích.
2. Ověř GPIO32/33 v obou polohách i při simulaci konfliktu a rozpojení vodiče. Ověř také reakci na oba skutečné NC kontakty GPIO18/19 podle elektrického návodu. Jejich rozpojení zablokuje nové impulzy. Po návratu kontaktů do provozní polohy potvrď případnou poruchu v místním webu při známé koncové poloze. Bezpečné znehybnění řídicí jednotky Kerbl řeší její vlastní fyzické odpojení a zajištění dvířek.
3. Ověř dělič 120 kΩ / 10 kΩ. Na straně baterie jsou přibližně 21–30 V, na GPIO34 za děličem přibližně 1,62–2,31 V. Při výchozí korekci 1,000 porovnej údaj `battery_voltage_estimate` s multimetrem u vstupu, zejména kolem 23,8 V a 25,0 V. Po měření nastav `HCC_BATTERY_ADC_CORRECTION` a ověř alespoň dva body. Poté lze potvrdit `HCC_BATTERY_ADC_CALIBRATED=1`. Napětí baterie patří na vstup děliče.
4. Přiřaď DS18B20 ve `/sensors` podle skutečného umístění a ověř reakci na odpojení. Platný čas nastav synchronizací NTP nebo při prvním spuštění z telefonu s nastaveným časem. Po restartu bez internetu má DS3231 obnovit hodiny.

## Samostatná větev dvířek

1. Dokonči a ověř chod Kerbl z panelu na jeho vlastním bateriovém napájení. Nastav hodiny, AUTO a případně AC ON. Kontakty k ESP32 zatím nech odpojené.
2. S odpojeným Kerbl a fólií povol pouze `HCC_KERBL_OUTPUTS_ENABLED=1` a potvrzenou kalibraci. Po nahrání uvolni obě místní tlačítka. S platným napětím, funkční pamětí, zdravými NC smyčkami a stabilním koncem dráhy podrž obě tlačítka 5 s. Sleduj `kerbl_commissioned=true`. Pro novou přejímku po přechodu z REV16 nejprve zruš uložené povolení podle prvního kroku výše.
3. K místnímu povelu stiskni a uvolni jedno tlačítko krátce, nejdéle do 2 s podle firmwaru. Ověř správný výstup cca 350 ms, neaktivní protější kontakt a vypnuté kontakty při startu, resetu, vypnutí 5 V a pouze jednom napájeném zařízení. Ověř zapojení prioritních přepínacích kontaktů podle elektrického návodu a stálé stavy i přechody kontaktů bez náhodného povelu. Po odpojení ESP ověř, že Kerbl sám neobdrží povel.
4. Připoj kontakty až po zkoušce s měřením a při odpojeném napájení. Ověř skutečný rozběh, potvrzení až cílovým snímačem, 60s limit a žádné samočinné opakování. Při zablokování zjišťuj příčinu místně. Po povelu ověř MANUAL, místní návrat do AUTO a další denní cyklus s AC ON.
5. Proveď 30 cyklů otevření a zavření bez zvířat, včetně zkoušky chování Kerbl podle návodu při překážce, výpadku ESP/routeru a bezpečného odpojení všech zdrojů Kerbl. Zkontroluj funkci při běžném pohybu bez falešného alarmu. Případné vzdálené povely povol v konfiguraci až po zkoušce návratu do AUTO.

## Samostatná větev kamery a alarm dohledu

1. Zkontroluj oddělené jištění 5V větve kamery, společný GND a spínání plusového vodiče. Nabootuj řídicí ESP32 s odpojenou kamerou a ověř, že výstup spínače je bez napětí před vyhodnocením platných hodin. Při ztrátě napájení řídicí desky má spínací prvek rozepnout.
2. Zvol kratší zkušební okno obsahující aktuální čas a ověř napájení kamery, vyžádanou fotografii a následné skutečné vypnutí na konci okna. Ověř, že napětí na zatíženém 5V vstupu kamery zůstává v mezích při Wi‑Fi startu a pořizování snímku. Pro zkoušku odpojení předpokládej také možné napájení z USB programátoru a zamez jeho souběhu s 5V větví. Po nahrání odpoj i datové vodiče UART programátoru.
3. Ověř stejné chování po restartu, při neplatných hodinách a bez LTE s platným časem z DS3231. Stav `camera_power_on` značí povel k napájení. Dostupný snímek se ověřuje zvlášť, až kamera po zapnutí naváže Wi‑Fi. Vrať denní okno na 07:00–16:00, případně na zvolenou skutečnou dobu. Je-li potřeba noční snímek, dočasně přesuň okno v místním webu nebo přes VPN.
4. Po nastavení hodin Kerbl ověř [dohled vynechaného cyklu](REV17_KERBL_OVLADANI.md) a jeho časová okna. Zkontroluj skutečný důvod v `/status`. Dohled se aktivuje až volbou uživatele a může běžet i s odpojenými povelovými relé.

## Samostatná větev ohřevu a závěr

1. Ověř DC jmenovité hodnoty termostatu a jednorázové tepelné pojistky. Zkontroluj kovový rozvod tepla a oddělenou stavovou NC smyčku GPIO17. Výkonový termostat a pojistka musejí samostatně odpojit výkon při trvale sepnutém MOSFETu.
2. Ponech fólii fyzicky odpojenou a zvol `HCC_EGG_HEATER_OUTPUTS_ENABLED=1`. Pro samostatný test mohou být relé Kerbl zakázaná. S platným časem, kalibrovanou baterií nad mezí, platným čidlem vajec a zdravým tepelným kontaktem uvolni a znovu podrž obě místní tlačítka 5 s. Sleduj `heater_commissioned=true`. Nejprve ověř GPIO na testovací zátěži. Po zkoušce samostatných větví nastav oba příslušné přepínače na 1 a nahraj finální konfiguraci. V `/status` ověř místní povolení obou větví. Případné chybějící povolení proveď podržením obou tlačítek podle podmínek uvedených výše. Až potom připoj ověřené zátěže odděleně.
3. Zkus servisní zámek pro povelová relé a topení, odpojené čidlo, ztrátu času a pokles napětí. Zkouška má potvrdit vypnutí ohřevu nebo blokaci nových povelů, podle příslušné větve. Pokud web hlásí problém s uložením zámku, servisuj s fyzicky odpojenými zdroji. Při vypnutí ESP mohou dvířka dál pracovat z vlastního napájení.
4. Nastav MPPT a BMS podle [napájecího návodu](REV17_NAPAJENI_A_FVE.md). Ověř vzdálený dohled a kameru z mobilních dat, SMS při skutečném alarmu a funkci po obnovení LTE. Provozuj celek několik dní bez zvířat, změř Wh/den a vyplň [přejímací protokol](REV17_ZKUSEBNI_PROTOKOL.csv).
