# Ověření REV17

## Překlad a testy

| Konfigurace | Cíl | Flash | Globální paměť |
| --- | --- | ---: | ---: |
| Řídicí firmware s distribuovaným nastavením | ESP32 Dev Module | 798 622 B | 39 992 B |
| Řídicí firmware s povolenými relé, topením, potvrzenou kalibrací a webovými povely | ESP32 Dev Module | 800 698 B | 40 000 B |
| Kamerový firmware | AI Thinker ESP32‑CAM | 871 486 B | 43 644 B |

Sestaveno na Linuxu pomocí Arduino CLI 1.6.0, ESP32 core 1.0.6, OneWire 2.3.8 a DallasTemperature 3.9.0. Zkušební aktivní nastavení sloužilo k překladu. Distribuovaný firmware má relé Kerbl, ohřev, potvrzení kalibrace a webové povely pohybu vypnuté. Časování kamery je povolené s výchozím oknem 07:00–16:00 a dohled termínů dvířek se zapíná až po zadání skutečných mezí.

Prošly čtyři hostitelské testovací sady. Ověřují stavový automat Kerbl, dvojstisk a místní povolení, ohřev, RTC a nově dohled termínů a časování kamery. Nové testy pokrývají obě ověřené krajní polohy, přechodová okna, neplatné hodiny, kameru během všech 1 440 minut dne, okno přes půlnoc a odmítnutí neplatných nastavení.

## Rozhraní a podklady

- Kerbl 70546 s vlastními AA, alternativně 70557 se samostatným nominálním 12V akumulátorem dle výrobce. Dohled ESP32 hlásí vynechaný cyklus podle polohy bez vydání povelu k pohybu.
- Dvě relé Drátek 1517435132 pro Kerbl. Dva spínače NKK MN12SD3G01 doplňují hardwarově zapojené vstupy GPIO18 a GPIO19 pro blokaci povelů ESP32. Přepínače patří do výkresu kabeláže a montážního plánu.
- GPIO23 ovládá Pololu #2810 v kladné 5V větvi kamery. Zkouška po montáži zahrnuje skutečný start kamery, vypnutí na konci okna, prázdnou větev při neplatném čase a ověření bez zpětného napájení z USB–UART.
- Excel obsahuje běžný a mrazový scénář, přepočet kamery z doby zapnutí a podmínky pro samoohřev. Kvůli rozdílu mezi webem LiThink a tabulkou v návodu používá plán pro samoohřev 10 A, dokud se nepotvrdí dodaná varianta. Modelové Wh i obchodní typy ověř podle konkrétních dílů.
- Návod pro RUT241 uvádí minimální kompatibilní RutOS u aktualizované hardwarové revize a zkoušku alarmu přetrvávajícího po obnově mobilní sítě.
- Montážní PDF obsahuje aktuální výkresy a všech 28 položek [přejímacího protokolu](REV17_ZKUSEBNI_PROTOKOL.csv).

Fyzické sepnutí kontaktů, tepelná ochrana, chování baterie v mrazu a dostupnost LTE se ověřují podle [přejímky po montáži](REV17_NAVOD_INSTALACE_A_TESTY.md). Před montáží uzavři hodnoty jištění, kotvení, konkrétní tepelné ochrany a způsob zajištění a odpojení dvířek pro servis.
