# REV17 – instalace LTE, WireGuard, kamery a SMS

RUT241 v kurníku propojuje místní Wi‑Fi s LTE. Automatiku dvířek řídí samostatný modul Kerbl 70550. ESP32 sleduje polohu a očekávaný čas pohybu dvířek, řídí ohřev vajec, spíná napájení kamery a poskytuje web. Telefon se přes WireGuard připojuje k webu a volitelné kameře. Pro zprovoznění připojení potřebuješ aktivní SIM, dosažitelný uzel WireGuard a jeho adresu. Výstupy uváděj do provozu podle instalačního návodu. Nastavení LTE ani VPN je samo nepovolí.

## RUT241, Wi‑Fi a adresa zařízení

U RUT241 vyráběných od druhého čtvrtletí 2025 je pro aktualizovanou hardwarovou revizi minimem `RUT2M_R_00.07.10.4`. Se starším firmwarem na této revizi nefunguje digitální vstup a výstup. Použij aktuální stabilní RutOS schválený výrobcem pro svůj RUT241. Před montáží ověř verzi ve webu routeru a dostupnost položek **Input (3)** a **Event Juggler**. Při aktualizaci zachovej správný model zařízení, zálohuj nastavení a zajisti nepřerušované napájení. [Oznámení změny hardwaru RUT241](https://wiki.teltonika-networks.com/view/RUT241_Product_Change_Notifications#2025.03.25:_New_Hardware_Revision) · [Oficiální firmware RUT241](https://wiki.teltonika-networks.com/view/RUT241_Firmware_Downloads)

1. Vlož SIM s daty a odchozími SMS. Připoj LTE antény podle příručky routeru, zapoj počítač do LAN a dokonči úvodní nastavení routeru. Změň heslo správce a nastav zabezpečenou 2,4GHz Wi‑Fi s WPA2‑PSK/AES pro obě ESP32.
2. V části **Network → Mobile** zkontroluj registraci v LTE a datové připojení. Pokud automatický APN nefunguje, nastav hodnotu operátora. Ověř datové připojení z LAN. [Nastavení mobilní sítě RUT241](https://wiki.teltonika-networks.com/view/RUT241_Mobile)
3. Zvol podsíť LAN kurníku, která se nepřekrývá s domácí ani jinou sítí, ze které se připojuješ. Příklad níže používá LAN `192.168.64.0/24` a router `192.168.64.1`. Po změně LAN se znovu připoj k routeru na nové adrese.
4. V `secrets.h` řídicí desky vyplň `HCC_WIFI_SSID`, `HCC_WIFI_PASS`, `HCC_WEB_USER` a vlastní `HCC_WEB_PASS`. U kamery vyplň `WIFI_SSID`, `WIFI_PASS`, `WEB_USER` a vlastní `WEB_PASS` ve zdrojovém kódu kamerového programu. Přístupové údaje ukládej lokálně, mimo sdílené archivy a repozitáře.
5. Po prvním připojení vytvoř v RUT241 **DHCP → Static Leases** rezervace podle MAC adresy Wi‑Fi stanice. Přidělené adresy najdeš v seznamu klientů RUT241 a v sériovém výpisu ESP32 na 115200 Bd. Například řídicí ESP32 `192.168.64.20` a kamera `192.168.64.21`. Rezervaci kamery vytvoř v době, kdy je napájená. Ověř zachování adres po restartu routeru a obou desek i po dalším cyklu napájení kamery. Do `HCC_CAMERA_LOCAL_URL` můžeš zadat `http://192.168.64.21/jpg`. [Rezervace DHCP RUT241](https://wiki.teltonika-networks.com/view/RUT241_DHCP)
6. Z místní LAN otevři `http://192.168.64.20/status`. V aktivním okně kamery po jejím připojení k Wi‑Fi otevři `http://192.168.64.21/jpg`. Obě zařízení mají vyžádat přihlášení. U řídicí desky otevři i hlavní stránku a ověř, že průběžně ukazuje čas posledního načtení. Ve webu routeru vypni přesměrování veřejných portů na obě desky.

Pro servis bez routeru nastav jedinečná hesla `HCC_AP_PASS` a `HCC_WEB_PASS`, připoj se k síti uvedené v `HCC_AP_SSID` a otevři `http://192.168.4.1/`. Pokud telefon hlásí Wi‑Fi bez internetu, ponech ji připojenou. Pro běžný provoz lze ponechat výchozí zástupný text `HCC_AP_PASS`, čímž AP zůstane vypnutý. Samotný web přes RUT241 vyžaduje vlastní `HCC_WEB_PASS`.

### Hodiny při zprovoznění

S dostupným LTE nech ESP32 získat čas přes NTP. K synchronizaci musí mít deska přístup k DNS a NTP. Ve `/events` zkontroluj `NTP time saved to DS3231` a ve `/status` ověř `clock_valid=true`. Bez internetu lze na hlavní stránce při neplatném čase použít **Nastavit hodiny podle telefonu**. Do získání platného času zůstane kamera vypnutá. Nejprve zkontroluj čas na telefonu a připojení modulu DS3231. ESP32 uloží UTC do DS3231 a zobrazuje místní čas pro ČR. Ověř jeho zachování po restartu bez LTE a že ESP32 znovu hlásí `clock_valid=true`. Čas dvířek nastavuj zvlášť na Kerbl.

### Nahrání a ověření volitelné kamery

Pro ESP32-CAM AI Thinker vyber odpovídající typ desky v Arduino IDE. U externího USB–UART použij logiku 3,3 V, společnou zem a překřížené TX/RX. Pro samotné programování odpoj kameru od instalované spínané větve a použij samostatný stabilní zdroj 5 V s rezervou alespoň 1 A na vstupu 5 V. Při nahrávání spoj GPIO0 s GND a proveď reset. Poté spoj odstraň, resetuj desku a sleduj sériový výpis na 115200 Bd. U hotového programátoru se řiď jeho návodem. Před instalací odpoj programátor i pomocný zdroj.

V instalaci vede napájení kamery ze spínané jištěné větve 5 V podle elektrického schématu. GPIO23 hlavní ESP32 ovládá spínací prvek. Kamera má nastavitelné časové okno v místním čase. Výchozí je **07:00–16:00**, v poledne je tedy při platném čase uvnitř okna. Mimo okno, při neplatných hodinách a při ztrátě napájení hlavní ESP32 má být kamerová větev vypnutá. Ověř to při přejímce měřením. Funkci při odpojení hlavní desky ověř bez připojeného USB–UART či druhého zdroje. Po sepnutí kamery počkej na start a rezervovanou IP z DHCP.

Na hlavním webu hledej nastavení **Dohled dvířek a napájení kamery**. `/status` ukazuje povel `camera_power_on`. Zkus `/jpg` v LAN a potom přes WireGuard během aktivního okna. Pokud hlavní web odpovídá a kamera je mimo okno vypnutá, je její nedostupnost očekávaná. Během okna při neúspěchu zkontroluj platný čas, nastavené okno, spínaných 5 V u kamery, sériový výpis a DHCP rezervaci. Ověř, že se po restartu RUT241 ve stejném okně kamera znovu připojí a vydá čerstvý snímek. Řídicí web a tunel pro dohled na době napájení kamery nezávisí.

## WireGuard přes dosažitelný uzel

RUT241 i telefon navazují spojení k jednomu uzlu WireGuard s veřejně dosažitelným UDP portem, například k domácímu routeru nebo jinému spravovanému uzlu. Tento směr funguje i za mobilním CGNAT. Pokud je doma také CGNAT a UDP port z internetu není dosažitelný, použij dosažitelný uzel. Pro připojení je potřeba jeho veřejná IP nebo DNS jméno a UDP port. Na WAN zpřístupni jen zvolený UDP port WireGuard na uzlu. Weby ESP32 ponech v místní síti a pro dohled ve VPN. Správu RUT241 ponech v místní síti. Při zapínání kamery se pravidla VPN nemění. [WireGuard na RUT241](https://wiki.teltonika-networks.com/view/RUT241_VPN#WireGuard)

Každé zařízení má vlastní soukromý klíč. Veřejný klíč uzlu patří do konfigurace RUT241 a telefonu. Uzel má dva peery, z nichž každý má veřejný klíč příslušného zařízení.

| Položka | Příklad hodnoty |
| --- | --- |
| Veřejná adresa uzlu | `<vlastní-dosažitelný-uzel>:51820` |
| Adresa tunelu uzlu | `10.55.241.1/24` |
| Adresa tunelu RUT241 | `10.55.241.2/24` |
| Adresa tunelu telefonu | `10.55.241.3/32` |
| Na uzlu, **AllowedIPs** u peeru RUT241 | `10.55.241.2/32, 192.168.64.20/32, 192.168.64.21/32` |
| Na uzlu, **AllowedIPs** u peeru telefonu | `10.55.241.3/32` |
| Na RUT241, **Allowed IPs** u peeru uzlu | `10.55.241.1/32, 10.55.241.3/32` |
| Na telefonu, **AllowedIPs** u peeru uzlu | `192.168.64.20/32, 192.168.64.21/32` |

Na RUT241 zadej adresu uzlu jako **Endpoint**, zapni **Route Allowed IPs** a nastav **Persistent Keep Alive** na 25 s. Na telefonu nastav stejný endpoint. Na uzlu povol IPv4 forwarding z tunelu zpět do tunelu a ověř směrování adres obou ESP32 přes peer RUT241. Na uzlu i na RUT241 povol průchod pouze z `10.55.241.3` na obě adresy ESP32, TCP 80, a zpět pro navázaná spojení. Na RUT241 pravidlo směřuje ze zóny WireGuard do LAN. Zařízení v kurníku používají jako výchozí bránu RUT241. Jejich adresy musí odpovídat rezervacím DHCP. Když kameru nepoužíváš, vypusť její adresu z povolených tras i pravidel. [Příklad směrování WireGuard](https://wiki.teltonika-networks.com/view/WireGuard_Configuration_Example) · [Firewall RUT241](https://wiki.teltonika-networks.com/view/RUT241_Firewall)

Veřejně dostupný uzel zajišťuje směrování mezi dvěma tunely. HTTP Basic chrání přístup heslem a WireGuard šifruje provoz po cestě mezi klienty a uzlem. K oběma webům proto přistupuj pouze z důvěryhodné LAN nebo přes vlastní důvěryhodný uzel.

## SMS z digitálního vstupu

1. Použij vstup **Input (3)** a referenci GND z RUT241 podle schématu této revize. Nech logiku vstupu bez invertování. Výrobce uvádí LOW 0–6 V a HIGH 8 V až do vlastního napájecího napětí routeru. U RUT241 napájeného 12 V použij pro vstup jeho vlastní 12V větev přes zapojení optočlenu uvedené v elektrickém návodu. Stav musí být při zdravém ESP32 LOW a při rozepnutí signalizace nebo odpojení napájení ESP32 HIGH. V obou stavech změř napětí přímo mezi připojeným vstupem a GND RUT241. Hodnota HIGH musí při zatíženém vstupu dosáhnout alespoň 8 V. Potvrď také stav ve webu routeru. [Digitální vstup RUT241](https://wiki.teltonika-networks.com/view/RUT241_Input/Output)
2. V **Event Juggler** přidej událost typu **I/O** se vstupem **Input (3)** a hranou **Rising**. Přiřaď akci **Send SMS** s číslem příjemce a textem, například `Kurnik: alarm nebo nedostupny radic, zkontroluj stav.` Nastav krátké zpoždění a **Prevent action execution**, pokud chceš odfiltrovat krátké přechody. Konkrétní názvy položek závisejí na RutOS. [Event Juggler RUT241](https://wiki.teltonika-networks.com/view/RUT241_Event_Juggler)
3. Se zapnutým RUT241 vyvolej přechod LOW → HIGH. Zaznamenej, zda a kdy SMS dorazila. Ověř návrat do LOW a doručení při další hraně. Zvlášť ověř restart RUT241 se vstupem už v HIGH. Pro tento případ můžeš použít pravidlo **Boot** s podmínkou **I/O → Input (3) → High**, s prodlevou pro registraci modemu.
4. Ověř výpadek mobilní registrace při napájeném routeru. Vyvolej stav HIGH až při skutečné nedostupnosti SMS a udrž jej i po návratu registrace **bez restartu RUT241**. Vypnutí samotných mobilních dat či APN tuto zkoušku nenahrazuje. Zaznamenej případné doručení, čas a stav vstupu. Pravidlo **Rising** při návratu signálu znovu nespustí akci, pokud vstup zůstane v HIGH. Opakované doručení není zaručené.
5. Volitelně přidej připomenutí **Time + podmínka I/O → Input (3) → High** a akci **Send SMS**. Zvol jediný konkrétní čas, například 12:00 místního času RUT241, a u tohoto pravidla nastav oba údaje, hodinu i minutu. Tím lze při trvajícím HIGH odeslat nejvýše jedno plánované připomenutí za den. Ověř časové pásmo a správný čas routeru. Vyzkoušej doručení při HIGH a bez SMS při LOW. Po návratu sítě připomenutí může zachytit stále aktivní alarm při nejbližším běhu pravidla. Závadu, která mezitím odezněla, ani doručení bez signálu pravidlo nepokrývá. [Nastavení událostí a podmínek v Event Juggler](https://wiki.teltonika-networks.com/view/RUT241_Event_Juggler)
6. GPIO27 signalizuje zdravý stav jako HIGH a sepne optočlen, takže **Input (3)** je LOW. Rozepnutí optočlenu znamená na routeru HIGH a společný alarm. Konkrétní příčinu ověř na hlavním webu nebo na místě. SMS vyžaduje napájený router a fungující mobilní službu. Při výpadku celé napájecí větve kurníku můžeš čerpat jen z nezávislého sledování dostupnosti nebo z osobní kontroly.

## Vzdálený dohled a příkazy Kerbl

Výchozí firmware má `HCC_ALLOW_WEB_KERBL_COMMANDS=0`. Telefon vidí aktuální stav a při zapnuté kameře fotografii. Přímé webové příkazy OTEVŘÍT a ZAVŘÍT jsou ve výchozím nastavení zakázané. Přihlášený uživatel s heslem hlavního webu může měnit podporovaná nastavení ESP32 včetně časových oken. VPN a heslo poskytuj pouze oprávněné obsluze.

Časy očekávaného otevření a zavření v ESP32 slouží k dohledu. Nastav je podle samostatného programu na Kerbl a při změně aktualizuj obě nastavení. Pokud se v očekávaném čase po nastavené toleranci nepotvrdí příslušná poloha, ESP32 zaznamená důvod alarmu. Zkontroluj stav koncových snímačů, čas, napájení a režim na panelu Kerbl. Dohled při zmeškání pohyb sám nespustí. SMS z digitálního vstupu je obecná, důvod zjistíš na webu ESP32.

Případný externí povel z ESP32 přepne Kerbl do MANUAL. Režim Kerbl ESP32 nečte. Na panelu Kerbl lze obnovit automatiku ručně nebo zapnout **AC ON** pro návrat v příštím denním cyklu. Před povolením vzdálených povelů ověř skutečný návrat na namontovaných dvířkách bez zvířat. Servisní zámek blokuje výstupy ESP32. Samotný pohon Kerbl při servisu izoluj podle jeho návodu. [Návod Kerbl v češtině, kapitoly 8.2.2, 8.4.2 a 8.5](https://www.kerbl.co.uk/ftp/product-doc/215237.pdf)

## Přejímka po instalaci

| Zkouška | Očekávaný výsledek |
| --- | --- |
| Telefon, vypnutá Wi‑Fi, zapnutá mobilní data a WireGuard | Na uzlu je aktuální handshake obou peerů. Po přihlášení se načte stav. V aktivním okně po připojení kamery se načte čerstvý snímek. Ověř ho změnou před kamerou. |
| Telefon, vypnutý WireGuard | Soukromé adresy zařízení jsou ze vzdálené sítě nedostupné a veřejné přesměrování TCP 80 se nepoužívá. |
| Restart RUT241 a následný návrat LTE | Tunel se znovu sestaví a řídicí ESP32 získá rezervovanou IP. Kamera získá svou rezervovanou IP, jakmile je napájená a připojená. Telefon načte stav i snímek během aktivního okna. |
| Výpadek LTE | Stav a kamera jsou vzdáleně nedostupné. Kerbl pokračuje podle vlastního programu, pokud má své napájení a je v automatickém režimu. Řízení ohřevu ESP32 vychází z platného času a čidel. Po návratu LTE se vrátí vzdálený přístup. |
| Simulace alarmu a vypnutí ESP32 při napájeném RUT241 | Zdravý stav LOW přejde do HIGH a při dostupné SMS službě se ověří doručení zprávy. |
| Ztráta registrace modemu, alarm zůstane HIGH přes obnovení sítě | Zaznamenej, zda se první zpráva doručila. Pokud používáš připomenutí Time + I/O, ověř jej v dalším zvoleném termínu. |
| Konec okna kamery, neplatný čas, vypnutí hlavní ESP32 | Spínaná větev 5 V zůstane vypnutá. Řídicí web funguje při vypnuté kameře, pokud běží hlavní ESP32. Po návratu do platného okna kamera nastartuje a načte se nový snímek. |
| Běžné otevření a zavření v AUTO | Stav polohy se po dojezdu potvrdí koncovým snímačem. Běžný pohyb podle očekávaného času nevyvolá nový alarm. |
| Bezpečně simulovaný nedojezd v očekávaném termínu | Po toleranci sleduj alarm s důvodem, skutečný stav z kontaktů a nepřítomnost automatického povelu z ESP32. |
| Ověření funkcí dostupných z telefonu | Ověř stav, fotografii a přihlášení. Při `web_kerbl_commands_enabled=false` jsou přímé webové povely OTEVŘÍT a ZAVŘÍT zakázané. |

Při poruše začni místním testem přes LAN. Když funguje LAN a chybí handshake, prověř LTE, adresu a UDP port uzlu, veřejné klíče a keepalive. Když je handshake aktuální a LAN přes tunel neodpovídá, zkontroluj `AllowedIPs`, IP forwarding na uzlu, firewall, DHCP rezervace a výchozí bránu obou desek.
