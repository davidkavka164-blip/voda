#pragma once
// IMPORTANT! Replace all demo credentials before connecting LTE/network.
// Router Wi-Fi SSID + password. Empty SSID = operate service AP only.
#define HCC_WIFI_SSID ""
#define HCC_WIFI_PASS ""
// Unique service AP password (minimum 8 chars).
#define HCC_AP_SSID "HCC-SERVICE-REV17"
#define HCC_AP_PASS "CHANGE_THIS_AP_PASSWORD"
#define HCC_WEB_USER "admin"
#define HCC_WEB_PASS "CHANGE_THIS_WEB_PASSWORD"
#define HCC_CAMERA_LOCAL_URL "" // e.g. http://192.168.10.80/jpg ; VPN/LAN ONLY
