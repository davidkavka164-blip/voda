#pragma once
// HCC REV17 – Kerbl 70546, ESP32 core 1.0.6. SAFE DEFAULTS.
// Set to 1 ONLY after independent relay test, assembly, wiring checks.
#define HCC_KERBL_OUTPUTS_ENABLED 0
// GPIO HIGH turns on the NPN driver. Set the 5 V relay modules to trigger on LOW.
// Use the pull-downs and pull-ups specified in the REV17 wiring table.
#define HCC_KERBL_RELAY_ON HIGH
#define HCC_KERBL_RELAY_OFF LOW
#define HCC_KERBL_PULSE_MS 350UL
#define HCC_KERBL_TRAVEL_TIMEOUT_MS 60000UL
#define HCC_KERBL_COOLDOWN_MS 10000UL
#define HCC_ALLOW_WEB_KERBL_COMMANDS 0 // Enable only after verifying AC ON on actual Kerbl.
#define HCC_EGG_HEATER_INSTALLED 1
// Battery calibration must use actual measured V / ADC-derived V, not guessed.
#define HCC_BATTERY_ADC_CALIBRATED 0
#define HCC_BATTERY_ADC_CORRECTION 1.000f
#define HCC_BATTERY_DIVIDER_RATIO 13.0f // 120k/10k divider, 100nF filter
#define HCC_OPEN_TIME_DEFAULT 450 // legacy setting stored, not used for Kerbl
#define HCC_CLOSE_TIME_DEFAULT 1080 // legacy setting stored, not used for Kerbl
#define HCC_EGG_HEATER_OUTPUTS_ENABLED 0 // separate enable after heater tests
#define HCC_CAMERA_POWER_ENABLED 1 // Camera switchover follows the local clock only.
#define HCC_CAMERA_START_DEFAULT 420 // 07:00
#define HCC_CAMERA_END_DEFAULT 960   // 16:00
#define HCC_DOOR_MORNING_DEFAULT 360 // 06:00
#define HCC_DOOR_OPEN_BY_DEFAULT 570 // 09:30
#define HCC_DOOR_EVENING_DEFAULT 1020 // 17:00
#define HCC_DOOR_CLOSED_BY_DEFAULT 1350 // 22:30
#define HCC_EGG_START_DEFAULT 420
#define HCC_EGG_END_DEFAULT 960
#define HCC_HEAT_CUTOFF_V 25.0f
#define HCC_MOTOR_CUTOFF_V 23.8f // compatibility with policy; applies to relays only
#define HCC_MIN_BATTERY_V 21.0f
#define HCC_MAX_BATTERY_V 30.0f
#define HCC_EGG_HEAT_ON_C 2.0f
#define HCC_EGG_HEAT_OFF_C 5.0f
#define HCC_SENSOR_PERIOD_MS 5000UL
// Existing REV11 inputs and 12V heater output preserved.
#define PIN_LIMIT_OPEN 32      // independent NO dry contact to GND, active LOW
#define PIN_LIMIT_CLOSED 33    // independent NO dry contact to GND, active LOW
#define PIN_ESTOP_NC 18        // NC safety feedback to GND, active LOW = healthy
#define PIN_OBSTRUCTION_NC 19  // NC safety feedback to GND, active LOW = healthy
#define PIN_LOCAL_OPEN 13      // NO button to GND
#define PIN_LOCAL_CLOSE 14     // NO button to GND
#define PIN_KERBL_OPEN 25      // relay with isolated NO contact, no shared ground with Kerbl
#define PIN_KERBL_CLOSE 26     // relay with isolated NO contact, no shared ground with Kerbl
#define PIN_EGG_HEATER 16
#define PIN_ONEWIRE 4
#define PIN_BAT_ADC 34
#define PIN_RTC_SDA 21
#define PIN_RTC_SCL 22
#define PIN_CAMERA_POWER 23   // HIGH enables the external 5 V high-side switch, 10k pull-down
#define PIN_ALARM_HEALTHY 27
#define PIN_WATER_LOW 39     // external pullup if used
#define PIN_EGG_THERMAL_NC 17
// Absolutely no motor PWM / motor-driver outputs in Kerbl mode.
