// HCC REV17 | Kerbl 70546 dry-contact interface | ESP32 core 1.0.6 | LAN/VPN only.
#include <Arduino.h>
#include <string.h>
#include <stdint.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <time.h>
#include <sntp.h>
#include <esp_adc_cal.h>
#include "config.h"
#include "secrets.h"
#include "kerbl_interface.hpp"
#include "policy.hpp"
#include "daily_monitor.hpp"
#include "commission_gate.hpp"
#include "rtc_ds3231.hpp"

static WebServer web(80);
static Preferences prefs;
static OneWire oneWire(PIN_ONEWIRE);
static DallasTemperature temperatures(&oneWire);
static hcckerbl::Interface kerbl(HCC_KERBL_PULSE_MS,HCC_KERBL_TRAVEL_TIMEOUT_MS,HCC_KERBL_COOLDOWN_MS);
static hcc7::EggHeaterPolicy heater;
static hcckerbl::Output lastDoor={hcckerbl::Position::UNKNOWN,hcckerbl::Fault::NONE,false,false,false,false,false,false};
static hcckerbl::Request pending=hcckerbl::Request::NONE;
static bool pendingAck=false,webConfigured=false;
static bool pendingFromWeb=false;
static uint32_t pendingWebAt=0;
// Preserve REV16 local output permissions across this monitoring-only upgrade.
static constexpr char PERMISSIONS_KEY[]="hccOutV16";
static constexpr uint8_t KERBL_PERMISSION=1u, HEATER_PERMISSION=2u;
static uint8_t outputPermissions=0;
static hcc11::LocalButtons localButtons;
static hcc11::CommissionHold kerblHold,heaterHold;

static bool kerblCommissioned(){return (outputPermissions&KERBL_PERMISSION)!=0;}
static bool heaterCommissioned(){return (outputPermissions&HEATER_PERMISSION)!=0;}
static bool cameraPowerOn=false;
static bool heaterOutput=false,batteryOk=false,eggTempOk=false,waterTempOk=false;
static bool alarmActive=true,startupGraceElapsed=false;
static bool thermalLoopOk=false,safetyLoopOk=false;
static bool batteryReadingOk=false,prefsReady=false;
static esp_adc_cal_characteristics_t batteryAdc;
static const bool batteryCalibrated=(HCC_BATTERY_ADC_CALIBRATED!=0);
static float batteryV=0,eggC=0,waterC=0;
static uint32_t lastDoorTime=0,lastTempReq=0,lastBattery=0,lastWifi=0;
static bool tempPending=false,ntpStarted=false,rtcBackupPending=false;
static const char LOCAL_TZ[]="CET-1CEST,M3.5.0/2,M10.5.0/3";
static uint32_t lastRtcBackupAttempt=0;
static uint16_t openMin=HCC_OPEN_TIME_DEFAULT,closeMin=HCC_CLOSE_TIME_DEFAULT;
static uint16_t eggStart=HCC_EGG_START_DEFAULT,eggEnd=HCC_EGG_END_DEFAULT;
static uint32_t csrf=0;
static String events[16];
static unsigned eventPtr=0;
struct Schedule {uint16_t open,close,heatStart,heatEnd;};
static bool validSchedule(const Schedule& v);
static void applySchedule(const Schedule& v);
static constexpr char MONITORING_KEY[]="monitorV17";
static_assert(sizeof(hcc17::MonitoringSchedule)==7*sizeof(uint16_t),
              "Unexpected monitoring schedule storage layout");
static hcc17::MonitoringSchedule monitoring={
  0,HCC_DOOR_MORNING_DEFAULT,HCC_DOOR_OPEN_BY_DEFAULT,HCC_DOOR_EVENING_DEFAULT,
  HCC_DOOR_CLOSED_BY_DEFAULT,HCC_CAMERA_START_DEFAULT,HCC_CAMERA_END_DEFAULT
};
static hcc17::DoorMonitor doorMonitor={hcc17::ExpectedDoor::MONITOR_OFF,hcc17::DoorDeadlineAlarm::NONE};
static unsigned char eggRom[8]={0},waterRom[8]={0};
static void record(const String& s) { events[eventPtr++%16]=String(millis()/1000)+"s "+s; Serial.println(s); }
static bool authenticated(){
  if(web.authenticate(HCC_WEB_USER,HCC_WEB_PASS)) return true;
  web.requestAuthentication();return false;
}
static bool formAuthorized(){return web.hasArg("token") && web.arg("token")==String(csrf,HEX);}
static void moveOutputs(bool open,bool close){
  // Momentary isolated DRY CONTACTS only. Never feed voltage into Kerbl terminals.
  // The built-in Kerbl controller, not ESP32, controls the motor.
  const bool allow=HCC_KERBL_OUTPUTS_ENABLED && kerblCommissioned() && prefsReady &&
      batteryOk && hcc7::batteryCanDrive(batteryV) && safetyLoopOk && digitalRead(PIN_ESTOP_NC)==LOW;
  digitalWrite(PIN_KERBL_OPEN,(allow && open && !close)?HCC_KERBL_RELAY_ON:HCC_KERBL_RELAY_OFF);
  digitalWrite(PIN_KERBL_CLOSE,(allow && close && !open)?HCC_KERBL_RELAY_ON:HCC_KERBL_RELAY_OFF);
}
static bool configuredRom(const unsigned char* rom){
  if(rom[0]!=0x28)return false;
  unsigned char r[8]; for(unsigned i=0;i<8;++i)r[i]=rom[i];
  return OneWire::crc8(r,7)==r[7];
}
static void sampleTemperature(){
  if(configuredRom(eggRom)) {
    float t=temperatures.getTempC(eggRom);
    eggTempOk=(t>-45 && t<85 && t!=85 && t!=DEVICE_DISCONNECTED_C);
    if(eggTempOk)eggC=t;
  }else eggTempOk=false;
  if(configuredRom(waterRom)){
    float t=temperatures.getTempC(waterRom);
    waterTempOk=(t>-45&&t<85&&t!=85&&t!=DEVICE_DISCONNECTED_C);
    if(waterTempOk)waterC=t;
  }else waterTempOk=false;
}
static void measureBattery(){
  uint32_t sum=0;
  bool inRange=true;
  for(int i=0;i<32;++i){
    const int raw=analogRead(PIN_BAT_ADC);
    inRange &= raw>0 && raw<4095;
    sum+=raw;
  }
  batteryReadingOk=inRange;
  batteryV=esp_adc_cal_raw_to_voltage(sum/32,&batteryAdc)*0.001f*
    HCC_BATTERY_DIVIDER_RATIO*HCC_BATTERY_ADC_CORRECTION;
  batteryOk=batteryCalibrated && batteryReadingOk && hcc7::voltageValid(batteryV);
}
static void updateHeat(uint16_t minute,bool clockOk){
  hcc7::HeatInputs i={};
  i.installed=(HCC_EGG_HEATER_INSTALLED!=0);
  i.armed=(HCC_EGG_HEATER_OUTPUTS_ENABLED!=0) && heaterCommissioned() && prefsReady;
  i.rtc_ok=clockOk;
  i.sensor_ok=eggTempOk;
  i.battery_ok=batteryOk&&hcc7::batteryCanHeat(batteryV);
  thermalLoopOk=digitalRead(PIN_EGG_THERMAL_NC)==LOW;
  i.hard_thermal_ok=thermalLoopOk;
  i.local_min=minute;i.start_min=eggStart;i.end_min=eggEnd;i.temp_c=eggC;
  heaterOutput=heater.tick(i);
  digitalWrite(PIN_EGG_HEATER,heaterOutput?HIGH:LOW);
}
static const char* yn(bool x){return x?"true":"false";}
static String statusJson(){
  uint16_t mi=0;uint32_t d=0;bool clockOk=hcc7::localClock(mi,d);
  String s="{\"project\":\"HCC\",\"rev\":17,\"door_type\":\"KERBL_70546\",\"commissioned\":";
  s+=yn(kerblCommissioned());s+=",\"kerbl_commissioned\":";
  s+=yn(kerblCommissioned());s+=",\"heater_commissioned\":";
  s+=yn(heaterCommissioned());s+=",\"heater_outputs_enabled\":";
  s+=yn(HCC_EGG_HEATER_OUTPUTS_ENABLED!=0);s+=",\"kerbl_relays_enabled\":";
  s+=yn(HCC_KERBL_OUTPUTS_ENABLED!=0);
  s+=",\"web_kerbl_commands_enabled\":";s+=yn(HCC_ALLOW_WEB_KERBL_COMMANDS!=0);
  s+=",\"door\":\"";s+=hcckerbl::positionName(lastDoor.position);
  s+="\",\"fault\":\"";s+=hcckerbl::faultName(lastDoor.fault);s+="\",\"position_verified\":";
  s+=yn(lastDoor.verified);s+=",\"kerbl_pulse_active\":";s+=yn(lastDoor.pulse);
  s+=",\"awaiting_position\":";s+=yn(lastDoor.pending);
  s+=",\"kerbl_manual_mode_assumed\":";s+=yn(lastDoor.assumed_manual);
  s+=",\"kerbl_auto_mode_verified\":false"; // Cannot read Kerbl mode via ext. button.
  s+=",\"door_deadline_enabled\":";s+=yn(monitoring.deadlineEnabled!=0);
  s+=",\"door_deadline_expected\":\"";s+=hcc17::expectedDoorName(doorMonitor.expected);
  s+="\",\"door_deadline_alarm\":\"";s+=hcc17::deadlineAlarmName(doorMonitor.alarm);s+="\"";
  s+=",\"door_morning_start_minute\":";s+=String(monitoring.morningStart);
  s+=",\"door_open_by_minute\":";s+=String(monitoring.openBy);
  s+=",\"door_evening_start_minute\":";s+=String(monitoring.eveningStart);
  s+=",\"door_closed_by_minute\":";s+=String(monitoring.closedBy);
  s+=",\"camera_power_schedule_enabled\":";s+=yn(HCC_CAMERA_POWER_ENABLED!=0);
  s+=",\"camera_power_on\":";s+=yn(cameraPowerOn);
  s+=",\"camera_start_minute\":";s+=String(monitoring.cameraStart);
  s+=",\"camera_end_minute\":";s+=String(monitoring.cameraEnd);
  s+=",\"clock_valid\":";s+=yn(clockOk);s+=",\"local_minute\":";s+=String(mi);
  s+=",\"battery_calibrated\":";s+=yn(batteryCalibrated);
  s+=",\"battery_voltage\":";s+=batteryOk?String(batteryV,2):"null";
  s+=",\"battery_voltage_estimate\":";s+=batteryReadingOk?String(batteryV,2):"null";
  s+=",\"battery_soc\":null";
  s+=",\"egg_temp\":";s+=eggTempOk?String(eggC,1):"null";
  s+=",\"water_temp\":";s+=waterTempOk?String(waterC,1):"null";
  s+=",\"water_available_verified\":false";
  s+=",\"egg_heater_output\":";s+=yn(heaterOutput);
  s+=",\"water_heater_output\":false";
  s+=",\"safety_loop_ok\":";s+=yn(safetyLoopOk);
  s+=",\"estop_feedback_ok\":";s+=yn(digitalRead(PIN_ESTOP_NC)==LOW);
  s+=",\"limit_open_active\":";s+=yn(digitalRead(PIN_LIMIT_OPEN)==LOW);
  s+=",\"limit_closed_active\":";s+=yn(digitalRead(PIN_LIMIT_CLOSED)==LOW);
  s+=",\"relay_open_active\":";s+=yn(lastDoor.relay_open&&kerblCommissioned()&&HCC_KERBL_OUTPUTS_ENABLED);
  s+=",\"relay_close_active\":";s+=yn(lastDoor.relay_close&&kerblCommissioned()&&HCC_KERBL_OUTPUTS_ENABLED);
  s+=",\"heater_thermal_loop_ok\":";s+=yn(thermalLoopOk);
  s+=",\"settings_storage_ok\":";s+=yn(prefsReady);
  s+=",\"egg_sensor_paired\":";s+=yn(configuredRom(eggRom));
  s+=",\"water_sensor_paired\":";s+=yn(configuredRom(waterRom));
  s+=",\"alarm_active\":";s+=yn(alarmActive);
  s+=",\"wifi_connected\":";s+=yn(WiFi.status()==WL_CONNECTED);
  s+=",\"wifi_ip\":\"";s+=WiFi.localIP().toString();s+="\"}";
  return s;
}
static String htmlHeader(const char* title){
  String s="<!doctype html><html lang='cs'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
  s+="<title>";s+=title;s+="</title><style>body{font:16px Arial,sans-serif;margin:25px auto;max-width:850px;padding:0 14px;line-height:1.5;color:#173035}table{border-collapse:collapse;width:100%}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:left}button{padding:10px;margin:5px}input{padding:8px;max-width:90px}input[type=time]{max-width:none}.warn{padding:12px;background:#fff3dd;border-left:4px solid #bb8d00}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f0f3f3;padding:12px}a{margin-right:12px}</style>";
  return s;
}
static String timeField(const char* label,const char* name,uint16_t minute){
  char timeValue[8];
  snprintf(timeValue,sizeof timeValue,"%02u:%02u",
    static_cast<unsigned>(minute/60),static_cast<unsigned>(minute%60));
  return String("<label>")+label+" <input type='time' required name='"+name+
    "' value='"+timeValue+"'></label><br>";
}
static void indexPage(){
  if(!authenticated())return;
  String s=htmlHeader("HCC Kerbl");
  s+="<h2>HOME CHICKEN CONTROLLER / REV17 – KERBL 70546</h2>";
  s+="<p class='warn'>Pred montazi a elektrickymi zkouskami rele fyzicky ODPOJ od Kerbl. "
     "Pri vychozi konfiguraci jsou rele i topeni zakazana. "
     "ESP32 ovlada jen externi tlacitkove vstupy Kerbl, NIKDY motor.</p>";
  s+="<p id='freshness'>Stav pri otevreni</p><pre id='st'>"+statusJson()+"</pre>";
  s+="<p><b>Samostatna automatika Kerbl:</b> cas/svetlo nastavovat primo na Kerbl. "
     "Vnejsi tlacitko prepne Kerbl do rucniho rezimu; navrat AUTO vyzaduje panel Kerbl "
     "nebo v Kerbl nastavene AC ON pri dalsim dennim cyklu. Stav AUTO ESP32 neumi cist.</p>";
  s+="<p><b>Uvedeni do provozu:</b> ";
  s+=kerblCommissioned()?"Kerbl povolen":"Kerbl zamcen";
  s+=heaterCommissioned()?"; topeni povoleno":"; topeni zamceno";
  s+=". Po zkouskach uvolni obe mistni tlacitka a pak je drz soucasne 5 sekund.";
  s+="</p><h3>Rucni prikazy</h3>";
  s+="<form method='POST' action='/action'><input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  if(HCC_ALLOW_WEB_KERBL_COMMANDS){
    s+="<button name='do' value='open'>OTEVRIT (puls)</button>";
    s+="<button name='do' value='close'>ZAVRIT (puls)</button>";
  }
  s+="<button name='do' value='ack'>Potvrdit chybu</button>";
  s+="<button name='do' value='service'>Servisni zamek</button></form>";
  s+="<p class='warn'><b>Pozor:</b> Servisni zamek prerusi jen povelove rele, NE zastaveni uz "
     "beziciho motoru Kerbl. Pri nebezpeci pouzij skutecne fyzicke odpojeni napajeni Kerbl "
     "a postup dle vyrobce. Nezkousej pohyb se zviraty v dosahu. "
     "Kameru při servisu odpoj na její větvi 5 V.</p>";
  if(!hcc7::systemTimeValid()){
    s+="<form method='POST' action='/clock' onsubmit=\"if(!confirm('Pouzit cas telefonu?'))return false;"
       "this.elements.epoch.value=Math.floor(Date.now()/1000)\">";
    s+="<input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
    s+="<input type='hidden' name='epoch'><button>Nastavit hodiny podle telefonu</button></form>";
  }
  s+="<h3>Ohrev vajec – casy ESP32</h3><form method='POST' action='/settings'>";
  s+="<input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  s+="Od min.: <input name='heatstart' type='number' min='0' max='1439' value='"+String(eggStart)+"'> ";
  s+="Do min.: <input name='heatend' type='number' min='0' max='1439' value='"+String(eggEnd)+"'>";
  s+="<button>Ulozit</button></form><p>Minuty od pulnoci. Hodiny dveri se nastavuji pouze na Kerbl.</p>";
  s+="<h3>Dohled dvířek a napájení kamery</h3>";
  s+="<p>Časy dohledu porovnej s plánem v Kerbl. Dohled pouze hlásí nesplněnou polohu. Pohyb dvířek řídí Kerbl.</p>";
  s+="<form method='POST' action='/monitoring'><input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  s+="<label><input type='checkbox' name='deadline' value='1'";
  if(monitoring.deadlineEnabled)s+=" checked";
  s+="> Hlásit nesplněnou polohu dvířek</label><br>";
  s+=timeField("Ranní přechod od","morning",monitoring.morningStart);
  s+=timeField("Otevřeno nejpozději","openby",monitoring.openBy);
  s+=timeField("Večerní přechod od","evening",monitoring.eveningStart);
  s+=timeField("Zavřeno nejpozději","closedby",monitoring.closedBy);
  s+=timeField("Zapnout kameru od","camerastart",monitoring.cameraStart);
  s+=timeField("Vypnout kameru v","cameraend",monitoring.cameraEnd);
  s+="<button>Uložit dohled a kameru</button></form>";
  s+="<p>Napájení kamery (GPIO23) <strong id='cameraPower'>";
  s+=cameraPowerOn?"zapnuto":"vypnuto";
  s+="</strong>. Kamera po zapnutí potřebuje čas na připojení.</p>";
  s+="<p><a href='/status'>JSON /status</a><a href='/sensors'>Cidla</a><a href='/events'>Udalosti</a></p>";
  if(String(HCC_CAMERA_LOCAL_URL).length()>0)s+="<p><a href='"+String(HCC_CAMERA_LOCAL_URL)+"'>Kamera vajec – LAN/VPN</a></p>";
  s+="<script>const f=document.getElementById('freshness');let last=new Date();"
     "async function poll(){const c=new AbortController();const t=setTimeout(()=>c.abort(),2500);"
     "try{const r=await fetch('/status',{cache:'no-store',signal:c.signal});if(!r.ok)throw Error(r.status);"
     "const data=await r.json();document.getElementById('st').textContent=JSON.stringify(data,null,2);"
     "document.getElementById('cameraPower').textContent=data.camera_power_on?'zapnuto':'vypnuto';last=new Date();"
     "f.textContent='Aktualizovano '+last.toLocaleTimeString()}catch(e){"
     "f.textContent='Nedostupne; posledni '+last.toLocaleTimeString()}"
     "finally{clearTimeout(t);setTimeout(poll,3000)}}poll();</script></html>";
  web.sendHeader("Cache-Control","no-store");web.send(200,"text/html; charset=utf-8",s);
}
static void statusPage(){if(!authenticated())return;web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",statusJson());}
static void sensorsPage(){
  if(!authenticated())return;
  String s=htmlHeader("HCC senzory")+"<h3>Adresy DS18B20</h3><pre>";
  uint8_t addr[8];int n=temperatures.getDeviceCount();
  for(int i=0;i<n;++i) {
    if(!temperatures.getAddress(addr,i))continue;
    s+=String(i)+": {";
    for(int j=0;j<8;++j){if(j)s+=",";s+="0x";if(addr[j]<16)s+="0";s+=String(addr[j],HEX);}
    s+="}\n";
  }
  s+="</pre><p>Pořadí sond se může měnit; přiřazení se ukládá podle unikátní ROM adresy. Umístění před párováním ověř termometrem.</p>";
  s+="<form method='POST' action='/pair'><input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  s+="Role: <select name='role'><option value='egg'>VEJCE</option><option value='water'>VODA</option></select>";
  s+="Index: <input name='index' type='number' min='0' max='9' required>";
  s+="<button>Spárovat čidlo</button></form><a href='/'>Zpět</a>";
  web.send(200,"text/html; charset=utf-8",s);
}
static void onPair(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  if(!prefsReady){web.send(503,"text/plain","Settings storage unavailable");return;}
  const String role=web.arg("role");
  const String ix=web.arg("index");
  if(ix.length()!=1 || ix[0]<'0' || ix[0]>'9'){
    web.send(400,"text/plain","Invalid sensor index");return;
  }
  uint8_t addr[8];
  if(!temperatures.getAddress(addr,ix[0]-'0') || !configuredRom(addr)){
    web.send(400,"text/plain","Sensor not found");return;
  }
  if(role=="egg"){
    if(memcmp(addr,waterRom,8)==0){web.send(409,"text/plain","Already assigned to water");return;}
    if(prefs.putBytes("eggrom",addr,8)!=8){web.send(500,"text/plain","Sensor pairing could not be saved");return;}
    memcpy(eggRom,addr,8);
    eggTempOk=false;
    heater.off();heaterOutput=false;digitalWrite(PIN_EGG_HEATER,LOW);
    record("Egg DS18B20 paired");
  }else if(role=="water"){
    if(memcmp(addr,eggRom,8)==0){web.send(409,"text/plain","Already assigned to egg");return;}
    if(prefs.putBytes("waterrom",addr,8)!=8){web.send(500,"text/plain","Sensor pairing could not be saved");return;}
    memcpy(waterRom,addr,8);
    waterTempOk=false;
    record("Water DS18B20 paired");
  }else {web.send(400,"text/plain","Invalid role");return;}
  web.sendHeader("Location","/sensors");web.send(303,"text/plain","Paired");
}
static void eventsPage(){if(!authenticated())return;String s="";for(int i=0;i<16;++i){const String& x=events[(eventPtr+i)%16];if(x.length())s+=x+"\n";}web.send(200,"text/plain; charset=utf-8",s);}
static bool parseMinute(const String& text,uint16_t& minute){
  if(!text.length() || text.length()>4)return false;
  minute=0;
  for(unsigned i=0;i<text.length();++i){
    if(text[i]<'0' || text[i]>'9')return false;
    minute=minute*10+text[i]-'0';
  }
  return minute<1440;
}
static bool validSchedule(const Schedule& v){
  return v.open<v.close && v.close<1440 && v.heatStart<1440 &&
    v.heatEnd<1440 && v.heatStart!=v.heatEnd;
}
static void applySchedule(const Schedule& v){
  openMin=v.open;closeMin=v.close;eggStart=v.heatStart;eggEnd=v.heatEnd;
}
static void onSettings(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  Schedule next={openMin,closeMin,eggStart,eggEnd};
  if(!parseMinute(web.arg("heatstart"),next.heatStart) ||
     !parseMinute(web.arg("heatend"),next.heatEnd) || !validSchedule(next)){
    web.send(400,"text/plain","Invalid egg timing");return;
  }
  if(!prefsReady || prefs.putBytes("schedule",&next,sizeof next)!=sizeof next){
    web.send(500,"text/plain","Schedule could not be saved");return;
  }
  applySchedule(next);record("Egg heating schedule updated");
  web.sendHeader("Location","/");web.send(303,"text/plain","Saved");
}

static bool parseTimeInput(const String& text,uint16_t& minute){
  if(text.length()!=5 || text[2]!=':')return false;
  for(unsigned i=0;i<text.length();++i)
    if(i!=2 && (text[i]<'0' || text[i]>'9'))return false;
  const unsigned hours=(text[0]-'0')*10+(text[1]-'0');
  const unsigned minutes=(text[3]-'0')*10+(text[4]-'0');
  if(hours>=24 || minutes>=60)return false;
  minute=hours*60+minutes;
  return true;
}
static void onMonitoring(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  hcc17::MonitoringSchedule next={};
  if(web.hasArg("deadline")){
    if(web.arg("deadline")!="1"){web.send(400,"text/plain","Invalid deadline setting");return;}
    next.deadlineEnabled=1;
  }
  if(!parseTimeInput(web.arg("morning"),next.morningStart) ||
     !parseTimeInput(web.arg("openby"),next.openBy) ||
     !parseTimeInput(web.arg("evening"),next.eveningStart) ||
     !parseTimeInput(web.arg("closedby"),next.closedBy) ||
     !parseTimeInput(web.arg("camerastart"),next.cameraStart) ||
     !parseTimeInput(web.arg("cameraend"),next.cameraEnd) || !hcc17::validSchedule(next)){
    web.send(400,"text/plain","Invalid schedule. Use ordered door times and different camera start and end.");
    return;
  }
  if(!prefsReady || prefs.putBytes(MONITORING_KEY,&next,sizeof next)!=sizeof next){
    web.send(500,"text/plain","Monitoring schedule could not be saved");
    return;
  }
  monitoring=next;
  record("Door deadline and camera schedules updated");
  web.sendHeader("Location","/");web.send(303,"text/plain","Saved");
}

static void onClock(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  if(hcc7::systemTimeValid()){web.send(409,"text/plain","Clock already set");return;}
  const String text=web.arg("epoch");
  int64_t epoch=0;
  if(text.length()==10){
    for(unsigned i=0;i<text.length();++i){
      if(text[i]<'0' || text[i]>'9'){epoch=0;break;}
      epoch=epoch*10+text[i]-'0';
    }
  }
  if(!hcc7::validClockEpoch(epoch)){web.send(400,"text/plain","Invalid browser time");return;}
  if(!hcc7::writeDS3231Utc(static_cast<time_t>(epoch))){
    web.send(503,"text/plain","DS3231 is unavailable");
    return;
  }
  hcc7::restoreClockFromRtc();
  if(!hcc7::systemTimeValid()){web.send(503,"text/plain","DS3231 clock could not be verified");return;}
  record("Browser time saved to DS3231");
  web.sendHeader("Location","/");web.send(303,"text/plain","Clock saved");
}
static void onAction(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  const String cmd=web.arg("do");
  if(cmd=="service"){
    outputPermissions=0;
    localButtons.requireRelease();
    pending=hcckerbl::Request::NONE;
    pendingFromWeb=false;
    kerbl.disarm();
    lastDoor=kerbl.output();
    moveOutputs(false,false);
    heater.off();heaterOutput=false;
    digitalWrite(PIN_EGG_HEATER,LOW);
    record("SERVICE LOCK: ESP outputs off; Kerbl motor may keep moving");
    if(!prefsReady || prefs.putUChar(PERMISSIONS_KEY,0)!=1){
      record("Service lock active in RAM; NVS write failed");
      web.send(500,"text/plain","Service lock not persisted. Isolate hardware before reboot.");
      return;
    }
  }else if(cmd=="ack"){
    if(lastDoor.fault==hcckerbl::Fault::NONE){
      web.send(409,"text/plain","No Kerbl fault to acknowledge");
      return;
    }
    pendingAck=true;record("Remote fault acknowledge queued");
  }else if(cmd=="open"||cmd=="close"){
    if(!HCC_ALLOW_WEB_KERBL_COMMANDS || !HCC_KERBL_OUTPUTS_ENABLED){
      web.send(403,"text/plain","Relay outputs disabled by config");return;
    }
    if(!kerblCommissioned() || !prefsReady || !batteryOk || !hcc7::batteryCanDrive(batteryV) ||
       digitalRead(PIN_ESTOP_NC)!=LOW || !safetyLoopOk || lastDoor.fault!=hcckerbl::Fault::NONE ||
       !lastDoor.verified || lastDoor.pending || lastDoor.pulse || pendingAck ||
       pending!=hcckerbl::Request::NONE){
      web.send(409,"text/plain","Safety, position or commissioning not ready");return;
    }
    if(!kerbl.cooldownReady(millis())){web.send(429,"text/plain","Door command cooldown in progress");return;}
    const bool open=(cmd=="open");
    if((open && lastDoor.position!=hcckerbl::Position::CLOSED)||
       (!open && lastDoor.position!=hcckerbl::Position::OPEN)){
      web.send(409,"text/plain","Already at destination or invalid starting position");return;
    }
    pending=open?hcckerbl::Request::OPEN:hcckerbl::Request::CLOSE;
    pendingFromWeb=true;
    pendingWebAt=millis();
    record(open?"Web Kerbl OPEN request":"Web Kerbl CLOSE request");
  }else{web.send(400,"text/plain","Unknown command");return;}
  web.sendHeader("Location","/");web.send(303,"text/plain","Accepted");
}
static void readLocalButtons(uint32_t now,bool rawOpen,bool rawClosed,bool safe,bool clockOk){
  const hcc11::ButtonGesture buttons=localButtons.tick(
    digitalRead(PIN_LOCAL_OPEN)==LOW,digitalRead(PIN_LOCAL_CLOSE)==LOW,now);
  const bool verifiedNow=lastDoor.verified && rawOpen!=rawClosed &&
    ((rawOpen && lastDoor.position==hcckerbl::Position::OPEN) ||
     (rawClosed && lastDoor.position==hcckerbl::Position::CLOSED));
  const bool canCommand=HCC_KERBL_OUTPUTS_ENABLED && prefsReady && batteryOk &&
    hcc7::batteryCanDrive(batteryV) && verifiedNow && safe &&
    lastDoor.fault==hcckerbl::Fault::NONE && !lastDoor.pulse && !lastDoor.pending;
  const bool canHeat=HCC_EGG_HEATER_OUTPUTS_ENABLED && HCC_EGG_HEATER_INSTALLED &&
    prefsReady && batteryOk && hcc7::batteryCanHeat(batteryV) && clockOk &&
    eggTempOk && digitalRead(PIN_EGG_THERMAL_NC)==LOW;
  uint8_t next=outputPermissions;
  if(kerblHold.tick(buttons.bothHeld,canCommand&&!kerblCommissioned(),now))
    next|=KERBL_PERMISSION;
  if(heaterHold.tick(buttons.bothHeld,canHeat&&!heaterCommissioned(),now))
    next|=HEATER_PERMISSION;
  if(next!=outputPermissions){
    if(prefs.putUChar(PERMISSIONS_KEY,next)==1){
      outputPermissions=next;
      record("Local permission saved for eligible enabled outputs");
    }else record("Local commissioning NVS error");
  }

  if(!canCommand || !kerblCommissioned() || !kerbl.cooldownReady(now) ||
     pendingAck || pending!=hcckerbl::Request::NONE)return;
  if((buttons.single==hcckerbl::Request::OPEN && rawClosed) ||
     (buttons.single==hcckerbl::Request::CLOSE && rawOpen)){
    pending=buttons.single;
    record(pending==hcckerbl::Request::OPEN?"Local Kerbl OPEN request":"Local Kerbl CLOSE request");
  }
}
static void tickDoor(uint32_t now,bool clockOk){
  safetyLoopOk=(digitalRead(PIN_OBSTRUCTION_NC)==LOW);
  const bool rawOpen=(digitalRead(PIN_LIMIT_OPEN)==LOW);
  const bool rawClosed=(digitalRead(PIN_LIMIT_CLOSED)==LOW);
  const bool safe=(digitalRead(PIN_ESTOP_NC)==LOW && safetyLoopOk);
  if(pendingFromWeb && static_cast<uint32_t>(now-pendingWebAt)>=2000u){
    pending=hcckerbl::Request::NONE;
    pendingFromWeb=false;
    record("Stale web request expired");
  }
  readLocalButtons(now,rawOpen,rawClosed,safe,clockOk);
  if(pendingAck){
    pending=hcckerbl::Request::NONE;
    if(kerbl.acknowledge(rawOpen,rawClosed,safe))record("Kerbl monitor fault acknowledged");
    else record("Kerbl fault acknowledgement refused – no fault or unsafe position");
    pendingAck=false;
  }
  const hcckerbl::Output old=lastDoor;
  const bool authorized=HCC_KERBL_OUTPUTS_ENABLED && kerblCommissioned() && prefsReady &&
      batteryOk && hcc7::batteryCanDrive(batteryV) && safe;
  lastDoor=kerbl.tick(rawOpen,rawClosed,safe,authorized,pending,now);
  moveOutputs(lastDoor.relay_open,lastDoor.relay_close);
  if(lastDoor.position!=old.position || lastDoor.fault!=old.fault ||
     (lastDoor.pulse && !old.pulse))
    record(String("Kerbl position ")+hcckerbl::positionName(lastDoor.position)+
      " / "+hcckerbl::faultName(lastDoor.fault));
  pending=hcckerbl::Request::NONE;
  pendingFromWeb=false;
}
void setup(){
  // GPIO initialized OFF before networking or any sensor reading.
  digitalWrite(PIN_KERBL_OPEN,HCC_KERBL_RELAY_OFF);pinMode(PIN_KERBL_OPEN,OUTPUT);
  digitalWrite(PIN_KERBL_CLOSE,HCC_KERBL_RELAY_OFF);pinMode(PIN_KERBL_CLOSE,OUTPUT);
  digitalWrite(PIN_EGG_HEATER,LOW);pinMode(PIN_EGG_HEATER,OUTPUT);
  digitalWrite(PIN_CAMERA_POWER,LOW);pinMode(PIN_CAMERA_POWER,OUTPUT);
  digitalWrite(PIN_ALARM_HEALTHY,LOW);pinMode(PIN_ALARM_HEALTHY,OUTPUT);
  pinMode(PIN_LIMIT_OPEN,INPUT_PULLUP);pinMode(PIN_LIMIT_CLOSED,INPUT_PULLUP);
  pinMode(PIN_ESTOP_NC,INPUT_PULLUP);pinMode(PIN_OBSTRUCTION_NC,INPUT_PULLUP);
  pinMode(PIN_LOCAL_OPEN,INPUT_PULLUP);pinMode(PIN_LOCAL_CLOSE,INPUT_PULLUP);
  pinMode(PIN_EGG_THERMAL_NC,INPUT_PULLUP);pinMode(PIN_WATER_LOW,INPUT);
  analogReadResolution(12);analogSetPinAttenuation(PIN_BAT_ADC,ADC_11db);
  esp_adc_cal_characterize(ADC_UNIT_1,ADC_ATTEN_DB_11,ADC_WIDTH_BIT_12,1100,&batteryAdc);
  Serial.begin(115200);delay(80);
  prefsReady=prefs.begin("hcc7",false);
  if(prefsReady){
    Schedule saved;
    if(prefs.getBytes("schedule",&saved,sizeof saved)!=sizeof saved){
      saved={prefs.getUShort("open",HCC_OPEN_TIME_DEFAULT),
             prefs.getUShort("close",HCC_CLOSE_TIME_DEFAULT),
             prefs.getUShort("eggstart",HCC_EGG_START_DEFAULT),
             prefs.getUShort("eggend",HCC_EGG_END_DEFAULT)};
    }
    if(validSchedule(saved))applySchedule(saved);
    hcc17::MonitoringSchedule savedMonitoring;
    if(prefs.getBytes(MONITORING_KEY,&savedMonitoring,sizeof savedMonitoring)==sizeof savedMonitoring &&
       hcc17::validSchedule(savedMonitoring))monitoring=savedMonitoring;
    outputPermissions=prefs.getUChar(PERMISSIONS_KEY,0)&
      (KERBL_PERMISSION|HEATER_PERMISSION);
    if(prefs.getBytesLength("eggrom")==8)prefs.getBytes("eggrom",eggRom,8);
    if(prefs.getBytesLength("waterrom")==8)prefs.getBytes("waterrom",waterRom,8);
  }
  Wire.begin(PIN_RTC_SDA,PIN_RTC_SCL);Wire.setClock(100000);
  hcc7::restoreClockFromRtc();setenv("TZ",LOCAL_TZ,1);tzset();
  measureBattery();lastBattery=millis();
  temperatures.begin();temperatures.setResolution(11);temperatures.setWaitForConversion(false);
  temperatures.requestTemperatures();tempPending=true;lastTempReq=millis();
  csrf=esp_random();
  const bool serviceApConfigured=strlen(HCC_AP_PASS)>=8 &&
    strcmp(HCC_AP_PASS,"CHANGE_THIS_AP_PASSWORD")!=0;
  webConfigured=strlen(HCC_WEB_PASS)>=8 &&
    strcmp(HCC_WEB_PASS,"CHANGE_THIS_WEB_PASSWORD")!=0;
  const bool enableServiceAp=serviceApConfigured && webConfigured;
  WiFi.mode(enableServiceAp?WIFI_AP_STA:WIFI_STA);
  if(enableServiceAp)WiFi.softAP(HCC_AP_SSID,HCC_AP_PASS);
  if(strlen(HCC_WIFI_SSID)>0)WiFi.begin(HCC_WIFI_SSID,HCC_WIFI_PASS);
  web.on("/",HTTP_GET,indexPage);
  web.on("/status",HTTP_GET,statusPage);
  web.on("/sensors",HTTP_GET,sensorsPage);
  web.on("/events",HTTP_GET,eventsPage);
  web.on("/pair",HTTP_POST,onPair);
  web.on("/action",HTTP_POST,onAction);
  web.on("/clock",HTTP_POST,onClock);
  web.on("/settings",HTTP_POST,onSettings);
  web.on("/monitoring",HTTP_POST,onMonitoring);
  web.onNotFound([](){if(!authenticated())return;web.send(404,"text/plain","Not found");});
  if(webConfigured)web.begin();
  record(kerblCommissioned()?"REV17 Kerbl permission stored":"REV17 Kerbl locked");
  record(heaterCommissioned()?"REV17 heater permission stored":"REV17 heater locked");
  if(enableServiceAp)Serial.println(WiFi.softAPIP());
}
void loop(){
  const uint32_t now=millis();
  if(tempPending && (uint32_t)(now-lastTempReq)>=750){sampleTemperature();tempPending=false;}
  if(!tempPending && (uint32_t)(now-lastTempReq)>=HCC_SENSOR_PERIOD_MS){
    temperatures.requestTemperatures();tempPending=true;lastTempReq=now;
  }
  if((uint32_t)(now-lastBattery)>=1000){lastBattery=now;measureBattery();}
  if((uint32_t)(now-lastDoorTime)>=25){
    lastDoorTime=now;
    uint16_t minute=0;uint32_t dayKey=0;
    const bool clockOk=hcc7::localClock(minute,dayKey);
    tickDoor(now,clockOk);
    updateHeat(minute,clockOk);
    cameraPowerOn=hcc17::cameraPowerOn(HCC_CAMERA_POWER_ENABLED!=0,clockOk,minute,monitoring);
    digitalWrite(PIN_CAMERA_POWER,cameraPowerOn?HIGH:LOW);
    const hcc17::DoorMonitor nextMonitor=hcc17::monitorDoor(monitoring,clockOk,minute,lastDoor);
    if(nextMonitor.alarm!=doorMonitor.alarm)
      record(String("Door deadline ")+hcc17::deadlineAlarmName(nextMonitor.alarm));
    doorMonitor=nextMonitor;
    if(now>=120000)startupGraceElapsed=true;
    alarmActive=(lastDoor.fault!=hcckerbl::Fault::NONE) ||
      (doorMonitor.alarm!=hcc17::DoorDeadlineAlarm::NONE) ||
      (startupGraceElapsed && (!clockOk || !kerbl.everLocated())) ||
      !prefsReady ||
      (HCC_KERBL_OUTPUTS_ENABLED && !kerblCommissioned()) ||
      (HCC_EGG_HEATER_OUTPUTS_ENABLED && !heaterCommissioned()) ||
      (!batteryOk || batteryV<24.5f) ||
      (HCC_EGG_HEATER_INSTALLED && (!eggTempOk || !thermalLoopOk)) ||
      !safetyLoopOk || digitalRead(PIN_ESTOP_NC)!=LOW;
    digitalWrite(PIN_ALARM_HEALTHY,alarmActive?LOW:HIGH);
  }
  // Keep short pulses accurately timed even when remote HTTP client is slow.
  if(lastDoor.pulse){delay(1);return;}
  if(webConfigured)web.handleClient();
  static IPAddress lastStaIp;
  if(WiFi.status()==WL_CONNECTED && WiFi.localIP()!=lastStaIp){
    lastStaIp=WiFi.localIP();Serial.print("HCC LAN IP: ");Serial.println(lastStaIp);
  }
  if((uint32_t)(now-lastWifi)>=30000){
    lastWifi=now;
    if(strlen(HCC_WIFI_SSID)>0 && WiFi.status()!=WL_CONNECTED)WiFi.reconnect();
  }
  if(!ntpStarted && WiFi.status()==WL_CONNECTED){
    configTzTime(LOCAL_TZ,"pool.ntp.org","time.google.com");ntpStarted=true;
  }
  if(ntpStarted && sntp_get_sync_status()==SNTP_SYNC_STATUS_COMPLETED){
    rtcBackupPending=true;lastRtcBackupAttempt=now-5000u;
  }
  if(rtcBackupPending && (uint32_t)(now-lastRtcBackupAttempt)>=5000u){
    lastRtcBackupAttempt=now;
    if(hcc7::systemTimeValid() && hcc7::writeDS3231Utc(time(nullptr))){
      rtcBackupPending=false;record("NTP time saved to DS3231");
    }
  }
  delay(1);
}
