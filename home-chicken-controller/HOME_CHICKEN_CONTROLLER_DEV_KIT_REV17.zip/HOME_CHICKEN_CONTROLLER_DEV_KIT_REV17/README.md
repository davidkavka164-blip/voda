# HOME CHICKEN CONTROLLER · REV17 / Kerbl 70546

Montážní sada pro ostrovní kurník pro deset slepic. Kerbl řídí dvířka podle vlastních hodin a světla. ESP32 čte polohu dvířek, umí vyslat místní servisní povel, měří teploty a řídí ohřev sběrného boxu. RUT241 zajišťuje vzdálený dohled. Napájení kamery je ve výchozím nastavení zapnuté od 07:00 do 16:00 místního času. Čas lze změnit z webu. Vodu a stav slepic kontroluj osobně.

## Pořadí instalace

1. [Stavba a příprava montáže](construction/REV17_STAVBA_A_MONTAZ.md) a [pracovní půdorys](drawings/HCC_PUDORYS_ROVINA_REV17.png). Rozměry otvoru a kotvení přenes podle skutečných dílů.
2. [Nákupní seznam](components/HCC_NAKUP_REV17_KERBL.xlsx), [zapojení](docs/REV17_ZAPOJENI_A_BEZPECNOST.md), [blokové schéma](drawings/HCC_KERBL_BLOKY_REV17.png) a [napájení a nastavení FVE](docs/REV17_NAPAJENI_A_FVE.md). Vybraná dvířka Kerbl 70546 běží standardně ze 4× AA. Pro samostatnou vnější 12V baterii je k dispozici originální kabel Kerbl 70557. Hlavní 24V baterie napájí DC rozvod kurníku.
3. [Instalace a zkoušky](docs/REV17_NAVOD_INSTALACE_A_TESTY.md) a [přejímací protokol](docs/REV17_ZKUSEBNI_PROTOKOL.csv). Výchozí firmware má spínání relé i topení zablokované. Při prvním nahrání nech obě výkonové větve fyzicky odpojené.
4. [LTE, WireGuard, kamera a SMS](docs/REV17_LTE_WIREGUARD_KAMERA.md). Počítej s vlastní SIM, hesly a veřejně dosažitelným protějškem WireGuard. Nastavitelný dohled hlásí nedosažení očekávané krajní polohy dvířek.
5. [Provoz dvířek a režim AUTO](docs/REV17_KERBL_OVLADANI.md) a [výsledky ověření vydání](docs/REV17_OVERENI.md).

Firmware je pro ESP32 Dev Module a AI Thinker ESP32‑CAM. Montážní návod se schématy a přejímacím protokolem je také v souboru `MONTAZNI_NAVOD_HCC_REV17.pdf`. Sada navazuje na REV16. Pro novou montáž používej schéma, firmware a protokol REV17.
