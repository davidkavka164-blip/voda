#pragma once
#include <Wire.h>
#include <stdint.h>
#include <sys/time.h>
#include <time.h>

namespace hcc7 {
constexpr uint8_t RTC_ADDRESS = 0x68;
constexpr uint8_t RTC_TIME_REGISTER = 0x00;
constexpr uint8_t RTC_STATUS_REGISTER = 0x0F;
constexpr uint8_t RTC_OSCILLATOR_STOPPED = 0x80;
constexpr int64_t MIN_CLOCK_EPOCH = 1760000000;
// ESP32 core 1.0.6 uses signed 32-bit time_t even when host tests use 64-bit.
constexpr int64_t MAX_CLOCK_EPOCH = INT32_MAX;

inline bool validClockEpoch(int64_t epoch) {
  return epoch > MIN_CLOCK_EPOCH && epoch <= MAX_CLOCK_EPOCH;
}

inline bool readRtcRegisters(uint8_t first, uint8_t* values, uint8_t count) {
  Wire.beginTransmission(RTC_ADDRESS);
  Wire.write(first);
  if (Wire.endTransmission(false) != 0 || Wire.requestFrom(RTC_ADDRESS, count) != count) {
    return false;
  }
  for (uint8_t i = 0; i < count; ++i) {
    const int value = Wire.read();
    if (value < 0) return false;
    values[i] = static_cast<uint8_t>(value);
  }
  return true;
}

inline bool decodeBcd(uint8_t value, unsigned& out) {
  const unsigned tens = value >> 4;
  const unsigned units = value & 0x0F;
  if (tens > 9 || units > 9) return false;
  out = 10 * tens + units;
  return true;
}

inline uint8_t decToBcd(uint8_t value) {
  return ((value / 10) << 4) | (value % 10);
}

inline unsigned daysInMonth(unsigned year, unsigned month) {
  constexpr uint8_t lengths[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  const bool leap = year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
  return lengths[month - 1] + (month == 2 && leap);
}

// Gregorian civil date to number of days since the Unix epoch.
inline int32_t civilDays(int year, unsigned month, unsigned day) {
  year -= month <= 2;
  const int era = (year >= 0 ? year : year - 399) / 400;
  const unsigned yearOfEra = static_cast<unsigned>(year - era * 400);
  const unsigned marchMonth = month > 2 ? month - 3 : month + 9;
  const unsigned dayOfYear = (153 * marchMonth + 2) / 5 + day - 1;
  const unsigned dayOfEra = yearOfEra * 365 + yearOfEra / 4 - yearOfEra / 100 + dayOfYear;
  return era * 146097 + static_cast<int>(dayOfEra) - 719468;
}

inline bool readDS3231Utc(time_t& out) {
  uint8_t status;
  if (!readRtcRegisters(RTC_STATUS_REGISTER, &status, 1) || (status & RTC_OSCILLATOR_STOPPED)) {
    return false;
  }

  uint8_t registers[7];
  if (!readRtcRegisters(RTC_TIME_REGISTER, registers, sizeof(registers))) return false;

  unsigned second, minute, hour, day, month, yearWithinCentury;
  // Reserved bits are zero. Hour must use 24 h mode and month must use century 0.
  if ((registers[0] & 0x80) || (registers[1] & 0x80) || (registers[2] & 0xC0) ||
      registers[3] < 1 || registers[3] > 7 || (registers[4] & 0xC0) || (registers[5] & 0xE0) ||
      !decodeBcd(registers[0], second) || !decodeBcd(registers[1], minute) ||
      !decodeBcd(registers[2], hour) || !decodeBcd(registers[4], day) ||
      !decodeBcd(registers[5], month) || !decodeBcd(registers[6], yearWithinCentury) ||
      second > 59 || minute > 59 || hour > 23 || month < 1 || month > 12) {
    return false;
  }

  const unsigned year = 2000 + yearWithinCentury;
  if (day < 1 || day > daysInMonth(year, month)) return false;
  const int64_t epoch = int64_t{civilDays(year, month, day)} * 86400 +
                        hour * 3600 + minute * 60 + second;
  if (!validClockEpoch(epoch)) return false;

  out = static_cast<time_t>(epoch);
  return true;
}

inline bool writeDS3231Utc(time_t epoch) {
  struct tm utc;
  if (!validClockEpoch(epoch) || !gmtime_r(&epoch, &utc)) return false;

  Wire.beginTransmission(RTC_ADDRESS);
  Wire.write(RTC_TIME_REGISTER);
  Wire.write(decToBcd(utc.tm_sec));
  Wire.write(decToBcd(utc.tm_min));
  Wire.write(decToBcd(utc.tm_hour));
  Wire.write(decToBcd(utc.tm_wday + 1));
  Wire.write(decToBcd(utc.tm_mday));
  Wire.write(decToBcd(utc.tm_mon + 1));
  Wire.write(decToBcd(utc.tm_year - 100));
  if (Wire.endTransmission() != 0) return false;

  uint8_t status;
  if (!readRtcRegisters(RTC_STATUS_REGISTER, &status, 1)) return false;
  Wire.beginTransmission(RTC_ADDRESS);
  Wire.write(RTC_STATUS_REGISTER);
  Wire.write(static_cast<uint8_t>(status & ~RTC_OSCILLATOR_STOPPED));
  return Wire.endTransmission() == 0;
}

inline bool systemTimeValid() {
  return validClockEpoch(time(nullptr));
}

inline void restoreClockFromRtc() {
  time_t utc;
  if (readDS3231Utc(utc)) {
    struct timeval tv = {static_cast<long>(utc), 0};
    settimeofday(&tv, nullptr);
  }
}

inline bool localClock(uint16_t& minute, uint32_t& dayKey) {
  const time_t utc = time(nullptr);
  struct tm local;
  if (!validClockEpoch(utc) || !localtime_r(&utc, &local)) return false;
  minute = static_cast<uint16_t>(60 * local.tm_hour + local.tm_min);
  dayKey = static_cast<uint32_t>(local.tm_year + 1900) * 1000u +
           static_cast<uint32_t>(local.tm_yday);
  return true;
}
}
