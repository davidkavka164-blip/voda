#pragma once
#include <stdint.h>
// Pure C++11, deterministic / host-testable. NOT a controller for Kerbl motor.
// Sends momentary button contacts only. Kerbl retains ALL real motor safety.
namespace hcckerbl {
enum class Position : uint8_t { UNKNOWN, OPEN, CLOSED, MOVING, FAULT };
enum class Fault : uint8_t { NONE, SWITCH_CONFLICT, SAFETY_LOOP, TRAVEL_TIMEOUT, POSITION_LOST, OUTPUT_INTERLOCK };
enum class Request : uint8_t { NONE, OPEN, CLOSE };
struct Output {
  Position position; Fault fault; bool relay_open; bool relay_close;
  bool verified; bool pending; bool pulse; bool assumed_manual;
};
class Debounce {
 public:
  explicit Debounce(uint32_t ms=80):duration_(ms){}
  void update(bool value,uint32_t now){
    if(!started_){started_=true;raw_=value;changed_=now;return;}
    if(value!=raw_){raw_=value;changed_=now;}
    if((uint32_t)(now-changed_)>=duration_){ready_=true;stable_=raw_;}
  }
  bool ready()const{return ready_;}
  bool value()const{return stable_;}
 private:
  const uint32_t duration_;
  uint32_t changed_=0;
  bool started_=false,ready_=false,raw_=false,stable_=false;
};
class Interface {
 public:
  Interface(uint32_t pulse_ms=350,uint32_t timeout_ms=60000,uint32_t cooldown_ms=10000):
    pulse_ms_(pulse_ms),timeout_ms_(timeout_ms),cooldown_ms_(cooldown_ms){}
  Output tick(bool raw_open,bool raw_closed,bool safety_ok,bool authorized,
              Request request,uint32_t now){
    op_.update(raw_open,now);cl_.update(raw_closed,now);
    const bool stable=op_.ready()&&cl_.ready() &&
                      op_.value()==raw_open && cl_.value()==raw_closed;
    // Never energize two outputs or permit unstable/contradictory sensors.
    if(fault_!=Fault::NONE)return output();
    if(raw_open&&raw_closed)fail(Fault::SWITCH_CONFLICT);
    else if(!safety_ok)fail(Fault::SAFETY_LOOP);
    else if(!authorized && pulse_)fail(Fault::OUTPUT_INTERLOCK);
    if(fault_!=Fault::NONE)return output();
    if(stable){
      if(op_.value()&&!cl_.value()) {position_=Position::OPEN;seen_position_=true;}
      else if(!op_.value()&&cl_.value()){position_=Position::CLOSED;seen_position_=true;}
      else position_=Position::UNKNOWN;
    }else position_=Position::UNKNOWN;
    if(pulse_){
      if((uint32_t)(now-started_)>=pulse_ms_){pulse_=false;awaiting_=true;}
      else return output();
    }
    if(awaiting_){
      // Require destination contact; a mere command is never verification.
      if(stable && ((target_==Request::OPEN&&position_==Position::OPEN)||
                    (target_==Request::CLOSE&&position_==Position::CLOSED))){
        awaiting_=false;target_=Request::NONE;
      }else if((uint32_t)(now-started_)>=timeout_ms_){fail(Fault::TRAVEL_TIMEOUT);}
      else position_=Position::MOVING;
      return output();
    }
    if(seen_position_ && position_==Position::UNKNOWN){
      if(!unlocated_){unlocated_=true;unlocated_at_=now;}
      if((uint32_t)(now-unlocated_at_)>=timeout_ms_)fail(Fault::POSITION_LOST);
    }else unlocated_=false;
    if(fault_!=Fault::NONE)return output();
    if(request!=Request::NONE && authorized && stable &&
       cooldownReady(now) &&
       ((request==Request::OPEN&&position_==Position::CLOSED)||
        (request==Request::CLOSE&&position_==Position::OPEN))){
      target_=request; pulse_=true; started_=now;
      last_command_=now;has_command_=true;assumed_manual_=true;
    }
    return output();
  }
  bool cooldownReady(uint32_t now)const{return !has_command_ || (uint32_t)(now-last_command_)>=cooldown_ms_;}
  // Acknowledgement must be explicit, with both loops good and exactly one stable limit.
  bool acknowledge(bool raw_open,bool raw_closed,bool safety_ok){
    if(fault_==Fault::NONE||!safety_ok||raw_open==raw_closed || !op_.ready()||!cl_.ready()||
       op_.value()!=raw_open||cl_.value()!=raw_closed)return false;
    fault_=Fault::NONE;stop();position_=raw_open?Position::OPEN:Position::CLOSED;
    unlocated_=false;seen_position_=true;return true;
  }
  // Releasing a contact cannot stop Kerbl. Keep monitoring its destination.
  void disarm(){if(pulse_){pulse_=false;awaiting_=true;}}
  bool everLocated()const{return seen_position_;}
  Output output()const{
    const Position reported = fault_!=Fault::NONE ? Position::FAULT :
      (pulse_ || awaiting_ ? Position::MOVING : position_);
    return {reported,fault_,
      pulse_&&target_==Request::OPEN,pulse_&&target_==Request::CLOSE,
      !pulse_&&!awaiting_&&fault_==Fault::NONE&&
      (position_==Position::OPEN||position_==Position::CLOSED),awaiting_,pulse_,assumed_manual_};
  }
 private:
  void stop(){pulse_=false;awaiting_=false;target_=Request::NONE;}
  void fail(Fault f){stop();fault_=f;position_=Position::FAULT;}
  Debounce op_,cl_;
  const uint32_t pulse_ms_,timeout_ms_,cooldown_ms_;
  Position position_=Position::UNKNOWN;
  Fault fault_=Fault::NONE;
  Request target_=Request::NONE;
  uint32_t started_=0,last_command_=0,unlocated_at_=0;
  bool pulse_=false,awaiting_=false,has_command_=false,assumed_manual_=false,
       seen_position_=false,unlocated_=false;
};
inline const char* positionName(Position p){
  switch(p){case Position::UNKNOWN:return "UNKNOWN";case Position::OPEN:return "OPEN";
  case Position::CLOSED:return "CLOSED";case Position::MOVING:return "MOVING";
  case Position::FAULT:return "FAULT";}return "INVALID";
}
inline const char* faultName(Fault f){
  switch(f){case Fault::NONE:return "NONE";case Fault::SWITCH_CONFLICT:return "SWITCH_CONFLICT";
  case Fault::SAFETY_LOOP:return "SAFETY_LOOP";case Fault::TRAVEL_TIMEOUT:return "TRAVEL_TIMEOUT";
  case Fault::POSITION_LOST:return "POSITION_LOST";
    case Fault::OUTPUT_INTERLOCK:return "OUTPUT_INTERLOCK";}return "INVALID";
}
}
