/* Optional egg photo camera. ESP32-CAM AI Thinker, Arduino ESP32 core 1.0.6.
 * Access via LAN/WireGuard only. No internet port-forwarding.
 * Test on bench with stable 5V supply (>=1A peak) and suitable ESP32-CAM programmer.
 */
#include <Arduino.h>
#include <string.h>
#include <WiFi.h>
#include <WebServer.h>
#include "esp_camera.h"
// Replace before deployment:
const char* WIFI_SSID="";
const char* WIFI_PASS="";
const char* WEB_USER="admin";
const char* WEB_PASS="CHANGE_CAMERA_PASSWORD";
WebServer web(80);
bool webStarted=false;
uint32_t lastRetry=0;
IPAddress lastIp;
// AI Thinker board camera pins:
#define PWDN_GPIO_NUM 32
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM 0
#define SIOD_GPIO_NUM 26
#define SIOC_GPIO_NUM 27
#define Y9_GPIO_NUM 35
#define Y8_GPIO_NUM 34
#define Y7_GPIO_NUM 39
#define Y6_GPIO_NUM 36
#define Y5_GPIO_NUM 21
#define Y4_GPIO_NUM 19
#define Y3_GPIO_NUM 18
#define Y2_GPIO_NUM 5
#define VSYNC_GPIO_NUM 25
#define HREF_GPIO_NUM 23
#define PCLK_GPIO_NUM 22
bool authorized(){if(web.authenticate(WEB_USER,WEB_PASS))return true;web.requestAuthentication();return false;}
void takePhoto(){
  if(!authorized())return;
  // With one framebuffer the first returned frame can have been queued before the request.
  camera_fb_t* cached=esp_camera_fb_get();
  if(cached)esp_camera_fb_return(cached);
  camera_fb_t* fb=esp_camera_fb_get();
  if(!fb){web.send(503,"text/plain","Camera failed");return;}
  WiFiClient client=web.client();
  client.print("HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nCache-Control: no-store\r\nConnection: close\r\nContent-Length: ");
  client.print(fb->len);client.print("\r\n\r\n");
  if(client.write(fb->buf,fb->len)!=fb->len)Serial.println("Incomplete JPEG transfer");
  esp_camera_fb_return(fb);
  client.stop();
}
void setup(){
  Serial.begin(115200);
  if(!strlen(WIFI_SSID) || strlen(WEB_PASS)<8 ||
     strcmp(WEB_PASS,"CHANGE_CAMERA_PASSWORD")==0){
    Serial.println("Configure camera WiFi and replace the web password");
    return;
  }
  camera_config_t cfg={};
  cfg.ledc_channel=LEDC_CHANNEL_0;cfg.ledc_timer=LEDC_TIMER_0;
  cfg.pin_d0=Y2_GPIO_NUM;cfg.pin_d1=Y3_GPIO_NUM;
  cfg.pin_d2=Y4_GPIO_NUM;cfg.pin_d3=Y5_GPIO_NUM;
  cfg.pin_d4=Y6_GPIO_NUM;cfg.pin_d5=Y7_GPIO_NUM;
  cfg.pin_d6=Y8_GPIO_NUM;cfg.pin_d7=Y9_GPIO_NUM;
  cfg.pin_xclk=XCLK_GPIO_NUM;cfg.pin_pclk=PCLK_GPIO_NUM;
  cfg.pin_vsync=VSYNC_GPIO_NUM;cfg.pin_href=HREF_GPIO_NUM;
  cfg.pin_sscb_sda=SIOD_GPIO_NUM;cfg.pin_sscb_scl=SIOC_GPIO_NUM;
  cfg.pin_pwdn=PWDN_GPIO_NUM;cfg.pin_reset=RESET_GPIO_NUM;
  cfg.xclk_freq_hz=20000000;cfg.pixel_format=PIXFORMAT_JPEG;
  cfg.frame_size=FRAMESIZE_VGA;cfg.jpeg_quality=12;cfg.fb_count=1;
  if(esp_camera_init(&cfg)!=ESP_OK){Serial.println("Camera init failed");return;}
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID,WIFI_PASS);
  web.on("/",HTTP_GET,[](){if(!authorized())return;web.send(200,"text/html; charset=utf-8","<h2>HCC kamera vajec</h2><p><a href='/jpg'>Pořídit fotografii</a></p>");});
  web.on("/jpg",HTTP_GET,takePhoto);
  web.begin();
  webStarted=true;
}
void loop(){
  if(webStarted){
    if(WiFi.status()==WL_CONNECTED){
      if(WiFi.localIP()!=lastIp){
        lastIp=WiFi.localIP();
        Serial.print("Camera LAN IP: ");Serial.println(lastIp);
      }
      web.handleClient();
    }else{
      lastIp=IPAddress();
      const uint32_t now=millis();
      if((uint32_t)(now-lastRetry)>=30000){
        lastRetry=now;
        WiFi.reconnect();
      }
    }
  }
  delay(2);
}
