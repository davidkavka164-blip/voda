#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
build_dir=$(mktemp -d)
trap 'rm -rf "$build_dir"' EXIT
flags=(-std=c++11 -O2 -Wall -Wextra -Werror -pedantic)
for suite in kerbl aux rtc; do
  "${CXX:-g++}" "${flags[@]}" -Irtc_stubs -I../HCC_CONTROLLER_REV16 "test_${suite}_rev16.cpp" -o "$build_dir/$suite"
  "$build_dir/$suite"
done
