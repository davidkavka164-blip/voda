#include <cassert>
#include <cstdint>
#include <iostream>
#include "../HCC_CONTROLLER_REV16/kerbl_interface.hpp"
using namespace hcckerbl;
static Output tick(Interface& k, bool o, bool c, bool safe, bool armed, Request r, uint32_t t){
 return k.tick(o,c,safe,armed,r,t);
}
int main(){
  {
    Interface k(350,60000,10000);
    auto s=tick(k,false,true,true,false,Request::OPEN,0);
    assert(!s.relay_open && !s.relay_close && !s.verified);
    s=tick(k,false,true,true,false,Request::OPEN,100);
    assert(s.position==Position::CLOSED && !s.relay_open);
    s=tick(k,false,true,true,true,Request::OPEN,101);
    assert(s.pulse && s.relay_open && !s.relay_close);
    s=tick(k,false,true,true,true,Request::NONE,451);
    assert(!s.relay_open && s.pending);
    assert(!k.acknowledge(false,true,true));
    assert(k.output().pending && !k.output().verified);
    s=tick(k,false,false,true,true,Request::CLOSE,600);
    assert(s.pending && !s.verified);
    s=tick(k,true,false,true,true,Request::NONE,1000);
    assert(s.pending);
    s=tick(k,true,false,true,true,Request::NONE,1100);
    assert(s.position==Position::OPEN && s.verified && !s.pending);
    s=tick(k,true,false,true,true,Request::CLOSE,1101); // cooldown
    assert(!s.pulse);
    s=tick(k,true,false,true,true,Request::CLOSE,10101);
    assert(s.relay_close && !s.relay_open);
    s=tick(k,true,false,true,true,Request::NONE,10500);
    assert(!s.relay_close && s.pending);
    s=tick(k,false,true,true,true,Request::NONE,11000);
    s=tick(k,false,true,true,true,Request::NONE,11100);
    assert(s.position==Position::CLOSED && s.verified);
  }
  {
    Interface k;
    tick(k,true,true,true,true,Request::NONE,0);
    auto s=tick(k,true,true,true,true,Request::OPEN,100);
    assert(s.position==Position::FAULT && s.fault==Fault::SWITCH_CONFLICT && !s.relay_open);
    assert(!k.acknowledge(false,false,true));
    tick(k,false,true,true,true,Request::NONE,200);
    tick(k,false,true,true,true,Request::NONE,300);
    assert(k.acknowledge(false,true,true));
    s=tick(k,false,true,true,true,Request::OPEN,301);
    assert(s.relay_open);
    s=tick(k,false,true,false,true,Request::NONE,302);
    assert(s.fault==Fault::SAFETY_LOOP && !s.relay_open);
  }
  {
    Interface k(350,1000,0);
    tick(k,false,true,true,true,Request::NONE,0);
    tick(k,false,true,true,true,Request::NONE,90);
    auto s=tick(k,false,true,true,true,Request::OPEN,100);
    assert(s.pulse);
    s=tick(k,false,true,true,true,Request::NONE,1200);
    assert(s.fault==Fault::TRAVEL_TIMEOUT && !s.relay_open && !s.relay_close);
  }
  {
    Interface k;
    tick(k,false,true,true,true,Request::NONE,0);
    tick(k,false,true,true,true,Request::NONE,120);
    auto s=tick(k,false,true,true,true,Request::OPEN,130);
    assert(s.relay_open);
    k.disarm();
    s=k.output();
    assert(!s.relay_open && !s.relay_close && s.pending);
    s=tick(k,false,false,true,false,Request::NONE,900);
    assert(s.pending && s.position==Position::MOVING);
    tick(k,true,false,true,false,Request::NONE,1000);
    s=tick(k,true,false,true,false,Request::NONE,1100);
    assert(s.verified && s.position==Position::OPEN && s.fault==Fault::NONE);
  }
  {
    Interface k(350,1000,0);
    tick(k,false,true,true,false,Request::NONE,0);
    auto s=tick(k,false,true,true,false,Request::NONE,90);
    assert(s.verified && k.everLocated());
    s=tick(k,false,false,true,false,Request::NONE,150);
    assert(s.position==Position::UNKNOWN && s.fault==Fault::NONE && k.everLocated());
    s=tick(k,false,false,true,false,Request::NONE,1149);
    assert(s.fault==Fault::NONE);
    s=tick(k,false,false,true,false,Request::NONE,1150);
    assert(s.fault==Fault::POSITION_LOST);
  }
  {
    Interface k(350,60000,0);
    tick(k,false,true,true,true,Request::NONE,0);
    tick(k,false,true,true,true,Request::NONE,100);
    assert(tick(k,false,true,true,true,Request::OPEN,101).relay_open);
    auto s=tick(k,false,true,true,false,Request::NONE,102);
    assert(s.fault==Fault::OUTPUT_INTERLOCK && !s.relay_open);
    s=tick(k,true,true,false,false,Request::NONE,103);
    assert(s.fault==Fault::OUTPUT_INTERLOCK);
  }
  {
    Interface k(350,60000,0);
    const uint32_t start=UINT32_MAX-200;
    tick(k,false,true,true,true,Request::NONE,start);
    tick(k,false,true,true,true,Request::NONE,start+90);
    auto s=tick(k,false,true,true,true,Request::OPEN,start+100);
    assert(s.relay_open);
    s=tick(k,false,true,true,true,Request::NONE,300); // rollover
    assert(!s.relay_open && s.pending);
  }
  std::cout<<"REV16 Kerbl state-machine tests OK\n";
}
