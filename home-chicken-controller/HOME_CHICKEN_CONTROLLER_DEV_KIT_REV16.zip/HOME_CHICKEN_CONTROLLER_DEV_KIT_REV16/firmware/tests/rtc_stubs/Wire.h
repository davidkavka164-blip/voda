#pragma once
#include <stdint.h>
#include <array>
#include <cassert>
#include <vector>

class TwoWire {
public:
  std::array<uint8_t, 16> registers{};
  bool failTransmission = false;
  bool truncateRead = false;

  void beginTransmission(uint8_t address) {
    assert(address == 0x68);
    writes.clear();
  }

  void write(uint8_t value) { writes.push_back(value); }

  int endTransmission(bool = true) {
    if (failTransmission) return 4;
    assert(!writes.empty());
    offset = writes.front();
    for (unsigned i = 1; i < writes.size(); ++i) {
      registers.at(offset++) = writes[i];
    }
    return 0;
  }

  uint8_t requestFrom(uint8_t address, uint8_t count) {
    assert(address == 0x68);
    return truncateRead ? static_cast<uint8_t>(count - 1) : count;
  }

  int read() { return registers.at(offset++); }

private:
  std::vector<uint8_t> writes;
  unsigned offset = 0;
};

extern TwoWire Wire;
