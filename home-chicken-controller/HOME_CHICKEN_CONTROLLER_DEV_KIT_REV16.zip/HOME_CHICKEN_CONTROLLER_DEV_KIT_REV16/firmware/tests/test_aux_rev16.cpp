#include <cassert>
#include <cstdint>
#include <iostream>
#include "../HCC_CONTROLLER_REV16/commission_gate.hpp"
#include "../HCC_CONTROLLER_REV16/policy.hpp"
static void testLocalButtons(){
  using hcckerbl::Request;
  const Request none=Request::NONE;
  hcc11::LocalButtons buttons;
  hcc11::CommissionHold hold;
  buttons.tick(true,true,0);
  auto gesture=buttons.tick(true,true,80);
  assert(!gesture.bothHeld && gesture.single==none);
  assert(!buttons.tick(true,true,6000).bothHeld); // held at boot
  buttons.tick(false,false,6010);
  buttons.tick(false,false,6090);

  // A short single press commands only at its own stable release.
  assert(buttons.tick(true,false,6200).single==none);
  assert(buttons.tick(true,false,6280).single==none);
  assert(buttons.tick(false,false,6350).single==none);
  assert(buttons.tick(false,false,6430).single==Request::OPEN);

  // A staggered chord cancels the first press and never emits a command.
  buttons.tick(true,false,6500);
  buttons.tick(true,false,6580);
  buttons.tick(true,true,6800);
  gesture=buttons.tick(true,true,6880);
  assert(gesture.bothHeld && gesture.single==none);
  assert(!hold.tick(gesture.bothHeld,true,6880));
  gesture=buttons.tick(true,true,11880);
  assert(hold.tick(gesture.bothHeld,true,11880) && gesture.single==none);
  gesture=buttons.tick(true,false,11881);
  assert(!gesture.bothHeld && gesture.single==none);
  assert(!hold.tick(gesture.bothHeld,true,11881));
  buttons.tick(false,false,11960);
  assert(buttons.tick(false,false,12040).single==none);

  buttons.tick(false,true,12100);
  buttons.tick(false,true,12180);
  buttons.tick(false,false,13000);
  assert(buttons.tick(false,false,13080).single==Request::CLOSE);
  buttons.tick(false,true,13300);
  buttons.tick(false,true,13400);
  buttons.tick(false,false,15401);
  assert(buttons.tick(false,false,15481).single==none);

  buttons.tick(true,true,15500);
  assert(buttons.tick(true,true,15600).bothHeld);
  buttons.requireRelease(); // service lock during a hold
  assert(!buttons.tick(true,true,22000).bothHeld);
  buttons.tick(false,false,22001);
  assert(buttons.tick(false,false,22100).single==none);
  buttons.tick(true,true,22200);
  assert(buttons.tick(true,true,22300).bothHeld);
}
int main(){
  testLocalButtons();
  hcc11::CommissionHold c;
  assert(!c.tick(true,true,0));
  assert(!c.tick(true,true,4999));
  assert(c.tick(true,true,5000));
  assert(!c.tick(true,true,6000)); // no repeat with held buttons
  assert(!c.tick(false,true,6100));
  assert(!c.tick(true,false,6200)); // denied if initially unsafe
  assert(!c.tick(true,true,13000));
  assert(!c.tick(false,true,13001));
  assert(!c.tick(true,true,13002));
  assert(!c.tick(true,false,16000)); // interrupted by safety issue
  assert(!c.tick(true,true,19000));
  assert(!c.tick(false,true,19001));
  assert(!c.tick(true,true,19002));
  assert(c.tick(true,true,24002));
  hcc7::EggHeaterPolicy heater;
  hcc7::HeatInputs in={};
  in.installed=true;in.armed=true;in.rtc_ok=true;in.sensor_ok=true;
  in.battery_ok=true;in.hard_thermal_ok=true;
  in.local_min=500;in.start_min=420;in.end_min=960;in.temp_c=0.0f;
  assert(heater.tick(in));
  in.sensor_ok=false;assert(!heater.tick(in));
  in.sensor_ok=true;in.rtc_ok=false;assert(!heater.tick(in));
  in.rtc_ok=true;in.hard_thermal_ok=false;assert(!heater.tick(in));
  in.hard_thermal_ok=true;in.battery_ok=false;assert(!heater.tick(in));
  in.battery_ok=true;in.temp_c=8.0f;assert(!heater.tick(in));
  assert(!hcc7::batteryCanHeat(24.0f));
  assert(hcc7::batteryCanHeat(27.0f));
  std::cout<<"REV16 heater and local commissioning tests OK\n";
}
