#include <cassert>
#include <iostream>
#include "rtc_ds3231.hpp"

TwoWire Wire;

static void loadDate(uint8_t day, uint8_t month, uint8_t year,
                     uint8_t hour = 0, uint8_t minute = 0, uint8_t second = 0) {
  Wire.registers = {second, minute, hour, 1, day, month, year};
}

int main() {
  using namespace hcc7;
  time_t epoch = 0;
  loadDate(0x22, 0x11, 0x26);
  assert(readDS3231Utc(epoch) && epoch == 1795305600);

  Wire.registers[RTC_STATUS_REGISTER] = RTC_OSCILLATOR_STOPPED;
  assert(!readDS3231Utc(epoch));
  Wire.registers[RTC_STATUS_REGISTER] = 0;
  Wire.failTransmission = true;
  assert(!readDS3231Utc(epoch));
  Wire.failTransmission = false;
  Wire.truncateRead = true;
  assert(!readDS3231Utc(epoch));
  Wire.truncateRead = false;

  loadDate(0x29, 0x02, 0x28);
  assert(readDS3231Utc(epoch));
  loadDate(0x29, 0x02, 0x27);
  assert(!readDS3231Utc(epoch));
  loadDate(0x31, 0x04, 0x27);
  assert(!readDS3231Utc(epoch));
  loadDate(0x1A, 0x11, 0x26);
  assert(!readDS3231Utc(epoch));
  loadDate(0x22, 0x0A, 0x26);
  assert(!readDS3231Utc(epoch));
  loadDate(0x22, 0x11, 0x2A);
  assert(!readDS3231Utc(epoch));
  loadDate(0x22, 0x11, 0x26, 0x41);
  assert(!readDS3231Utc(epoch));
  loadDate(0x22, 0x11, 0x26, 0x24);
  assert(!readDS3231Utc(epoch));
  loadDate(0x22, 0x91, 0x26);
  assert(!readDS3231Utc(epoch));

  loadDate(0x19, 0x01, 0x38, 0x03, 0x14, 0x07);
  assert(readDS3231Utc(epoch) && epoch == INT32_MAX);
  Wire.registers[RTC_TIME_REGISTER] = 0x08;
  assert(!readDS3231Utc(epoch) && epoch == INT32_MAX);
  assert(!validClockEpoch(int64_t{INT32_MAX} + 1));
  assert(!validClockEpoch(MIN_CLOCK_EPOCH));
  assert(validClockEpoch(MIN_CLOCK_EPOCH + 1));

  Wire.registers[RTC_STATUS_REGISTER] = 0x83;
  assert(writeDS3231Utc(1795305600));
  assert(Wire.registers[RTC_STATUS_REGISTER] == 0x03);
  assert(readDS3231Utc(epoch) && epoch == 1795305600);
  assert(!writeDS3231Utc(0));
  std::cout << "RTC PASS: 22 checks\n";
}
