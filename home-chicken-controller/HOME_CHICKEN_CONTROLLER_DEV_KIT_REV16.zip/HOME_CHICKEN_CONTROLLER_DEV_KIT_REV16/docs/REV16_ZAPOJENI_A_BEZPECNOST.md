# REV16 – zapojení ESP32 a originálního pohonu Kerbl 70550

Sada Kerbl **70546** obsahuje pohon **70550**, posuvný panel velikosti M **70570**, napáječ a 4× AA. ESP32 vysílá krátké povely přes relé a čte nezávislé polohové kontakty. Čas, světelný senzor a pohyb motoru nadále řídí Kerbl. Čísla na straně ESP32 níže označují GPIO.

## Napájení Kerbl

Výchozí volba je **4× AA v originálním držáku**, při prvním oživení použij baterie ze sady. Při výpadku hlavní 24V baterie, měniče či ESP32 pokračuje Kerbl ve vlastním programu, pokud jsou AA v pořádku a Kerbl je v AUTO. Po výměně AA ověř datum, čas, AUTO a AC ON. Symbol slabé baterie sleduj na displeji Kerbl. Jako běžnou náhradní sadu lze použít čtyři stejné nenabíjecí alkalické AA/LR6 1,5 V po ověření typu podle dodaného kusu, například balení Geti z nákupního seznamu. Napětí hlavní baterie na ESP32 neukazuje stav AA.

Pro jinou variantu výrobce nabízí kabel **Kerbl 70557** pro 70550 z **externího nominálně 12V akumulátoru**, s originální 2A pojistkou. Zapoj kladný červený přívod kabelu na plus akumulátoru a postupuj podle návodu k jeho zápornému přívodu i napájecímu konektoru 70550. Do napájecího konektoru Kerbl nepřiváděj 24 V. Připojení k centrálnímu 24→12V měniči a případná souběžná záloha AA vyžadují potvrzení výrobce pro použitý zdroj a zařízení. Pro základní sestavu ponech Kerbl s vlastními AA.

Pro servis dvířka mechanicky zajisti a odpoj **všechny** zdroje Kerbl, včetně vyjmutí AA a odpojení externího kabelu, pokud je osazený. Servisní zámek ESP32, blokace GPIO18/19 a výpadek reléové větve pouze odepřou externí povely. Běžící nebo vlastní naplánovaný pohyb Kerbl tím nezastavíš.

## Vybraná relé a řízení GPIO

Použij **2 kusy Drátek 1517435132**, mechanický jednokanálový reléový modul 5 V s kontakty COM, NO a NC a volbou spínací úrovně. Relé K1 je OTEVŘÍT, K2 ZAVŘÍT. Obě propojky nastav na **LOW**. Napájej oba moduly z jištěné 5V větve a připoj jejich GND ke GND ESP32. Kerbl zůstává na druhé straně kontaktů elektricky oddělený.

Vstup každého relé stáhni na GND přes vlastní tranzistor **BC337-40**. Díky tomu zůstává ovládání na ESP32 aktivní úrovní HIGH, i když samotný modul spíná při LOW. GPIO připojuj jen k bázi přes rezistor, protože IN má tah na 5 V.

| Vodič nebo součástka | K1 OTEVŘÍT | K2 ZAVŘÍT |
|---|---|---|
| GPIO přes 1 kΩ na bázi NPN | GPIO25 → R1 → B Q1 | GPIO26 → R2 → B Q2 |
| Vypínací odpor báze | B Q1 → 10 kΩ → GND | B Q2 → 10 kΩ → GND |
| Emitor | E Q1 → GND ESP32 a modulu | E Q2 → GND ESP32 a modulu |
| Kolektor | C Q1 → IN modulu K1 | C Q2 → IN modulu K2 |
| Tah vstupu modulu | IN K1 → 10 kΩ → +5V napájení K1 | IN K2 → 10 kΩ → +5V napájení K2 |

Ověř orientaci B/C/E podle datového listu skutečné dodávky, protože ji nelze určit jen z označení TO‑92. GPIO LOW nebo vysoká impedance při resetu ponechá tranzistor vypnutý, IN na +5 V a relé v klidu. GPIO HIGH stáhne IN a sepne relé. Teoretický proud vstupu podle prodejce je kolem 5 mA plus 0,5 mA z tahu 10 kΩ. Před připojením Kerbl ověř skutečné úrovně a chování při pomalém náběhu napájení, výpadku a resetu s aktivní 5V větví. Pokud relé sepne bez povelu, zapojení oprav a test opakuj.

### Suché kontakty Kerbl a přednost OTEVŘÍT

Návod pro 70550, kap. 8.4.2, ukazuje svorkovnici **OPEN – V – CLOSE** s V jako společným bodem kontaktů. Ověř označení a obrázek v návodu dodaného kusu bez napájení. V může být označeno společně s UP/DOWN. Vodiče Kerbl patří pouze na kontakty relé níže. V je společný pól ovládacích kontaktů uvnitř Kerbl a nespojuje se s napájením ani GND ESP32.

| Od | Kam |
|---|---|
| Kerbl V | K1 COM |
| Kerbl OPEN | K1 NO |
| K1 NC | K2 COM |
| Kerbl CLOSE | K2 NO |
| K2 NC | Nechat volnou |

V klidu zůstanou OPEN i CLOSE rozpojené. K2 může připojit CLOSE k V pouze přes klidový kontakt K1. K1 přepne V na OPEN a nejprve odpojí CLOSE, pokud skutečné relé při přepnutí rozpojuje před sepnutím (break-before-make). Oba povely proto nelze **trvale** sepnout v normálním stavu kontaktů. Při chybném souběžném náběhu obou cívek však rozdílná rychlost relé může vytvořit nejdříve krátký CLOSE a poté OPEN. Zapojení nekryje svařený kontakt a nenahrazuje bezpečnostní blokaci pohybu Kerbl.

| K1 | K2 | Průchod z Kerbl V ve stabilním stavu |
|---|---|---|
| vypnuto | vypnuto | žádný |
| zapnuto | vypnuto | pouze OPEN |
| vypnuto | zapnuto | pouze CLOSE |
| zapnuto | zapnuto | pouze OPEN |

Stav NO/NC, stabilní tabulku, přechody a zpoždění odpadnutí proměř s Kerbl odpojeným. Katalog modulu neuvádí minimální spolehlivý proud kontaktu. Při navazující zkoušce s Kerbl ověř opakovanou reakci na oba povely bez zvířat. Ověř, že COM–NC a COM–NO na K1 nejsou při přepínání současně propojeny. Krátké impulzy při náběhu výstupů kontroluj osciloskopem nebo logickým analyzátorem s bezpečným zkušebním obvodem. Přepojení, zkoušku obou cívek současně a servisní manipulaci dělej bez připojeného pohonu.

## Ostatní signály a větve

| Funkce | GPIO | Propojení |
|---|---:|---|
| OTEVŘENO, ZAVŘENO | 32, 33 | Dva nezávislé NO polohové kontakty na GND. LOW až u bezpečně potvrzené koncové polohy. |
| Servisní blokace povelů | 18, 19 | Každý přes samostatný bezpotenciálový NC diagnostický kontakt na GND. LOW = průchod povelu dovolen, HIGH = blokace nebo přerušený vodič. Připoj skutečné kontakty. |
| Místní tlačítka | 13, 14 | Dvě NO tlačítka na GND. Místní uvedení do provozu podle instalačního návodu. |
| Ohřev vajec | 16 | SIG 3,3 V aktivní HIGH na DFR0457, 10 kΩ pull-down u vstupu. Řídicí VCC/GND podle modulu. |
| Stav termostatu | 17 | Vlastní bezpotenciálový NC na GND. Oddělen od 12V výkonových kontaktů. |
| DS18B20 | 4 | Třívodičová čidla 3,3 V, DQ s 4,7 kΩ na 3V3. |
| RTC DS3231 | 21, 22 | SDA, SCL a pull-upy na 3V3. Nenabíjecí modul pro CR2032. |
| Napětí hlavní baterie | 34 | Jištěný kladný rozvod → 120 kΩ 1 % → GPIO34 → 10 kΩ 1 % → GND. Připoj 100 nF z GPIO34 na GND přímo u ESP32. |
| Alarm RUT241 | 27 | GPIO27 → 470 Ω → LED PC817 → GND ESP32. Kolektor na DI routeru, emitor na GND routeru. Návrhový pull-up DI k jeho napájení 12 V proměř před připojením. |
| Voda – rezerva | 39 | Stav hladiny tato revize nevyhodnocuje. |

Při 21–30 V **na vstupu děliče baterie** má být na uzlu GPIO34 asi 1,62–2,31 V. Nejdříve ověř napětí uzlu s odpojeným GPIO. Bateriové napětí nikdy nepřiváděj přímo na GPIO34. Kalibruj ADC proti multimetru podle instalačního návodu.

Napájecí větev topení: jištěných 12 V → VIN DFR0457, VOUT → výkonový NC DC termostat → tepelná pojistka → topná fólie → 12V GND. Použij kontakty a pojistku s doloženou vypínací schopností pro stejnosměrnou zátěž. Stavový termostat GPIO17 je samostatný. Fólii instaluj na vhodný kovový rozvaděč tepla dle výrobce, mimo přímý kontakt s dřevem, vejci a slepicemi. GPIO ani MOSFET nenahrazují nezávislé tepelné odpojení.

Digitální vstup RUT241 musí při zdravém ESP32 změřit LOW (0–6 V) a při alarmu nebo výpadku samotného ESP32 HIGH (8 V až napájecí napětí routeru). Pull-up 22 kΩ je návrhová hodnota původního rozhraní. Pokud uvedených mezí nedosáhne, prověř skutečné zatížení DI a vyber odpovídající rozhraní. Při výpadku napájení routeru SMS neodejde.

Hlavní jištění, odpojení FV a baterie, průřezy, samostatná jištění větví 5/12 V, ochranu DC rozvaděče, omezení mrazového nabíjení a termostaty stanov pro skutečné kabely, klimatické podmínky a komponenty. Při servisu nevystavuj napěťové vstupy ESP32 současně externímu zdroji a USB, jestliže to konkrétní deska výslovně nepovoluje.

## Podklady výrobců a dodavatele

- [Drátek 1517435132 – produkt, svorky a volba LOW/HIGH](https://dratek.cz/arduino-platforma/2947-modul-rele-5v-1-kanal-s-urovnovym-spinacem.html)
- [Eclipsera 1517435132 – montážní list modulu](https://dratek.cz/docs/produkty/0/576/1517435132.pdf)
- [Diotec BC337-40 – datový list tranzistoru](https://diotec.com/request/datasheet/bc337.pdf)
- [Drátek Geti AA/LR6 – náhradní sada čtyř článků](https://dratek.cz/arduino-platforma/232354-geti-baterie-aa-alkalicka-4-kusy.html)
- [Kerbl 70546 – kompletní sada](https://www.kerbl.co.uk/en/product/automatic-chicken-door-complete-set/169470/16242)
- [Kerbl 70550 – originální návod, česká část str. 26–31](https://www.kerbl.co.uk/ftp/product-doc/215237.pdf)
- [Kerbl 70557 – originální připojovací návod](https://www.kerbl.co.uk/ftp/product-doc/176617.pdf)
- [Kerbl 70557 – údaje kabelu pro 12 V](https://www.kerbl.com/en/product/connector-cable-for-car-electric-fence-battery-115043)
- [Teltonika RUT241 – prahy digitálního vstupu](https://wiki.teltonika-networks.com/view/RUT241_Input/Output)
