# Kerbl 70546 / 70550 v provozu

## První nastavení

1. Ověř štítek 70550 a označení skutečné svorkovnice. Připrav sestavu podle kapitol 6 a 7 návodu Kerbl. Nejdřív otestuj samotné dvířka jejich panelem.
2. Nastav čas, datum, časy pro pracovní dny a víkend, případně zvolenou kombinaci času a světla. Kerbl používá vlastní hodiny. Po výměně AA podle výrobce znovu nastav datum a čas.
3. Nastav automatický režim na panelu a ověř symbol kroužku. Zapni `AC ON`, pokud chceš povolit návrat po ručním zásahu. Podle výrobce se AUTO obnoví v příštím denním cyklu. Přesný čas ani obnovení v témže dni manuál negarantuje.

## Povel z ESP32

Místní tlačítka ESP32 a povolené webové povely pouze krátce sepnou externí kontakt. Ověřená poloha na webu pochází ze samostatných snímačů. Každý externí povel přepne Kerbl do MANUAL. Kerbl režim přes svorkovnici nesděluje. Chceš-li vrátit AUTO ihned, použij tlačítka na panelu podle § 8.4.1.

Přímé webové povely jsou výchozím nastavením vypnuté. Před případným povolením místně ověř chování při ručním povelu, fyzický návrat do AUTO a návrat po následujícím denním cyklu s AC ON. Po výpadku ESP32 nebo LTE pokračuje Kerbl z vlastního zdroje v režimu, který byl právě nastavený.

## Údržba

Nejdřív zajisti šoupátko proti pohybu. Odpoj vnější napájecí kabel a vyjmi AA, pokud jsou vložené. Ověř, že dvířka jsou zajištěná a samotný Kerbl nemá napájení. Servisní zámek ESP32 vypíná vlastní výstupy. Vlastní pohyb Kerbl řídí jeho elektronika. Snímače na GPIO18/19 blokují nové povely ESP32.

[Český návod Kerbl, § 6–10](https://www.kerbl.co.uk/ftp/product-doc/215237.pdf)
