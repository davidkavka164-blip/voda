# Ověření REV16

## Překlad a testy

| Konfigurace | Cíl | Flash | Globální paměť |
| --- | --- | ---: | ---: |
| Řídicí firmware s distribuovaným nastavením | ESP32 Dev Module | 792 094 B | 39 968 B |
| Řídicí firmware s povolenými relé, topením, potvrzenou kalibrací a webovými povely | ESP32 Dev Module | 794 194 B | 39 976 B |
| Kamerový firmware | AI Thinker ESP32‑CAM | 871 486 B | 43 644 B |

Sestaveno na Linuxu pomocí Arduino CLI 1.6.0, ESP32 core 1.0.6, OneWire 2.3.8 a DallasTemperature 3.9.0. Aktivní konfigurace byla dočasná pouze pro překlad. Distribuovaný firmware má relé, ohřev, potvrzení kalibrace a webový pohyb vypnuté.

Prošly tři hostitelské testovací sady. Ověřují stavový automat Kerbl, potvrzení poruchy, zachování sledování po servisním uzamčení, timeout, souběh vstupů, dvojstisk místních tlačítek, nezávislé podmínky ohřevu a 22 kontrol RTC. V [přejímacím protokolu](REV16_ZKUSEBNI_PROTOKOL.csv) je označený překlad a softwarové ověření. Fyzické zkoušky mají samostatné položky.

## Rozhraní zvolené pro REV16

- Kerbl 70546 s vlastními AA, alternativně 70557 se samostatným nominálním 12V akumulátorem dle výrobce.
- Dva moduly Drátek 1517435132 nastavené na LOW. GPIO spíná přes NPN budič, kontakty patří do izolovaného rozhraní Kerbl. V ustáleném stavu určuje prioritní přepínací kontakt pouze jeden povel.
- Dodané podklady obsahují 91 položek XLSX, výběr 17 shodných řádků CSV, půdorys, blokové schéma, zapojení svorek, přejímku, nastavení sítě a FVE.
- Změny napájecích parametrů, síťových údajů, kalibrace nebo umístění se provádějí podle skutečné sestavy. Fyzické sepnutí kontaktů, topení, výdrž baterie a připojení LTE nebyly v cloudovém prostředí dostupné k měření.

Před provozem se zvířaty potvrď [přejímku po montáži](REV16_NAVOD_INSTALACE_A_TESTY.md) podle skutečných podmínek. Při výběru dílů předem uzavři kotvení, jištění, konkrétní tepelné ochrany a způsob zajištění a odpojení dvířek pro servis.
