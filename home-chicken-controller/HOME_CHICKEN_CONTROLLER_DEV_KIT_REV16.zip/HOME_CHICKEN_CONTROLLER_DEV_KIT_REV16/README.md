# HOME CHICKEN CONTROLLER · REV16 / Kerbl 70546

Montážní sada pro ostrovní kurník pro deset slepic. Kerbl řídí dvířka podle vlastních hodin a světla. ESP32 čte polohu dvířek, umí vyslat místní servisní povel, měří teploty a řídí ohřev sběrného boxu. RUT241 zajišťuje vzdálený dohled a kamera samostatné fotografie. Vodu a stav slepic kontroluj osobně.

## Pořadí instalace

1. [Stavba a příprava montáže](construction/REV16_STAVBA_A_MONTAZ.md) a [pracovní půdorys](drawings/HCC_PUDORYS_ROVINA_REV16.png). Rozměry otvoru a kotvení přenes podle skutečných dílů.
2. [Nákupní seznam](components/HCC_NAKUP_REV16_KERBL.xlsx), [zapojení](docs/REV16_ZAPOJENI_A_BEZPECNOST.md), [blokové schéma](drawings/HCC_KERBL_BLOKY_REV16.png) a [napájení a nastavení FVE](docs/REV16_NAPAJENI_A_FVE.md). Vybraná dvířka Kerbl 70546 běží standardně ze 4× AA. Pro samostatnou vnější 12V baterii je k dispozici originální kabel Kerbl 70557. Hlavní 24V baterie napájí DC rozvod kurníku.
3. [Instalace a zkoušky](docs/REV16_NAVOD_INSTALACE_A_TESTY.md) a [přejímací protokol](docs/REV16_ZKUSEBNI_PROTOKOL.csv). Výchozí firmware má spínání relé i topení zablokované. Při prvním nahrání nech obě výkonové větve fyzicky odpojené.
4. [LTE, WireGuard, kamera a SMS](docs/REV16_LTE_WIREGUARD_KAMERA.md). Počítej s vlastní SIM, hesly a veřejně dosažitelným protějškem WireGuard.
5. [Provoz dvířek a režim AUTO](docs/REV16_KERBL_OVLADANI.md) a [výsledky ověření vydání](docs/REV16_OVERENI.md).

Firmware je pro ESP32 Dev Module a AI Thinker ESP32‑CAM. Sada navazuje na REV15. Pro novou montáž používej schéma, firmware a protokol REV16.
