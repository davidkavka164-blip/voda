# Začni zde · REV26

1. Otevři `DOKUMENTACE_REV26.pdf` pro tisk nebo `DOKUMENTACE_REV26.docx` pro úpravy.
2. Aktuální schéma a objednací seznam jsou uvedené v [README](README.md). K napájení použij dvě oddělené 12V větve ze stejné hlavní baterie.
3. Řídicí zdrojový soubor je `firmware/HCC_CONTROLLER_REV26/HCC_CONTROLLER_REV26.ino`. Kamera se nahrává z `firmware/HCC_CAM_REV11/HCC_CAM_REV11.ino`.
4. Po montáži, před provozem se zvířaty, vyplň [přejímací protokol](docs/REV26_ZKUSEBNI_PROTOKOL.csv).
