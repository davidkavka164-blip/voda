# Kurník na rovném terénu a montáž Kerbl

Původní dispozice počítá s deseti slepicemi, půdorysem rámu přibližně **2 400 × 2 400 mm**, vyvýšenou podlahou, chráněným větráním, třemi hnízdy a vyjímatelnou venkovní kazetou na vejce. Viz [půdorys](../drawings/HCC_PUDORYS_ROVINA_REV26.png). Otvor pro slepice určuje skutečná sada Kerbl 70546.

## Co připravit před rozřezáním a montáží

| Místo | Údaj pro montáž |
| --- | --- |
| Základy, rám, střecha | Změř podloží, rovinu, odtok a zásobu materiálu. Patky, kotvení, průřezy nosných prvků a krytinu stanov podle zatížení sněhem a větrem a skutečných profilů. Pro panely na střeše započítej jejich montáž a vzlaky. |
| Obsluha | Nech prostor pro dveře, vysunutí kazety, přístup k rozváděči, baterii a odpojení napájecího kabelu Kerbl. Montážní desku rozváděče před vrtáním rozlož v měřítku 1:1 se dvěma 12V měniči, průchodkami, rezervou pro ohyb vodičů a přístupem k pojistkám. Pro zvažovanou LiThink vyhraď samostatný nosný prostor. Návod uvádí přibližně 532 × 207 × 215 mm a 20,6 kg. Techniku odděl od vlhkosti, podestýlky a zvířat. |
| Otvor dvířek | 300 × 400 mm je rozměr šoupátka M. Přenes skutečné rozměry vodicích lišt, boční překrytí a horní dráhu. Jednotku montuj svisle s vývodem šňůry dolů pod ochranu před deštěm. |
| Trasy a jištění | Stanov délky a uložení vodičů pro FV, jednotlivé DC větve, čidla a relé. Silové a signální kabely veď odděleně a chraň před přístupem zvířat. |

## Montáž

1. Vyznač rám vodorovně. U půdorysu 2 400 × 2 400 mm je teoretická úhlopříčka přibližně 3 394 mm. Před opláštěním ověř obě úhlopříčky a rovinu. Podlahu chraň před zemní vlhkostí a zajisti omyvatelný povrch. Ověř možnost čištění a upevnění ochrany proti predátorům.
2. Připrav zkušební modul hnízda a zkontroluj odval vajec a vyjmutí kazety. Pracovní sklon 12 % znamená pokles 12 mm na 100 mm délky. Rozměry tří hnízd potvrď podle skutečných bočnic a přístupnosti pro čištění. Vyhřívací fólii montuj s ochrannými prvky a kovovým rozvodem tepla podle [elektrického návodu](../docs/REV26_ZAPOJENI_A_BEZPECNOST.md).
3. Namontuj skutečné lišty Kerbl s plynulou svislou dráhou. Panel se podle návodu zavírá vlastní tíhou. Vzdálenost šoupátka od stěny po celé dráze má být nejvýše 5 mm. U horní polohy ponech podle návodu nejméně 50 mm odstupu od překážky nebo dorazu, aby motor vypnul včas. Šňůra vede rovně, bez drhnutí. Pohyblivé části a šňůru umísti mimo místa dosahu. Před servisem měj možnost panel fyzicky zajistit a odpojit jeho všechny zdroje.
4. Namontuj dva nezávislé NO snímače polohy. V každém stabilním konci patří sepnutí právě jednomu snímači. V mezilehlé poloze jsou oba rozpojené. Ověř, že držáky a kabely snímačů neomezí chod a zůstanou přístupné k seřízení.
5. Po montáži ověř chod nejdřív panelem Kerbl. Potom proveď elektrické zkoušky a kompletní přejímku bez zvířat podle [instalačního postupu](../docs/REV26_NAVOD_INSTALACE_A_TESTY.md). U dvířek použij podmínky a postup výrobce pro ochranu při pohybu.

[Katalogová sada Kerbl 70546](https://www.kerbl.com/en/product/automatic-chicken-door-complete-set-16242) · [Český návod Kerbl, § 6](https://www.kerbl.co.uk/ftp/product-doc/215237.pdf)
