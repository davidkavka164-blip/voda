#pragma once
#include <stdint.h>
#include "config.h"
namespace hcc7 {
inline bool within(uint16_t now, uint16_t start, uint16_t end) {
  if(start>=1440 || end>=1440 || start==end || now>=1440) return false;
  return start<end ? (now>=start && now<end) : (now>=start || now<end);
}
struct HeatInputs {
  bool installed, armed, rtc_ok, sensor_ok, battery_ok, hard_thermal_ok;
  uint16_t local_min, start_min, end_min;
  float temp_c;
};
class EggHeaterPolicy {
public:
  bool tick(const HeatInputs& v) {
    if(!v.installed || !v.armed || !v.rtc_ok || !v.sensor_ok ||
       !v.battery_ok || !v.hard_thermal_ok ||
       !within(v.local_min,v.start_min,v.end_min) ||
       !(v.temp_c >= -35 && v.temp_c <= 65)) {active_=false;return false;}
    if(active_ && v.temp_c>=HCC_EGG_HEAT_OFF_C) active_=false;
    if(!active_ && v.temp_c<=HCC_EGG_HEAT_ON_C) active_=true;
    return active_;
  }
  void off() {active_=false;}
private:
  bool active_=false;
};
inline bool voltageValid(float v) {return v>=HCC_MIN_BATTERY_V && v<=HCC_MAX_BATTERY_V;}
inline bool batteryCanHeat(float v) {return voltageValid(v) && v>=HCC_HEAT_CUTOFF_V;}
inline bool batteryCanDrive(float v) {return voltageValid(v) && v>=HCC_MOTOR_CUTOFF_V;}
// Priority supply: keep the 12 V Kerbl feed permanently connected.
// Only the 12 V egg heater MOSFET is shed at low battery voltage.
// Voltage is NOT an SOC estimate; thresholds are provisional until measured.
class HeatBatteryReserve {
  static_assert(HCC_MIN_BATTERY_V<=HCC_HEAT_CUTOFF_V &&
                HCC_HEAT_CUTOFF_V<HCC_HEAT_RESTORE_V &&
                HCC_HEAT_RESTORE_V<=HCC_MAX_BATTERY_V,
                "Invalid battery reserve thresholds");
public:
  bool tick(bool calibrated, bool readingValid, float voltage) {
    if(!calibrated || !readingValid || !voltageValid(voltage)) {
      allowed_=false;
    } else {
      allowed_=voltage>=(allowed_?HCC_HEAT_CUTOFF_V:HCC_HEAT_RESTORE_V);
    }
    return allowed_;
  }
  bool allowed() const { return allowed_; }
private:
  bool allowed_=false;
};
inline bool shouldScheduleOpen(uint16_t minute, uint16_t open, uint16_t close) {
  return open<close && minute>=open && minute<close;
}
inline bool shouldScheduleClose(uint16_t minute, uint16_t open, uint16_t close) {
  return open<close && (minute<open || minute>=close);
}
}
