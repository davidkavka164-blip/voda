#pragma once
#include <stdint.h>

// Pure C++11 logic; no Arduino dependency. Ground contact must use an external
// 3.3V pull-up on ESP32 GPIO39 (which has no internal pull-up).
namespace hcc18 {
enum class WaterState : uint8_t { NOT_INSTALLED, SETTLING, OK, LOW_OR_WIRE_OPEN };
inline const char* waterStateName(WaterState s) {
  switch(s){
    case WaterState::NOT_INSTALLED:return "NOT_INSTALLED";
    case WaterState::SETTLING:return "SETTLING";
    case WaterState::OK:return "OK";
    case WaterState::LOW_OR_WIRE_OPEN:return "LOW_OR_WIRE_OPEN";
  }
  return "UNKNOWN";
}
class WaterContact {
public:
  explicit WaterContact(uint32_t debounceMs=2000u): debounceMs_(debounceMs) {}
  WaterState tick(bool installed, bool pinHigh, uint32_t now){
    if(!installed){started_=false;state_=WaterState::NOT_INSTALLED;return state_;}
    if(!started_ || pinHigh!=candidateHigh_){
      if(!started_)state_=WaterState::SETTLING;
      started_=true;candidateHigh_=pinHigh;candidateAt_=now;
    }
    if((uint32_t)(now-candidateAt_)>=debounceMs_){
      state_=candidateHigh_?WaterState::LOW_OR_WIRE_OPEN:WaterState::OK;
    }
    return state_;
  }
  WaterState state()const{return state_;}
private:
  uint32_t debounceMs_,candidateAt_=0;
  bool started_=false,candidateHigh_=false;
  WaterState state_=WaterState::NOT_INSTALLED;
};
class FreezeWarning {
public:
  bool tick(bool sensorValid,float temp,float warnAt,float clearAt){
    if(!sensorValid)return risk_; // Unknown must be separately reported as SENSOR_INVALID.
    if(temp<=warnAt)risk_=true;
    else if(temp>=clearAt)risk_=false;
    return risk_;
  }
  bool risk()const{return risk_;}
private:
  bool risk_=false;
};
class RtcBackupGuard {
public:
  bool due(bool sntpCompleted,uint32_t now){
    if(sntpCompleted&&!lastCompleted_ &&
       (!everSaved_ || (uint32_t)(now-lastSaved_)>=43200000u)) pending_=true;
    lastCompleted_=sntpCompleted;
    return pending_ && (!attempted_ || (uint32_t)(now-lastAttempt_)>=30000u);
  }
  void attempted(uint32_t now,bool success){
    lastAttempt_=now;attempted_=true;
    if(success){lastSaved_=now;everSaved_=true;pending_=false;}
  }
private:
  bool lastCompleted_=false,pending_=false,everSaved_=false,attempted_=false;
  uint32_t lastAttempt_=0,lastSaved_=0;
};
class CriticalWriteGate {
public:
  explicit CriticalWriteGate(uint32_t intervalMs=60000u):intervalMs_(intervalMs){}
  void seed(const char* previousReason){
    if(previousReason && *previousReason)copy(lastObserved_,previousReason);
  }
  void observe(const char* reason){
    if(!reason || !*reason || (reason[0]=='N' && reason[1]=='O' &&
       reason[2]=='N' && reason[3]=='E' && reason[4]==0)){
      lastObserved_[0]=0;return;
    }
    if(same(reason,lastObserved_))return;
    copy(lastObserved_,reason);copy(pending_,reason);pendingExists_=true;
  }
  bool due(uint32_t now) const {
    return pendingExists_ && (!attempted_ || (uint32_t)(now-lastAttempt_)>=intervalMs_);
  }
  const char* pending()const{return pending_;}
  void attempted(uint32_t now,bool success){
    attempted_=true;lastAttempt_=now;
    if(success)pendingExists_=false;
  }
private:
  static bool same(const char* a,const char* b){
    for(unsigned i=0;i<47;i++){if(a[i]!=b[i])return false;if(a[i]==0)return true;}
    return true;
  }
  static void copy(char* target,const char* src){
    unsigned i=0;for(;i<47&&src[i];++i)target[i]=src[i];target[i]=0;
  }
  uint32_t intervalMs_;
  uint32_t lastAttempt_=0;
  bool attempted_=false,pendingExists_=false;
  char lastObserved_[48]={0},pending_[48]={0};
};
}
