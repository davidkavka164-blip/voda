#pragma once
#include <stdint.h>
// All alarm causes are observable simultaneously; the first set bit is the
// same priority-based headline as REV21. Pure C++11, no Arduino dependencies.
namespace hcc22 {
enum : unsigned { ALARM_COUNT=14 };
struct Inputs {
  bool kerblFault,doorDeadline,waterLow,waterNotReady,waterTempSensor,waterFreeze,
       wifiLost,watchdog,clockOrDoor,settings,batteryInvalid,batteryLow,
       heater,commandInhibit;
};
struct Report {
  uint16_t mask;
  bool has(unsigned index) const {return index<ALARM_COUNT && ((mask>>index)&1u)!=0;}
  unsigned count() const {unsigned count=0;for(unsigned i=0;i<ALARM_COUNT;++i)count+=has(i);return count;}
};
inline Report evaluate(const Inputs& in){
  const bool flags[ALARM_COUNT]={
    in.kerblFault,in.doorDeadline,in.waterLow,in.waterNotReady,
    in.waterTempSensor,in.waterFreeze,in.wifiLost,in.watchdog,
    in.clockOrDoor,in.settings,in.batteryInvalid,in.batteryLow,
    in.heater,in.commandInhibit
  };
  uint16_t mask=0;
  for(unsigned i=0;i<ALARM_COUNT;++i)if(flags[i])mask|=static_cast<uint16_t>(1u<<i);
  return {mask};
}
inline const char* name(unsigned index){
  static const char* const names[ALARM_COUNT]={
    "KERBL_POSITION_FAULT","DOOR_DEADLINE","WATER_LOW_OR_WIRE_OPEN",
    "WATER_CONTACT_NOT_READY","WATER_TEMP_SENSOR_FAIL","WATER_FREEZE_RISK",
    "WIFI_DISCONNECTED","WATCHDOG_NOT_READY","CLOCK_OR_DOOR_UNKNOWN",
    "NVS_STORAGE_FAIL","BATTERY_INVALID","BATTERY_LOW",
    "EGG_HEATER_SENSOR_OR_THERMAL","ESP_COMMAND_INHIBIT_OPEN"
  };
  return index<ALARM_COUNT ? names[index] : "INVALID";
}
inline const char* primary(const Report& report){
  for(unsigned i=0;i<ALARM_COUNT;++i)if(report.has(i))return name(i);
  return "NONE";
}
}
