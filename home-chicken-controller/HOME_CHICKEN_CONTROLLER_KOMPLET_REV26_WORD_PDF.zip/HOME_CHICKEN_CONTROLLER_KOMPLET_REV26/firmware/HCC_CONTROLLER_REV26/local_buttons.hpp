#pragma once
#include "kerbl_interface.hpp"
// Debounced local button gestures; host-testable C++11, no Arduino dependencies.
namespace hcc11 {
// Local button gestures; no special commissioning gesture required.
struct ButtonGesture {
  hcckerbl::Request single;
  bool bothHeld;
};

class LocalButtons {
public:
  void requireRelease(){
    ready_=false;
    chord_=false;
    single_=hcckerbl::Request::NONE;
  }
  ButtonGesture tick(bool rawOpen, bool rawClose, uint32_t now) {
    using hcckerbl::Request;
    const ButtonGesture idle={Request::NONE,false};
    open_.update(rawOpen,now);
    close_.update(rawClose,now);
    if(!open_.ready() || !close_.ready())return idle;
    const bool released=!rawOpen&&!rawClose&&!open_.value()&&!close_.value();
    if(!ready_){
      ready_=released; // Buttons held at boot cannot arm or request motion.
      return idle;
    }
    if((rawOpen&&rawClose) || (single_==Request::OPEN&&rawClose) ||
       (single_==Request::CLOSE&&rawOpen)){
      chord_=true;
      single_=Request::NONE;
    }
    if(chord_){
      if(released)chord_=false;
      return {Request::NONE,rawOpen&&rawClose&&open_.value()&&close_.value()};
    }
    if(single_==Request::NONE){
      if(rawOpen&&open_.value())single_=Request::OPEN;
      if(rawClose&&close_.value())single_=Request::CLOSE;
      if(single_!=Request::NONE)pressedAt_=now;
      return idle;
    }
    if(!released)return idle;
    const Request completed=single_;
    single_=Request::NONE;
    return {static_cast<uint32_t>(now-pressedAt_)<=2000u?completed:Request::NONE,false};
  }
private:
  hcckerbl::Debounce open_{60},close_{60};
  hcckerbl::Request single_=hcckerbl::Request::NONE;
  uint32_t pressedAt_=0;
  bool ready_=false,chord_=false;
};
}
