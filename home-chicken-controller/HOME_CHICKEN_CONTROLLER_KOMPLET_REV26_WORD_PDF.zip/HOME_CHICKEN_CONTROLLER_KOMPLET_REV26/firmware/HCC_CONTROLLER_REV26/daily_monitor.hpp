#pragma once
#include "kerbl_interface.hpp"
#include "policy.hpp"

namespace hcc17 {
struct MonitoringSchedule {
  uint16_t deadlineEnabled;
  uint16_t morningStart, openBy, eveningStart, closedBy;
  uint16_t cameraStart, cameraEnd;
};

inline bool validSchedule(const MonitoringSchedule& s) {
  return s.deadlineEnabled<=1 && s.morningStart<s.openBy && s.openBy<s.eveningStart &&
         s.eveningStart<s.closedBy && s.closedBy<1440 &&
         s.cameraStart<1440 && s.cameraEnd<1440 && s.cameraStart!=s.cameraEnd;
}

enum class ExpectedDoor { MONITOR_OFF, CLOCK_INVALID, TRANSITION, OPEN, CLOSED };
enum class DoorDeadlineAlarm { NONE, OPEN_DEADLINE_MISSED, CLOSE_DEADLINE_MISSED };

struct DoorMonitor {
  ExpectedDoor expected;
  DoorDeadlineAlarm alarm;
};

inline DoorMonitor monitorDoor(const MonitoringSchedule& s, bool clockOk, uint16_t minute,
                               const hcckerbl::Output& door) {
  if (!s.deadlineEnabled || !validSchedule(s)) {
    return {ExpectedDoor::MONITOR_OFF, DoorDeadlineAlarm::NONE};
  }
  if (!clockOk || minute>=1440) {
    return {ExpectedDoor::CLOCK_INVALID, DoorDeadlineAlarm::NONE};
  }
  if (minute<s.morningStart || minute>=s.closedBy) {
    const bool closed=door.verified && door.position==hcckerbl::Position::CLOSED;
    return {ExpectedDoor::CLOSED, closed?DoorDeadlineAlarm::NONE:
                                         DoorDeadlineAlarm::CLOSE_DEADLINE_MISSED};
  }
  if (minute>=s.openBy && minute<s.eveningStart) {
    const bool open=door.verified && door.position==hcckerbl::Position::OPEN;
    return {ExpectedDoor::OPEN, open?DoorDeadlineAlarm::NONE:
                                     DoorDeadlineAlarm::OPEN_DEADLINE_MISSED};
  }
  return {ExpectedDoor::TRANSITION, DoorDeadlineAlarm::NONE};
}

inline bool cameraPowerOn(bool enabled, bool clockOk, uint16_t minute,
                          const MonitoringSchedule& s) {
  return enabled && clockOk && hcc7::within(minute,s.cameraStart,s.cameraEnd);
}

inline const char* expectedDoorName(ExpectedDoor expected) {
  switch (expected) {
    case ExpectedDoor::MONITOR_OFF: return "DISABLED";
    case ExpectedDoor::CLOCK_INVALID: return "CLOCK_INVALID";
    case ExpectedDoor::TRANSITION: return "TRANSITION";
    case ExpectedDoor::OPEN: return "OPEN";
    case ExpectedDoor::CLOSED: return "CLOSED";
  }
  return "UNKNOWN";
}

inline const char* deadlineAlarmName(DoorDeadlineAlarm alarm) {
  switch (alarm) {
    case DoorDeadlineAlarm::NONE: return "NONE";
    case DoorDeadlineAlarm::OPEN_DEADLINE_MISSED: return "OPEN_DEADLINE_MISSED";
    case DoorDeadlineAlarm::CLOSE_DEADLINE_MISSED: return "CLOSE_DEADLINE_MISSED";
  }
  return "UNKNOWN";
}
}
