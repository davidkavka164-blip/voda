#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
build_dir=$(mktemp -d)
trap 'rm -rf "$build_dir"' EXIT
flags=(-std=c++11 -O2 -Wall -Wextra -Werror -pedantic)
for suite in rtc daily; do
  "${CXX:-g++}" "${flags[@]}" -Irtc_stubs -I../HCC_CONTROLLER_REV26 "test_${suite}_rev17.cpp" -o "$build_dir/$suite"
  "$build_dir/$suite"
done
"${CXX:-g++}" "${flags[@]}" -I../HCC_CONTROLLER_REV26 test_kerbl_rev20.cpp -o "$build_dir/kerbl"
"$build_dir/kerbl"
"${CXX:-g++}" "${flags[@]}" -I../HCC_CONTROLLER_REV26 test_aux_rev20.cpp -o "$build_dir/aux"
"$build_dir/aux"
"${CXX:-g++}" "${flags[@]}" -I../HCC_CONTROLLER_REV26 test_health_rev18.cpp -o "$build_dir/health"
"$build_dir/health"

"${CXX:-g++}" "${flags[@]}" -I../HCC_CONTROLLER_REV26 test_alarm_rev22.cpp -o "$build_dir/alarms"
"$build_dir/alarms"

python3 test_rev26_source_contract.py

"${CXX:-g++}" "${flags[@]}" -I../HCC_CONTROLLER_REV26 test_heat_priority_rev26.cpp -o "$build_dir/heat"
"$build_dir/heat"
python3 test_rev26_priority_source.py
