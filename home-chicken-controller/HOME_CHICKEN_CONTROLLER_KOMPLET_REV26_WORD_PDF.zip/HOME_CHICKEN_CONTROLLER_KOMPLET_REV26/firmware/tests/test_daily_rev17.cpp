#include <cassert>
#include <iostream>
#include "daily_monitor.hpp"

using hcc17::DoorDeadlineAlarm;
using hcc17::ExpectedDoor;
using hcckerbl::Position;

static hcckerbl::Output doorAt(Position position, bool verified=true) {
  return {position,hcckerbl::Fault::NONE,false,false,verified,false,false,false};
}

int main() {
  hcc17::MonitoringSchedule s={0,360,570,1020,1350,420,960};
  assert(hcc17::validSchedule(s));
  const auto open=doorAt(Position::OPEN);
  const auto closed=doorAt(Position::CLOSED);
  const auto moving=doorAt(Position::MOVING,false);
  const auto unverified=doorAt(Position::CLOSED,false);
  const auto unknown=doorAt(Position::UNKNOWN,false);

  auto result=hcc17::monitorDoor(s,true,0,open);
  assert(result.expected==ExpectedDoor::MONITOR_OFF && result.alarm==DoorDeadlineAlarm::NONE);
  s.deadlineEnabled=1;
  result=hcc17::monitorDoor(s,false,570,closed);
  assert(result.expected==ExpectedDoor::CLOCK_INVALID && result.alarm==DoorDeadlineAlarm::NONE);
  assert(hcc17::monitorDoor(s,true,1440,open).expected==ExpectedDoor::CLOCK_INVALID);

  for (uint16_t minute=0; minute<1440; ++minute) {
    auto expected=ExpectedDoor::TRANSITION;
    if (minute<360 || minute>=1350) expected=ExpectedDoor::CLOSED;
    if (minute>=570 && minute<1020) expected=ExpectedDoor::OPEN;

    auto opened=hcc17::monitorDoor(s,true,minute,open);
    auto closedResult=hcc17::monitorDoor(s,true,minute,closed);
    assert(opened.expected==expected && closedResult.expected==expected);
    assert(opened.alarm==(expected==ExpectedDoor::CLOSED
                         ? DoorDeadlineAlarm::CLOSE_DEADLINE_MISSED : DoorDeadlineAlarm::NONE));
    assert(closedResult.alarm==(expected==ExpectedDoor::OPEN
                               ? DoorDeadlineAlarm::OPEN_DEADLINE_MISSED : DoorDeadlineAlarm::NONE));
    assert(hcc17::monitorDoor(s,true,minute,moving).alarm==
           (expected==ExpectedDoor::OPEN ? DoorDeadlineAlarm::OPEN_DEADLINE_MISSED :
            expected==ExpectedDoor::CLOSED ? DoorDeadlineAlarm::CLOSE_DEADLINE_MISSED :
            DoorDeadlineAlarm::NONE));
    assert(hcc17::monitorDoor(s,true,minute,unverified).alarm==
           (expected==ExpectedDoor::OPEN ? DoorDeadlineAlarm::OPEN_DEADLINE_MISSED :
            expected==ExpectedDoor::CLOSED ? DoorDeadlineAlarm::CLOSE_DEADLINE_MISSED :
            DoorDeadlineAlarm::NONE));
    assert(hcc17::monitorDoor(s,true,minute,unknown).alarm==
           (expected==ExpectedDoor::OPEN ? DoorDeadlineAlarm::OPEN_DEADLINE_MISSED :
            expected==ExpectedDoor::CLOSED ? DoorDeadlineAlarm::CLOSE_DEADLINE_MISSED :
            DoorDeadlineAlarm::NONE));
    assert(hcc17::cameraPowerOn(true,true,minute,s)==(minute>=420 && minute<960));
  }

  assert(!hcc17::cameraPowerOn(true,false,420,s));
  assert(!hcc17::cameraPowerOn(false,true,420,s));
  assert(!hcc17::cameraPowerOn(true,true,1440,s));
  assert(!hcc17::cameraPowerOn(true,true,0,s));

  auto overnight=s;
  overnight.cameraStart=22*60;
  overnight.cameraEnd=6*60;
  assert(hcc17::validSchedule(overnight));
  assert(!hcc17::cameraPowerOn(true,true,overnight.cameraStart-1,overnight));
  assert(hcc17::cameraPowerOn(true,true,overnight.cameraStart,overnight));
  assert(hcc17::cameraPowerOn(true,true,1439,overnight));
  assert(hcc17::cameraPowerOn(true,true,0,overnight));
  assert(hcc17::cameraPowerOn(true,true,overnight.cameraEnd-1,overnight));
  assert(!hcc17::cameraPowerOn(true,true,overnight.cameraEnd,overnight));

  auto invalid=s;
  invalid.openBy=invalid.morningStart;
  assert(!hcc17::validSchedule(invalid));
  assert(hcc17::monitorDoor(invalid,true,570,closed).alarm==DoorDeadlineAlarm::NONE);
  invalid=s;
  invalid.closedBy=1440;
  assert(!hcc17::validSchedule(invalid));
  invalid=s;
  invalid.deadlineEnabled=2;
  assert(!hcc17::validSchedule(invalid));
  invalid=s;
  invalid.cameraEnd=invalid.cameraStart;
  assert(!hcc17::validSchedule(invalid));
  assert(!hcc17::cameraPowerOn(true,true,420,invalid));

  std::cout<<"REV21 deadline and camera policies OK across all 1440 minutes\n";
}
