#include <cassert>
#include <cstdint>
#include <iostream>
#include "../HCC_CONTROLLER_REV26/health_monitor.hpp"
using namespace hcc18;
int main(){
  WaterContact water(2000);
  assert(water.tick(false,false,0)==WaterState::NOT_INSTALLED);
  assert(water.tick(true,false,100)==WaterState::SETTLING);
  assert(water.tick(true,false,2099)==WaterState::SETTLING);
  assert(water.tick(true,false,2100)==WaterState::OK);
  assert(water.tick(true,true,2125)==WaterState::OK);
  assert(water.tick(true,false,2150)==WaterState::OK); // short bounce must not signal a fault
  assert(water.tick(true,true,2200)==WaterState::OK);
  assert(water.tick(true,true,4199)==WaterState::OK);
  assert(water.tick(true,true,4200)==WaterState::LOW_OR_WIRE_OPEN);
  assert(water.tick(true,false,4250)==WaterState::LOW_OR_WIRE_OPEN);
  assert(water.tick(true,false,6250)==WaterState::OK);
  assert(water.tick(false,false,6500)==WaterState::NOT_INSTALLED);
  FreezeWarning frost;
  assert(!frost.tick(true,7,3,5));
  assert(frost.tick(true,2.5f,3,5));
  assert(frost.tick(true,4.5f,3,5));
  assert(frost.tick(false,20,3,5));
  assert(!frost.tick(true,5.2f,3,5));
  RtcBackupGuard rtc;
  assert(rtc.due(true,500));
  rtc.attempted(500,true);
  assert(!rtc.due(true,1000)); // stuck SNTP_COMPLETED must NOT trigger writes
  assert(!rtc.due(true,43200500u));
  assert(!rtc.due(false,43200600u));
  assert(rtc.due(true,43200700u)); // genuine new sync, 12h later
  rtc.attempted(43200700u,false);
  assert(!rtc.due(true,43210700u));
  assert(rtc.due(true,43230700u));
  rtc.attempted(43230700u,true);
  assert(!rtc.due(true,50000000u));
  CriticalWriteGate log(60000);
  log.observe("NONE");assert(!log.due(0));
  log.observe("WATER_LOW_OR_WIRE_OPEN");assert(log.due(500));
  log.attempted(500,true);assert(!log.due(1000));
  log.observe("NONE");assert(!log.due(1100));
  log.observe("WATER_LOW_OR_WIRE_OPEN");assert(!log.due(1250));
  assert(log.due(60500));
  log.attempted(60500,true);assert(!log.due(60600));
  log.observe("WIFI_DISCONNECTED");assert(!log.due(60700));
  assert(log.due(120500));
  std::cout<<"REV18 water, freeze, RTC rate-limit and persistent alarm gate OK\n";
}
