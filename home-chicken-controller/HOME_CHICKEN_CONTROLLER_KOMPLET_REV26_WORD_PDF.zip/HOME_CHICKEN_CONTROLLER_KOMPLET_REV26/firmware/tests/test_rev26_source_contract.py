#!/usr/bin/env python3
"""Verify first-flash configuration and integration paths."""
from pathlib import Path

base = Path(__file__).resolve().parents[1] / "HCC_CONTROLLER_REV26"
source = (base / "HCC_CONTROLLER_REV26.ino").read_text(encoding="utf-8")
config = (base / "config.h").read_text(encoding="utf-8")

assert "#define HCC_FIRMWARE_REV 26" in config
assert "s+=String(HCC_FIRMWARE_REV);" in source
assert "REV26 – KERBL" in source
for name in (
    "HCC_KERBL_OUTPUTS_ENABLED",
    "HCC_ALLOW_WEB_KERBL_COMMANDS",
    "HCC_EGG_HEATER_OUTPUTS_ENABLED",
    "HCC_BATTERY_ADC_CALIBRATED",
):
    assert "#define " + name + " 0" in config
assert "#define HCC_CAMERA_POWER_ENABLED 1" in config
assert "digitalWrite(PIN_KERBL_OPEN,HCC_KERBL_RELAY_OFF);" in source
assert "digitalWrite(PIN_KERBL_CLOSE,HCC_KERBL_RELAY_OFF);" in source
assert "lastDoor=kerbl.tick(" in source
assert 'prefs.begin("hcc7",false)' in source
assert '"monitorV17"' in source
assert 'prefs.getBytes("schedule",' in source
assert "const bool hasWifiCredentials=strlen(HCC_WIFI_SSID)>0;" in source

clock_handler = source.split("static void onClock(){", 1)[1].split("static void onAction(){", 1)[0]
assert "Nastavit hodiny podle telefonu" in source
assert "Clock already set" not in clock_handler
assert "if(!authenticated())return;" in clock_handler
assert "if(!formAuthorized())" in clock_handler
assert "hcc7::writeVerifiedDS3231Utc" in clock_handler
assert "if(settimeofday(&corrected,nullptr)!=0)" in clock_handler

loop = source.split("void loop(){", 1)[1]
assert loop.index("if(lastDoor.pulse){delay(1);return;}") < loop.index("updateCriticalHistory(now);")
assert loop.index("if(lastDoor.pulse){delay(1);return;}") < loop.index("web.handleClient();")
print("REV26 source contracts OK")
