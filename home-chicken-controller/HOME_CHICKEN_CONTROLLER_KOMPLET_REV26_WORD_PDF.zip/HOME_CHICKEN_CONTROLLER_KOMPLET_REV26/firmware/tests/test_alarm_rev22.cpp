#include <cassert>
#include <cstring>
#include <iostream>
#include "../HCC_CONTROLLER_REV26/alarm_report.hpp"
using namespace hcc22;
int main(){
  Inputs in={};
  Report r=evaluate(in);
  assert(r.count()==0 && std::strcmp(primary(r),"NONE")==0);
  in.batteryLow=true;in.waterLow=true;in.doorDeadline=true;
  r=evaluate(in);
  assert(r.count()==3 && r.has(1) && r.has(2) && r.has(11));
  assert(std::strcmp(primary(r),"DOOR_DEADLINE")==0);
  in.kerblFault=true;r=evaluate(in);
  assert(r.count()==4 && std::strcmp(primary(r),"KERBL_POSITION_FAULT")==0);
  in.kerblFault=false;in.doorDeadline=false;in.waterLow=false;
  in.batteryLow=false;in.waterNotReady=true;
  r=evaluate(in);
  assert(r.count()==1 && std::strcmp(primary(r),"WATER_CONTACT_NOT_READY")==0);
  in.waterNotReady=false;in.commandInhibit=true;in.heater=true;
  r=evaluate(in);
  assert(r.count()==2 && std::strcmp(primary(r),"EGG_HEATER_SENSOR_OR_THERMAL")==0);
  assert(!r.has(14) && !r.has(999));
  std::cout<<"REV22 concurrent alarm report OK\n";
}
