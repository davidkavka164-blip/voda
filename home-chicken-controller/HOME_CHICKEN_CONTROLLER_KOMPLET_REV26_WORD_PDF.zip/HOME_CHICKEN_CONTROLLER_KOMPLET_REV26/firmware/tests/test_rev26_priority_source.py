#!/usr/bin/env python3
"""Verify that battery policy affects the heater rather than the Kerbl command path."""
from pathlib import Path

root = Path(__file__).parent.parent / "HCC_CONTROLLER_REV26"
source = (root / "HCC_CONTROLLER_REV26.ino").read_text(encoding="utf-8")
config = (root / "config.h").read_text(encoding="utf-8")

assert "i.battery_ok=heatBatteryReserve.tick(batteryCalibrated,batteryOk,batteryV);" in source
assert "digitalWrite(PIN_EGG_HEATER,heaterOutput?HIGH:LOW)" in source
assert "HCC_HEAT_CUTOFF_V 25.0f" in config
assert "HCC_HEAT_RESTORE_V 26.0f" in config
assert "HARDWIRED_12V_FROM_MAIN_BATTERY" in source
assert r'\"kerbl_12v_measured\":false' in source

for name, next_name in [
    ("moveOutputs", "configuredRom"),
    ("onAction", "readLocalButtons"),
    ("readLocalButtons", "tickDoor"),
    ("tickDoor", "setup"),
]:
    section = source.split(f"void {name}(", 1)[1].split(f"{next_name}(", 1)[0]
    assert "battery" not in section.lower(), f"{name} must stay independent of ADC policy"
print("PASS REV26 source priority contract")
