#include <cassert>
#include <iostream>
#include "policy.hpp"

int main() {
  hcc7::HeatBatteryReserve reserve;
  assert(!reserve.tick(false, true, 28.0f)); // plausible but uncalibrated
  assert(!reserve.tick(true, true, 25.5f));  // cold boot cannot bypass restore
  assert(!reserve.tick(true, true, 25.99f));
  assert(reserve.tick(true, true, 26.0f));
  assert(reserve.tick(true, true, 25.0f));
  assert(!reserve.tick(true, true, 24.99f));
  assert(!reserve.tick(true, true, 25.5f));
  assert(reserve.tick(true, true, 26.1f));
  assert(!reserve.tick(true, false, 26.8f)); // invalid ADC sheds
  assert(!reserve.tick(true, true, 25.5f));
  assert(reserve.tick(true, true, 26.0f));
  assert(!reserve.tick(true, true, 30.1f));  // out-of-range volts shed

  hcc7::HeatBatteryReserve reboot;
  assert(!reboot.tick(true, true, 25.5f));
  assert(reboot.tick(true, true, 26.0f));
  assert(!reboot.tick(false, true, 28.0f));

  hcc7::EggHeaterPolicy heat;
  hcc7::HeatInputs inputs={true,true,true,true,false,true,600,420,960,1.0f};
  inputs.battery_ok=reboot.tick(false,true,28.0f);
  assert(!heat.tick(inputs));
  inputs.battery_ok=reboot.tick(true,true,26.0f);
  assert(heat.tick(inputs));
  inputs.battery_ok=reboot.tick(true,true,24.9f);
  assert(!heat.tick(inputs));
  std::cout << "PASS REV26 heater reserve, calibration and output policy\n";
}
