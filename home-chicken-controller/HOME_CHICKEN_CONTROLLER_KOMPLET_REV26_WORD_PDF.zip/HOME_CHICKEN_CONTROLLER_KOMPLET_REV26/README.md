# HOME CHICKEN CONTROLLER · REV26

Montážní sada pro ostrovní kurník pro deset slepic. Kerbl 70546 řídí dvířka vlastní automatikou a bere energii z hlavní 24V baterie přes samostatný měnič. ESP32 sleduje polohu, hladinu a teplotu vody, ovládá ohřev vajec a časované napájení kamery. RUT241 zajišťuje vzdálený dohled.

## Pořadí instalace

1. Projdi [stavbu a montáž](construction/REV26_STAVBA_A_MONTAZ.md) a [pracovní půdorys](drawings/HCC_PUDORYS_ROVINA_REV26.png). Rozměry otvoru, vedení a kotvení ověř podle skutečných dílů a místa.
2. Použij [elektrické zapojení](docs/REV26_ZAPOJENI_A_BEZPECNOST.md), [nové schéma napájení](drawings/HCC_REV26_NAPAJENI.png) a [nákupní seznam](components/HCC_NAKUP_REV26_KERBL.xlsx). Řízení baterie, nabíjení a funkci priority popisuje [návod napájení](docs/REV26_NAPAJENI_A_FVE.md).
3. Přelož a nahraj zdroje podle [instalačního postupu](docs/REV26_NAVOD_INSTALACE_A_TESTY.md). Při prvním zapnutí jsou povelová relé, ohřev a vzdálené povely ve výchozím programu zakázané. Kerbl může po připojení vlastního napájecího kabelu pracovat nezávisle.
4. Nastav [dvířka a časový dohled](docs/REV26_KERBL_OVLADANI.md) a [LTE, VPN, kameru a SMS](docs/REV26_LTE_WIREGUARD_KAMERA.md).
5. Projdi [přejímací protokol](docs/REV26_ZKUSEBNI_PROTOKOL.csv) a [výsledky softwarového ověření](docs/REV26_OVERENI.md). Pro tisk a editaci slouží `DOKUMENTACE_REV26.pdf` a `DOKUMENTACE_REV26.docx`.

U dvířek jde o **samostatnou napájecí větev ze stejné baterie**. Vlastní měnič odděluje jejich 12V rozvod od ohřevu a routeru. Výpadek hlavní baterie, hlavního jištění nebo zásah BMS zasáhne i dvířka. Před montáží potvrď u Kerbl použití originálního kabelu 70557 s vybraným regulovaným zdrojem, protože návod 70557 popisuje vnější baterii.
