# REV26 – napájení Kerbl a priorita ohřevu

## Platné zapojení

Hlavní baterie je **LiFePO₄ 25,6 V / 100 Ah** s BMS a FVE. Pro 12V obvody jsou dva samostatné **Mean Well DDR‑60G‑12**. Výstupy se nespojují paralelně.

| Větev | Cesta | Působení ESP32 |
| --- | --- | --- |
| Dvířka Kerbl 70550 | Hlavní 24V sběrnice → F10 5 A → vyhrazený DDR‑60G‑12 → originální Kerbl 70557 s F9 2 A → Kerbl | Napájení zůstává zapojené a ESP32 je neodpojuje. ESP32 poskytuje jen dva bezpotenciálové impulzy. V této konfiguraci se AA nepoužívají. |
| RUT241 | Hlavní 24V sběrnice → F2 5 A → druhý DDR‑60G‑12 → F5 1 A → RUT241 | Při běžném vypnutí ohřevu je router dál napájený. |
| Ohřev vajec | 12 V z větve F2 → F4 3 A → MOSFET řízený GPIO16, samostatný výkonový termostat a tepelná pojistka → fólie 20 W | Při nízkém napětí baterie ESP32 vypíná MOSFET ohřevu. F4 zůstává pojistkou kabelové větve. |
| Řídicí elektronika a kamera | Hlavní 24V sběrnice → F3 → DDR‑30G‑5 → F6–F8 | Kamera přes GPIO23 jen ve zvoleném časovém okně. Řídicí elektronika napájená i při vypnuté kameře. |

Kerbl a ohřev mají oddělené DC/DC měniče. Jestliže ochrana BMS odpojí hlavní baterii nebo selže společný 24V rozvod, ztratí energii také Kerbl. Vyhrazený F10/F9 zmenšuje vliv poruch 12V větve ohřevu, selektivitu jištění musí potvrdit kontrola návrhu a provozní měření. Samostatná záložní baterie se v tomto zapojení nepoužívá.

Výrobce originálního kabelu 70557 dokumentuje napájení 70550 ze samostatné nominálně 12V automobilové/ohradníkové baterie. Zvolený stabilizovaný zdroj je projektová volba. Potvrď kompatibilitu konkrétního Kerbl s výrobcem, změř polaritu a výstup před připojením. Do napájecí zdířky Kerbl nesmí přijít 24 V a do kontaktů OPEN–V–CLOSE žádné externí napájení. Originální 2A pojistka slouží k jištění, neudává rozběhový odběr a není omezovačem proudu. Při servisu mechanicky zajisti šoupátko a odpoj napájení Kerbl fyzicky.

## Pracovní prahy a výpočet

- Firmware vypíná ohřev vajec při odhadu hlavního napětí pod **25,0 V**. Po zotavení na nejméně **26,0 V** ohřev opět připadá v úvahu při platném čidle, čase a zdravé tepelné smyčce. Prahy vycházejí z odhadu napětí, **nejsou údajem o procentu nabití**. Po montáži ověř napětí multimetrem a reakce při zatížení.
- První DDR‑60G‑12 napájí fólii 20 W / 1,67 A a RUT241 s pracovním odhadem 0,60 A. To je přibližně 2,27 A před ověřením špiček a teploty. Lze osadit další větev pouze po novém dimenzování rozvodu. Přídavná topná fólie bateriového prostoru a automatický ohřev vody jsou mimo základ.
- Samostatný DDR‑60G‑12 poskytuje Kerblu jmenovitě 12 V / 5 A. Výrobce měniče uvádí typický náběhový proud na **24V vstupu 20 A**. Ověř, že skutečný souběžný start obou měničů nevyvolá pokles, vypnutí BMS ani vybavení F2/F10. Špička na vstupu měniče nepatří do 12V modelu spotřeby Kerbl. Ověř také napětí na zátěži při rozběhu dvířek, nikoli pouze napětí naprázdno.
- Denní energetický sešit odděluje vlastní odběr Kerbl na 12V větvi od klidového příkonu jeho nového měniče na 24V straně. Obě hodnoty jsou plánovací do prvního měření. Změř Wh při čekání i několika cyklech Kerbl bez zvířat a v reálné teplotě. V sešitu je zvlášť běžný den a celý 9h běh fólie za chladu.

## Fotovoltaika a mráz

Pro dva potvrzené shodné panely v sérii počítej **Voc_zima = 2 × Voc_STC × (1 + |βVoc| × (25 − Tmin))**, když je koeficient v desetinném vyjádření na °C. Údaj v %/°C nejdřív vyděl 100. Potvrď hodnoty skutečných štítků, teplotu a návrhovou rezervu. Mez regulátoru Victron SmartSolar 150/35 je 150 V na PV vstupu. Pojistky, odpojovače a vodiče nevybírej jen podle jmenovitého výkonu panelů.

U LiThink 24 V / 100 Ah Bluetooth uvádí produktová stránka 8 A pro samoohřev a technický list výrobce minimum 10 A, navzdory tomu, že uvádí časy ohřevu při 8 A. Do potvrzení dodané revize je pracovní návrh **10 A ≈ 256 W při 25,6 V** na straně baterie. V reálném napětí mohou být nároky vyšší a přičítá se současná spotřeba. Pokud MPPT nepustí proud kvůli teplotě, samoohřev z nabíječky se nemusí spustit. Zachovej ochranu článků proti nabíjení v mrazu a kombinaci BMS/MPPT potvrď podle doloženého postupu výrobce. Jmenovitých 840 Wp panelů samo nezaručuje zimní výrobu a 2 560 Wh jmenovité kapacity neudává skutečné odběrné okno.

## Ověření po montáži

Zkontroluj napájení a polaritu při každém zapnutí části soustavy. Bez zvířat změř úrovně 24 V a obou 12V větví při souběhu startů, zapnutí fólie a jízdě Kerbl. Při zkoušce běžného vypnutí ohřevu potvrď, že F9 zůstane napájený. Prověř fyzické odpojení zdroje Kerbl, servisní zajištění, vlastní automatiku a návrat do AUTO s AC ON. Pojistku z držáku vyjmi po odpojení napětí, pokud držák není výslovně určen k odpojování pod zátěží. Teprve ze změřených Wh/den a skutečné zimní výroby vyhodnoť potřebnou rezervu.

- [Kerbl 70557, návod výrobce](https://www.kerbl.co.uk/ftp/product-doc/176617.pdf)
- [Mean Well DDR‑60, výkony a omezení](https://www.meanwell.com/Upload/PDF/DDR-60/DDR-60-SPEC.PDF)
- [Victron 150/35, technické parametry](https://www.victronenergy.com/media/pg/Manual_SmartSolar_MPPT_150-35__150-45/en/technical-specifications.html)
- [LiThink, údaje produktu](https://lithink.de/en/products/24v-100ah-lifepo4-battery-bluetooth-heating-trolling-motorhome-solar) · [Návod 24 V / 100 Ah Bluetooth, s. 5–6](https://cdn.shopify.com/s/files/1/0759/1844/2717/files/24V_100Ah_Bluetooth_Product_Manual_EN.pdf.pdf?v=1761285720)
