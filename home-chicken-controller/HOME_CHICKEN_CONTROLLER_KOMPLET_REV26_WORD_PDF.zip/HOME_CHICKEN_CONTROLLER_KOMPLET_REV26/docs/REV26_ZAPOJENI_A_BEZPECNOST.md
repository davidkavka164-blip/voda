# REV26 – aktuální zapojení a ochrany

Řídicí program je HCC_CONTROLLER_REV26 pro ESP32 Dev Module. Čísla u ESP32 jsou GPIO, nikoli pořadí pinů konektoru. Aktivní rozpis je v sešitu **HCC_NAKUP_REV26_KERBL.xlsx**. Údaje REV17–25 slouží v archivu k dohledání změn.

## Výkonový rozvod

| Označení | Propojení | Jištění a návrhová trasa |
| --- | --- | --- |
| PV-SW | Dva shodné SOLARFAM SZ-420-60M v sérii → dvoupólový FV DC odpojovač → PV+ a PV− regulátoru Victron SmartSolar 150/35 | Odpojovač alespoň 250 V DC / 20 A v použitém zapojení pólů. H1Z2Z2-K 4 mm², nejvýše 20 m jedním směrem. Potvrdit skutečné štítky, Voc za mrazu, Isc, kompatibilitu konektorů a případnou ochranu proti přepětí. |
| F0 / S0 | Baterie + → F0 → S0 → krytá +24V sběrnice. Baterie − → záporná sběrnice | Eaton Bussmann JJN‑60, 60 A Class T s kompatibilním krytým DC držákem u kladného pólu. S0 alespoň 60 V DC / 100 A s odpovídající DC vypínací schopností. Cu 16 mm², nejvýše 1 m jedním směrem. |
| F1 | +24V sběrnice → F1 → BAT+ Victron 150/35. BAT− na zápornou sběrnici | JJN‑40, 40 A Class T s kompatibilním krytým DC držákem u sběrnice. Cu 16 mm², do 3 m jedním směrem. |
| F2 | +24V sběrnice → F2 → IN+ prvního DDR‑60G‑12. IN− na zápornou sběrnici. Jeho 12 V výstup napájí jen F4 a F5 | Mersen ATDR5, 5 A Class CC se zpožděním, DC držák u sběrnice. Cu 2× 2,5 mm² do 3 m. |
| F3 | +24V sběrnice → F3 → IN+ DDR‑30G‑5. IN− na zápornou sběrnici. Jeho 5 V výstup napájí F6–F8 | Mersen ATDR3, 3 A Class CC se zpožděním, DC držák u sběrnice. Cu 2× 1,5 mm² do 3 m. |
| F10 | +24V sběrnice → F10 → IN+ druhého DDR‑60G‑12. IN− na zápornou sběrnici. Jeho 12 V výstup patří pouze Kerblu přes F9 | **Mersen ATDR5, 5 A Class CC se zpožděním** s DC držákem u sběrnice. Dva vodiče Cu 2,5 mm² do 3 m. |
| F4 | První DDR‑60G‑12 OUT+ → F4 → VIN DFR0457. VOUT DFR0457 → výkonový NC termostat → jednorázová tepelná pojistka → kladný vodič fólie. Záporný vodič fólie na OUT− tohoto měniče | DC 3 A u zdroje pro větev fólie, Cu 2× 1,5 mm² do 5 m. Oba výkonové tepelné prvky zůstávají v sérii. |
| F5 | První DDR‑60G‑12 → F5 → RUT241 přes správný napájecí konektor 4pin | DC 1 A u zdroje, Cu 2× 0,75 mm² do 5 m. |
| F6 | DDR‑30G‑5 → F6 → 5V vstup ESP32 Dev Module. RTC a sondy berou 3,3 V z řídicí větve | DC 2 A u zdroje, Cu 2× 1 mm² do 1 m. Připojení 5V pinu potvrdit podle modelu DevKitu. |
| F7 | DDR‑30G‑5 → F7 → VIN Pololu #2810 → VOUT → 5V vstup kamery | DC 2 A u zdroje, Cu 2× 1,5 mm² do 2 m. GPIO23 spíná vysokou stranu. |
| F8 | DDR‑30G‑5 → F8 → napájení dvou 5V relé a jejich budičů | DC 1 A u zdroje, Cu 2× 0,75 mm² do 2 m. |
| F9 | Druhý DDR‑60G‑12 OUT+/OUT− → originální kabel Kerbl 70557 → napájecí konektor 70550 | Integrovaná originální 2A pojistka v kabelu 70557 u zdrojové strany, originální délka 3 m, bez prodloužení v základu. Připojit přes vhodné izolované svorky bez obcházení originální pojistky. |

Každou větev označ na obou koncích. Dva výstupy 12V měničů se vedou odděleně a nespojují do paralelního zdroje. Svorku V externího tlačítka Kerbl veď pouze na suché kontakty relé. Do svorkovnice OPEN–V–CLOSE nepřiváděj 5, 12 ani 24 V a nepřipojuj zem ESP32. Způsob uzemnění a pospojování rozváděče/rámů, vypínací schopnost jištění, skutečný průřez a vhodný držák potvrď podle reálné trasy, konkrétních přístrojů a umístění. Prověř také odvětrání rozváděče a montážní mezery obou 12V měničů podle datového listu. Regulátor připojuj a odpojuj ve správném pořadí podle návodu Victron. Před zapnutím potvrď polaritu každé dokončené větve.

Jmenovitá pojistka vyjadřuje ochranný prvek větve. Určení skutečného zkratového proudu a vypínací selektivity zůstává součástí kontroly návrhu DC rozvodu. Po montáži se ověří náběh měničů, pokles 24 V, skutečný proud a stálost obou 12V výstupů. Zkrat výstupu provozované sestavy nevyvolávej. Pro ověření souběhu využij bezpečné měření běžné zátěže a zkoušku odpojení samostatné větve.

## Kerbl 70546/70550

Kerbl má vlastní 12V měnič z hlavní 24V LiFePO₄. ESP32 spíná jen krátké povely. BMS nebo společný 24V rozvod mohou při výpadku odebrat energii i Kerblu. Vyhrazený měnič odděluje výkonovou větev dvířek od F4/F5 a omezuje přímý dopad závady na sousedním 12V výstupu. Společný 24V rozvod, hlavní pojistka a BMS zůstávají společnými body.

Výrobce kabelu 70557 dokumentuje napájení 70550 z nominální **12V automobilové nebo ohradníkové baterie**. Použití se stabilizovaným izolovaným výstupem DDR‑60G‑12 je zvolený projektový způsob. Kompatibilitu konkrétního Kerbl a způsob připojení potvrď u výrobce. Před připojením změř správných 12 V a polaritu podle skutečného konektoru a kabelu. **AA v této konfiguraci nevkládej.** Při servisním zásahu nejprve mechanicky zajisti panel, odpoj a ověř beznapěťový stav všech skutečných zdrojů Kerbl. F9 vyjmi až po odpojení napětí, pokud držák není výslovně určen k odpojování pod zátěží. Při jiné konfiguraci zkontroluj i případné vložené AA.

Zapni a ověř AUTO přímo na Kerblu s vlastními hodinami. Externí povel vede do MANUAL. Zapnuté AC ON podle výrobce obnoví AUTO při následujícím denním cyklu. Zpětná vazba GPIO18/19 blokuje jen povely ESP32, vlastní pohyb Kerbl nezastavuje.

### Relé povelů

Použij 2× Drátek **1517435132**, oba moduly v režimu **LOW**, s 5 V na jejich napájecích svorkách a společnou řídicí GND. Každý má jeden BC337‑40. Připoj GPIO25/26 přes 1 kΩ na bázi příslušného tranzistoru, bázi přes 10 kΩ na GND, emitor na GND, kolektor na IN relé a IN přes 10 kΩ k jeho +5 V. Ověř piny tranzistoru v dokumentaci konkrétního kusu. GPIO HIGH stáhne IN a sepne; bez povelu je modul rozepnutý.

| Od | Kam |
| --- | --- |
| Kerbl V | K1 COM |
| Kerbl OPEN / UP | K1 NO |
| K1 NC | K2 COM |
| Kerbl CLOSE / DOWN | K2 NO |
| K2 NC | Nezapojit |

V ustáleném stavu má OPEN přednost. Přechodový souběh kontaktů, stavy při náběhu, přerušení 5 V a opakovanou spolehlivost malého signálu potvrdí po montáži měření. Jednotku Kerbl při prvním měření odpoj od povelových svorek a vyluč přítomnost zvířat v dráze. Obnovení napájení ani odjištění spínačů samo o sobě nemá poslat povel.

## Signály ESP32

| GPIO | Funkce | Zapojení |
| --- | --- | --- |
| 4 | DS18B20 VEJCE a VODA | Třívodičově 3V3/GND/DQ. Jeden 4,7 kΩ pull-up DQ na 3V3. Obě role přiřadit v /sensors. |
| 13 / 14 | Místní OTEVŘÍT / ZAVŘÍT | Samostatné tlačítko NO mezi každým GPIO a GND. |
| 16 | Ohřev vajec | GPIO16 HIGH → SIG DFR0457 s 10 kΩ pull-down; řídicí VCC/GND podle označení modulu na straně ESP32. Výkonový GND na OUT− prvního 12V měniče. |
| 17 | Tepelná zpětná vazba | Samostatný bezpotenciálový NC kontakt mezi GPIO17 a GND. LOW = zdravá tepelná smyčka. Výkonových 12 V sem nesmí. |
| 18 / 19 | Servisní blokace / přístupná blokace povelů | Dva samostatné zlaté přepínače NKK MN12SD3G01, vývod COM na příslušný GPIO, kontakt sepnutý v PROVOZU na GND, druhý krajní vývod izolovat. Každý vstup u ESP32 přitáhnout 10 kΩ na 3V3, rozepnutí nebo přerušení vede na HIGH. |
| 21 / 22 | DS3231 SDA / SCL | Modul a pull-upy na 3V3, nenabíjecí držák CR2032. RTC uchovává UTC. |
| 23 | Kamera | GPIO23 → ON Pololu #2810 s 10 kΩ na GND. Vestavěný posuvník zůstává OFF. Společná GND pro Pololu, oba ESP32 a 5V měnič. |
| 25 / 26 | Budiče K1/K2 | Aktivní HIGH na straně ESP32. Viz reléové zapojení. |
| 27 | Alarm do RUT241 | GPIO27 přes 470 Ω na anodu LED PC817, katoda na GND ESP32. Na straně RUT241 kolektor na DI, emitor na GND routeru, podmíněný odpor 22 kΩ z DI na jeho +12 V. |
| 32 / 33 | OTEVŘENO / ZAVŘENO | Dva nezávislé NO kontakty na GND, LOW pouze při dosažené poloze. |
| 34 | Měření hlavní baterie | Jištěný kladný 24V rozvod → 120 kΩ 1 % → uzel GPIO34 → 10 kΩ 1 % → GND ESP32. U desky paralelně 100 nF z GPIO34 na GND. |
| 39 | Plovák vody | Snímač mezi GPIO39 a GND. Vlastní 10 kΩ pull-up na 3V3 u ESP32. Kontakt sepnutý pouze nad zvolenou prahovou hladinou. |

Při 21–30 V **na vstupu děliče** má být na odpojeném uzlu GPIO34 asi 1,62–2,31 V. Po montáži s multimetrem dolaď odhad v několika bodech, zvlášť kolem 25/26 V. Připojení napětí baterie přímo na GPIO34 poškodí ESP32. Samostatná 5V kamera ani 3,3V UART nesmí napájet spínanou větev zpětně. Při prvním programování odpoj externí přívod desky, pokud souběh s USB nedovoluje její konstrukce.

RUT241 vyžaduje naměřených 0–6 V pro LOW a 8 V až vlastní napájecí napětí pro HIGH. Při zdravém ESP32 má být LOW. Při alarmu či vypnutí pouze ESP32 má být HIGH. Ověř s připojeným vstupem a se skutečným 22 kΩ odporem; jeho hodnota je návrhová. Hardware RUT241 vyráběný od druhého čtvrtletí 2025 používá pro funkční I/O RutOS alespoň RUT2M_R_00.07.10.4.

### Plovák v napáječce

Předběžně vybraný model je vodorovný **Sensata/Cynergy3 RSF44Y100RF**, PP, těsnění NBR, 1m kabel, malý jazýčkový kontakt. U řady RSF40 lze pracovní polaritu otočit o 180°. Dokumentace verze RSF44 uvádí pro tuto vodní aplikaci schválení NSF a podle revize listu i WRAS nebo probíhající WRAS. Konkrétní certifikaci kusu a prostor ověř před objednáním. Montuj na vyjímatelný držák nebo vhodnou průchodnou stěnu monitorovaného dílu. Před případným vrtáním ověř výšku, volný zdvih, způsob čištění a těsnost. U samospádové napáječky neporuš vzduchotěsnost nádrže a neumísťuj snímač tak, aby omezil průtok nebo přístup slepic. Rozměry montáže přenes z výkresu výrobce na skutečnou napáječku.

Pro spojení GPIO39 smí plovák vést jen do signalizačního 3,3V okruhu. Vypni napájení a proměř kontakt při dostatku vody a pod nastavenou mezí. Instalace požaduje **sepnutý při dostatku**, rozepnutý při nízké hladině či poruše vodiče. Ověř hlášení po dvousekundovém zdržení a dostupnost nezamrzlé vody kontroluj osobně. Pokud RSF44Y100RF do té konkrétní nádoby rozměrově nevyjde, vyber před vrtáním jiný plovák s doloženými materiály a shodnou kontaktní logikou.

### Teplotní ochrany

Fólie Malapa TF1320 pracuje při jmenovitých 12 V / 20 W a výrobce uvádí maximum 14 V. Nenalepená může dosáhnout přibližně 82 °C při okolní teplotě 20 °C. Montuj ji na rovnou, očištěnou tepelně vodivou kovovou plochu po celé aktivní ploše, mimo dřevo, izolaci a přímý kontakt se zvířaty a vejci. Odveď teplo, chraň kabel a dodrž krytí skutečné sestavy.

EGG03 potřebuje NC termostat s doloženým vypínacím údajem alespoň 3 A při 12 V DC, EGG04 samostatnou jednorázovou DC tepelnou pojistku. Výrobce rodiny **Sensience MICROTEMP G4** uvádí 5 A při 24 V DC. Jde o doloženou kandidátní rodinu, nikoli zvolený otevírací teplotní stupeň pro tuto montáž. U obou prvků urči teplotu a polohu podle materiálů a tepelné cesty v hotové kazetě. Prověř samostatné odpojení nezávisle na GPIO, správný způsob montáže i nejteplejší bod. Stavový NC kontakt EGG05 je samostatný, elektricky oddělený od výkonového obvodu. Po montáži první kontrolu výkonu dělej s fyzicky odpojenou fólií a skutečný ohřev připoj po potvrzení těchto ochran. Firmware nevyžaduje přidání servisního softwarového zámku.

## Zdroje použitých údajů

- [Mean Well DDR‑60, parametry a teplotní derating](https://www.meanwell.com/Upload/PDF/DDR-60/DDR-60-SPEC.PDF)
- [Mean Well DDR‑30](https://www.meanwell.com/Upload/PDF/DDR-30/DDR-30-SPEC.PDF)
- [Victron 150/35, montáž](https://www.victronenergy.com/media/pg/Manual_SmartSolar_MPPT_150-35__150-45/en/installation.html)
- [Kerbl 70550, český návod](https://www.kerbl.co.uk/ftp/product-doc/215237.pdf) · [Kerbl 70557, výchozí 12V bateriové použití](https://www.kerbl.co.uk/ftp/product-doc/176617.pdf)
- [Drátek 1517435132, údaje relé](https://dratek.cz/docs/produkty/0/576/1517435132.pdf) · [Pololu #2810](https://www.pololu.com/product/2810)
- [Sensata RSF40, rozměry a seznam provedení](https://cynergy3.com/sites/default/files/sensata-level-rsf40-datasheet.pdf)
- [Malapa TF1320](https://malapa.cz/topne-folie-samolepici-silikonove/tf1320-topna-folie-silikon-12v-20w-lepici-200x50mm) · [Sensience MICROTEMP G4](https://www.sensience.com/products/microtemp-thermal-fuse-2/)
- [Teltonika RUT241, digitální vstup](https://wiki.teltonika-networks.com/view/RUT241_Input/Output) · [Teltonika RUT241, změny hardware](https://wiki.teltonika-networks.com/view/RUT241_Product_Change_Notifications)
