# Ověření REV26

## Překlad a testy

| Konfigurace | Cíl | Flash | Globální paměť |
| --- | --- | ---: | ---: |
| Řadič s výchozím nastavením pro první nahrání | ESP32 Dev Module | 804 082 B | 40 160 B |
| Zkušební překlad řadiče s povolenými relé, ohřevem, kalibrací a webovými povely | ESP32 Dev Module | 805 566 B | 40 160 B |
| Kamera HCC_CAM_REV11 | AI Thinker ESP32-CAM | 871 486 B | 43 644 B |

Překlad proběhl na Linuxu v Arduino CLI 1.6.0 s ESP32 core 1.0.6, OneWire 2.3.8 a DallasTemperature 3.9.0. Obě konfigurace řadiče se sestavily. Distribuovaná konfigurace je pro první nahrání. Relé, topení, potvrzení kalibrace a vzdálené povely pohybu jsou vypnuté.

Prošlo všech devět kontrol C++ a zdrojových podmínek v `firmware/tests/run_tests.sh`. Ověřují mimo jiné návrat ohřevu až od 26,0 V i po restartu, nutnost kalibrace při ohřevu, filtr plováku, 31 kontrol DS3231 včetně čtení po zápisu a nezávislé časové okno kamery. Zápis záznamů alarmů do NVS probíhá po skončení krátkého povelu relé. Výpadek Wi-Fi se hlásí podle nakonfigurovaného SSID i při vypnutém webu.

## Přechod z REV25

- Kerbl napájí hlavní 24V baterie přes vyhrazený DDR‑60G‑12 na F10 a originální 70557/F9. F4 a F5 mají společný druhý DDR‑60G‑12. Firmware řídí MOSFET ohřevu. Údaj `kerbl_supply_priority` označuje projektové zapojení. Skutečné napětí F9 se měří při přejímce.
- Při zavádění povelů a ohřevu použij konfigurační přepínače a zkoušky v [instalačním návodu](REV26_NAVOD_INSTALACE_A_TESTY.md). Nastavení hodin, harmonogramů, navázaných teploměrů a historie používají dosavadní uložené klíče.
- Aktuální nákupní seznam, schéma, montážní PDF a Word odpovídají REV26. Kontroly po montáži jsou v [přejímacím protokolu](REV26_ZKUSEBNI_PROTOKOL.csv).

Fyzická sestava se přejímá na místě. Pro připojení Kerbl potvrď použití kabelu 70557 s regulovaným 12V zdrojem. Změř napájení při rozběhu, ověř odpojení F9, kalibraci, plovák, nezávislé tepelné ochrany a alarmy. Nastavení MPPT a výdrž baterie v zimě ověř podle [napájecího návodu](REV26_NAPAJENI_A_FVE.md).
