# Instalace firmwaru a přejímka

Přejímka proběhne po montáži, bez zvířat. Před výrobou ověř šablonu otvoru a umístění rozváděče. Před zapnutím ověř napájecí variantu, polaritu, jištění a vedení vodičů podle [elektrického zapojení](REV26_ZAPOJENI_A_BEZPECNOST.md). Kerbl se může po připojení F9 pohybovat podle vlastního programu.

## Překlad a první nahrání

1. Rozbal ZIP. Pro hlavní desku otevři `firmware/HCC_CONTROLLER_REV26/HCC_CONTROLLER_REV26.ino`. Ponech všechny hlavičky v téže složce. Pro kameru použij `firmware/HCC_CAM_REV11/HCC_CAM_REV11.ino`.
2. Pro hlavní desku vyber **ESP32 Dev Module**, pro kameru **AI Thinker ESP32-CAM**. Použij Espressif ESP32 core **1.0.6**, **OneWire 2.3.8** a **DallasTemperature 3.9.0**. Pro hlavní desku můžeš použít Arduino IDE 1.8.19. Překlad této revize byl ověřen přes Arduino CLI. V sériovém monitoru zvol 115200 Bd.
3. Nastav vlastní `secrets.h` řadiče a síťové údaje kamery. Přístupové údaje ponech v místní kopii. Nahrávej s odpojenými povelovými kontakty Kerbl a odpojenou fólií. Před prací u šoupátka fyzicky zajisti dvířka a vypni napájení Kerbl vhodným DC odpojovačem.
4. První nahrání proveď s hodnotou 0 u `HCC_KERBL_OUTPUTS_ENABLED`, `HCC_EGG_HEATER_OUTPUTS_ENABLED`, `HCC_ALLOW_WEB_KERBL_COMMANDS` a `HCC_BATTERY_ADC_CALIBRATED`. Na `/status` ověř `rev=26`. Kamera má samostatný spínač a své časové okno. Při nahrávání do kamery používej právě jeden zdroj 5 V a po nahrání odpoj USB–UART.
5. Web je dostupný po nastavení hesla přes lokální síť. Bez routeru lze použít `HCC-SERVICE-REV26` na adrese `http://192.168.4.1/`, pokud máš nastavená vlastní hesla pro web i servisní AP. Nastav a ověř RTC, přihlas Wi‑Fi stanici a vyzkoušej alarmy podle [síťového návodu](REV26_LTE_WIREGUARD_KAMERA.md).

```sh
arduino-cli compile --fqbn esp32:esp32:esp32 firmware/HCC_CONTROLLER_REV26
arduino-cli compile --fqbn esp32:esp32:esp32cam firmware/HCC_CAM_REV11
```

## Napájení Kerbl z hlavní baterie

1. Před připojením Kerbl potvrď použití kabelu 70557 s regulovaným zdrojem u výrobce. Na výstupu jeho samostatného měniče nastav a změř 12 V. Zkontroluj polaritu na přívodu originálního kabelu a původní pojistku F9. V zapojení REV26 jsou baterie AA vyjmuté.
2. Ověř F10 na 24V vstupu vlastního měniče Kerbl. RUT241 a ohřev mají svůj měnič přes F2. Potvrď napětí Kerbl při rozběhu dvířek i při souběžném zapnutí topení. Změř proud Kerbl v klidu a při chodu. Označ odpojovače a všechny napájecí větve.
3. Ověř chování dvířek po vypnutí ESP32 a při odpojení větve F4 postupem bez zkratu. Vlastní napájení Kerbl má zůstat aktivní, pokud je hlavní baterie a větev F10/F9 funkční. Pro údržbu izoluj napájení Kerbl vhodným DC odpojovačem a ověř nepřítomnost napájení. Pojistky vyjímej bez napětí, pokud jejich držák není výslovně určený pro odpojení zátěže. Při výpadku hlavní baterie obnov a ověř hodiny a režim Kerbl.

## Místní ovládání a dohled Kerbl

1. První skutečný cyklus ověř panelem Kerbl a podle výrobce nastav čas a AUTO. U dvířek není v dráze člověk ani zvíře. Poté ověř spínače GPIO32/33 v obou skutečných koncích a blokace GPIO18/19. Po obnově blokovacích smyček potvrď případnou poruchu při ověřené poloze v místním webu.
2. S kontakty Kerbl odpojenými povol `HCC_KERBL_OUTPUTS_ENABLED=1` a změř každý z obou krátkých povelů, přibližně 350 ms, a správný klidový stav obou relé při resetu. Poté připoj vyzkoušené povelové kontakty, prověř koncové potvrzení, nedojezd a elektromagnetickou odolnost čidel. Návod [pro režim Kerbl](REV26_KERBL_OVLADANI.md) vysvětluje, jak externí povel přepne Kerbl do MANUAL a jak se vrací AUTO. Webové pohybové povely povol jen jako zvláštní provozní volbu po úspěšné zkoušce AC ON.
3. Aktivuj dohled mezních časů až po sladění s reálným programem Kerbl. Ověř `OPEN_DEADLINE_MISSED` a `CLOSE_DEADLINE_MISSED` se skutečnými koncovými kontakty i po restartu. Dohled vydává alarm, pohyb přenechává Kerbl.

## Voda, ohřev a kamera

1. GPIO39 potřebuje externí 10 kΩ na 3,3 V a skutečný kontakt plováku. S dostatkem vody má být spojený s GND. Ověř nedostatek vody, přerušený vodič a krátký zákmit. Změna stavu se potvrdí po dvou sekundách souvislého stavu. Ve `/sensors` přiřaď obě sondy DS18B20 podle skutečného umístění. Ověř varování při teplotě vody nejvýše 3 °C, jeho uvolnění od 5 °C a fyzickou dostupnost nezamrzlé vody.
2. S odpojenou fólií zkalibruj měření baterie proti multimetru nejméně ve dvou bodech kolem 25,0 a 26,0 V. Dělič je 120 kΩ / 10 kΩ a na GPIO34 čekej přibližně 1,62–2,31 V při 21–30 V na straně baterie. Oprav faktor `HCC_BATTERY_ADC_CORRECTION`, pak nastav `HCC_BATTERY_ADC_CALIBRATED=1`. Bateriové napětí připojuj pouze na vstup děliče.
3. Teprve po přejímce samostatného NC termostatu a tepelné pojistky s doloženými DC parametry povol `HCC_EGG_HEATER_OUTPUTS_ENABLED=1`. Ohřev vyžaduje platné kalibrované napětí, platný čas, funkční čidlo a zdravou tepelnou smyčku. Ohřev se vypne pod 25,0 V a povolí od 26,0 V i po restartu. Ověř prahy a ztrátu čidla nejprve na výstupu s fólií odpojenou. Pak ověř skutečné teploty a nezávislé odpojení výkonu.
4. GPIO23 spíná 5 V přes Pololu #2810. Ve výchozím okně 07:00–16:00 ověř start, DHCP a aktuální snímek `/jpg`. Mimo okno, bez platného času a po výpadku ESP32 má 5V výstup kamery zhasnout. Změř skutečné napájení i při startu Wi‑Fi.
5. Projdi [nastavení FVE a zimní rezervu](REV26_NAPAJENI_A_FVE.md), LTE/VPN a SMS při ztrátě a obnově registrace. Několik dní provozuj sestavu bez slepic. Výsledky zapiš do [přejímacího protokolu](REV26_ZKUSEBNI_PROTOKOL.csv).
