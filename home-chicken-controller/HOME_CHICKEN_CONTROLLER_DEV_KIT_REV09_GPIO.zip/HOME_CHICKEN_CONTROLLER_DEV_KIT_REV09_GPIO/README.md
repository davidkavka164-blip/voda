# HOME CHICKEN CONTROLLER – DEV KIT REV09

Vydání s aktivními výstupy pro přejímací zkoušky pro ostrovní kurník pro 10 slepic na zahradě přibližně 500 m od domu. Cílem je ušetřit zbytečné cesty díky místní automatice dvířek, kontrole vajec a vzdálenému dohledu přes LTE/VPN. Dostupnost nezamrzlé vody a stav zvířat se kontrolují osobně.

## První spuštění

1. Přečti si `docs/INSTALACE_ARDUINO_REV09.md`. Nahraj řídicí program do samostatného ESP32 s odpojeným motorem a topením. Výstupy motoru a topení jsou ve zdrojovém kódu povolené. Skutečné sepnutí blokuje nepotvrzená kalibrace baterie a další ochrany.
2. Ověř místní web, RTC, koncové spínače a čidla. Přejímací návod je v `docs/NAVOD_ZKOUSEK_REV09.md` a pracovní schéma v `docs/ZAPOJENI_A_BEZPECNOST_REV09.md`.
3. Po ověření samostatných ochran zkoušej dvířka a topení odděleně. Pro vzdálený dohled ověř LTE, dostupný protějšek WireGuard a kameru. Před nákupem výkonových dílů změř sílu a dráhu zkušebních dvířek a zimní spotřebu sestavy.

## Obsah

- `firmware/` obsahuje REV09 pro ESP32 Dev Module a AI Thinker ESP32‑CAM.
- `components/`, `construction/` a `drawings/` obsahují pracovní podklady REV08 pro navržené zapojení a rovný terén. Motor, baterie a výkonové ochrany vyžadují ověření.
- `REFERENCE/` obsahuje původní archiv REV08 včetně starších revizí a souvisejících podkladů. Aktuální postupy pro firmware jsou v tomto vydání v `docs/`.
- `docs/KONTROLA_REV09.md` uvádí zkoušky a zbývající podmínky provozu.

Firmware předpokládá stejné desky a piny jako REV08, časové pásmo Europe/Prague a provoz v LAN nebo přes VPN. Rozměry pozemku, zimní stínění, místní zátěže stavby, skutečné komponenty a dostupnost VPN uzlu čekají na ověření.
