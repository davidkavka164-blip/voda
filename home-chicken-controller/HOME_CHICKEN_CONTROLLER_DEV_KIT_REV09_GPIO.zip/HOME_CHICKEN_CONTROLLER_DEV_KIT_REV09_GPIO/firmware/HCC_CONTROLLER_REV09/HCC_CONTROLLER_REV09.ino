// HCC REV09 | ESP32 core 1.0.6 | commissioning build, LAN/VPN only.
#include <Arduino.h>
#include <string.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <time.h>
#include <sntp.h>
#include "config.h"
#include "secrets.h"
#include "door_safety.hpp"
#include "policy.hpp"
#include "rtc_ds3231.hpp"

static WebServer web(80);
static Preferences prefs;
static OneWire oneWire(PIN_ONEWIRE);
static DallasTemperature temperatures(&oneWire);
static hcc::DoorController door(HCC_MOTOR_TIMEOUT_MS,80,1800);
static hcc7::EggHeaterPolicy heater;
static hcc::DoorOutput lastDoor={hcc::DoorState::UNKNOWN,hcc::DoorFault::NONE,false,false,false};
static hcc::DoorCommand pending=hcc::DoorCommand::NONE;
static bool pendingAck=false, manualHold=false, webConfigured=false;
static bool heaterOutput=false, batteryOk=false, eggTempOk=false, waterTempOk=false;
static bool alarmActive=true;
static bool motorDriverFault=false, motorOverCurrent=false;
static float motorCurrentA=0;
static uint8_t overcurrentConsecutive=0;
static bool batteryCalibrated=(HCC_BATTERY_ADC_CALIBRATED!=0);
static float batteryV=0, eggC=0, waterC=0;
static uint32_t lastDoorTime=0,lastTempReq=0,lastBattery=0,lastWifi=0;
static bool tempPending=false, ntpStarted=false, rtcBackupPending=false;
static const char LOCAL_TZ[]="CET-1CEST,M3.5.0/2,M10.5.0/3";
static uint32_t lastRtcBackupAttempt=0;
static uint16_t openMin=HCC_OPEN_TIME_DEFAULT,closeMin=HCC_CLOSE_TIME_DEFAULT;
static uint16_t eggStart=HCC_EGG_START_DEFAULT,eggEnd=HCC_EGG_END_DEFAULT;
static uint32_t manualHoldDay=0;
static uint32_t csrf=0;
static String events[16];
static unsigned eventPtr=0;
static bool buttonOpenPrev=false,buttonClosePrev=false;
static unsigned char eggRom[8]={0}, waterRom[8]={0};

static void record(const String& s) { events[eventPtr++%16]=String(millis()/1000)+"s "+s; Serial.println(s); }
static bool authenticated(){
  if(web.authenticate(HCC_WEB_USER,HCC_WEB_PASS)) return true;
  web.requestAuthentication();return false;
}
static bool formAuthorized(){return web.hasArg("token") && web.arg("token")==String(csrf,HEX);}
static void moveOutputs(bool open,bool close){
  // Only 1 direction at once. PWM=0 is motor stop. Hardware normally-open
  // power contactor + E-STOP must separately cut 24V motor supply.
  const bool mayMove=(HCC_ACTUATORS_ARMED!=0)&&batteryOk;
  if(!mayMove || (open&&close)) {ledcWrite(0,0);return;}
  digitalWrite(PIN_MOTOR_DIR,open?HIGH:LOW);
  ledcWrite(0,(open||close)?HCC_MOTOR_PWM_DUTY:0);
}
static bool configuredRom(const unsigned char* rom){
  if(rom[0]!=0x28)return false;
  unsigned char r[8]; for(unsigned i=0;i<8;++i)r[i]=rom[i];
  return OneWire::crc8(r,7)==r[7];
}
static void sampleTemperature(){
  if(configuredRom(eggRom)) {
    float t=temperatures.getTempC(eggRom);
    eggTempOk=(t>-45 && t<85 && t!=85 && t!=DEVICE_DISCONNECTED_C);
    if(eggTempOk)eggC=t;
  }else eggTempOk=false;
  if(configuredRom(waterRom)){
    float t=temperatures.getTempC(waterRom);
    waterTempOk=(t>-45&&t<85&&t!=85&&t!=DEVICE_DISCONNECTED_C);
    if(waterTempOk)waterC=t;
  }else waterTempOk=false;
}
static void measureBattery(){
  uint32_t raw=0;for(int i=0;i<32;++i)raw+=analogRead(PIN_BAT_ADC);
  batteryV=((raw/32.0f)/4095.0f)*3.3f*HCC_BATTERY_DIVIDER_RATIO*HCC_BATTERY_ADC_CORRECTION;
  batteryOk=batteryCalibrated && hcc7::voltageValid(batteryV);
}
// Supplementary current monitor: NOT a physical force limiter. Pololu CS ~40mV/A
// with an offset. 0dB ADC nominal scale 0..1.1V; calibrate at site.
static void sampleMotorSafety(){
  motorDriverFault=(digitalRead(PIN_DRIVER_FAULT)==LOW);
  uint32_t raw=0;for(int k=0;k<8;++k)raw+=analogRead(PIN_MOTOR_CURRENT_ADC);
  const float volts=((raw/8.0f)/4095.0f)*1.10f;
  motorCurrentA=(volts-0.05f)/0.04f;
  if(motorCurrentA<0)motorCurrentA=0;
  // Do not evaluate stalled current when PWM is off or during start-up surge.
  const bool moving=lastDoor.motor_open || lastDoor.motor_close;
  if(!moving){overcurrentConsecutive=0;motorOverCurrent=false;return;}
  if(motorCurrentA>HCC_MOTOR_CURRENT_CUTOFF_A) {
    if(overcurrentConsecutive<4)++overcurrentConsecutive;
  } else overcurrentConsecutive=0;
  motorOverCurrent=(overcurrentConsecutive>=3);
}
static void updateHeat(uint16_t minute,bool clockOk){
  hcc7::HeatInputs i={};
  i.installed=(HCC_EGG_HEATER_INSTALLED!=0);
  i.armed=(HCC_ACTUATORS_ARMED!=0);
  i.rtc_ok=clockOk;
  i.sensor_ok=eggTempOk;
  i.battery_ok=batteryOk&&hcc7::batteryCanHeat(batteryV);
  i.hard_thermal_ok=digitalRead(PIN_EGG_THERMAL_NC)==LOW;
  i.local_min=minute;i.start_min=eggStart;i.end_min=eggEnd;i.temp_c=eggC;
  heaterOutput=heater.tick(i);
  digitalWrite(PIN_EGG_HEATER,heaterOutput?HIGH:LOW);
}
static const char* yn(bool x){return x?"true":"false";}
static String statusJson(){
  uint16_t mi=0;uint32_t d=0;bool clockOk=hcc7::localClock(mi,d);
  String s="{\"project\":\"HCC\",\"rev\":9,\"armed\":";
  s+=yn(HCC_ACTUATORS_ARMED!=0);s+=",\"motor_web_enabled\":";
  s+=yn(HCC_ALLOW_WEB_MOTOR_COMMANDS!=0);s+=",\"door\":\"";
  s+=hcc::doorStateName(lastDoor.state);s+="\",\"fault\":\"";
  s+=hcc::doorFaultName(lastDoor.fault);s+="\",\"position_verified\":";
  s+=yn(lastDoor.position_valid);s+=",\"manual_hold\":";s+=yn(manualHold);
  s+=",\"clock_valid\":";s+=yn(clockOk);
  s+=",\"local_minute\":";s+=String(mi);
  s+=",\"battery_calibrated\":";s+=yn(batteryCalibrated);
  s+=",\"battery_voltage\":";s+=batteryOk?String(batteryV,2):"null";
  s+=",\"battery_voltage_estimate\":";s+=String(batteryV,2);
  s+=",\"battery_soc\":null"; // voltage is NOT % SOC for LiFePO4.
  s+=",\"egg_temp\":";s+=eggTempOk?String(eggC,1):"null";
  s+=",\"water_temp\":";s+=waterTempOk?String(waterC,1):"null";
  s+=",\"water_available_verified\":false";
  s+=",\"egg_heater_output\":";s+=yn(heaterOutput);
  s+=",\"water_heater_output\":false";
  s+=",\"motor_driver_fault\":";s+=yn(motorDriverFault);
  s+=",\"motor_current_a_approx\":";s+=String(motorCurrentA,2);
  s+=",\"egg_sensor_paired\":";s+=yn(configuredRom(eggRom));
  s+=",\"water_sensor_paired\":";s+=yn(configuredRom(waterRom));
  s+=",\"alarm_active\":";s+=yn(alarmActive);
  s+=",\"wifi_connected\":";s+=yn(WiFi.status()==WL_CONNECTED);
  s+=",\"wifi_ip\":\"";s+=WiFi.localIP().toString();s+="\"}";
  return s;
}
static String htmlHeader(const char* title){
  String s="<!doctype html><html lang='cs'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
  s+="<title>";s+=title;s+="</title><style>body{font:16px Arial,sans-serif;margin:25px auto;max-width:850px;padding:0 14px;line-height:1.5;color:#173035}table{border-collapse:collapse;width:100%}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:left}button{padding:10px;margin:5px}input{padding:8px;max-width:90px}.warn{padding:12px;background:#fff3dd;border-left:4px solid #bb8d00}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f0f3f3;padding:12px}a{margin-right:12px}</style>";
  return s;
}
static void indexPage(){
  if(!authenticated())return;
  String s=htmlHeader("HOME CHICKEN CONTROLLER");
  s+="<h2>HOME CHICKEN CONTROLLER / REV09</h2>";
  s+="<p class='warn'><b>PŘEDREALIZAČNÍ FIRMWARE.</b> Fyzické výstupy ";
  s+=(HCC_ACTUATORS_ARMED?"AKTIVNI GPIO: pohyb vyzaduje koncovy spinac, NC ochrany a napeti. Pred ostrym provozem nutna mechanicka bezpecnost.":"VYPNUTY.");
  s+=" Vodu ani stav slepic software nepotvrzuje. HTTP jen v lokální síti / VPN.</p>";
  s+="<pre id='st'>"+statusJson()+"</pre>";
  s+="<h3>Ruční příkazy</h3><form method='POST' action='/action'><input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  s+="<button name='do' value='open'>OTEVŘÍT</button><button name='do' value='close'>ZAVŘÍT</button>";
  s+="<button name='do' value='stop'>STOP</button><button name='do' value='ack'>Potvrdit poruchu</button>";
  s+="<button name='do' value='auto'>Zapnout AUTO</button></form>";
  s+="<p>Webove prikazy jsou povolene pouze v mistni siti / VPN. Při pohybu použij fyzický E-STOP. Web během jízdy neobsluhuje příkazy.</p>";
  s+="<h3>Časy (místní, Europe/Prague)</h3><form method='POST' action='/settings'><input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  s+="Otevření min.: <input name='open' type='number' min='0' max='1439' value='"+String(openMin)+"'> ";
  s+="Zavření min.: <input name='close' type='number' min='0' max='1439' value='"+String(closeMin)+"'> ";
  s+="Topení vajec od: <input name='heatstart' type='number' min='0' max='1439' value='"+String(eggStart)+"'> ";
  s+="do: <input name='heatend' type='number' min='0' max='1439' value='"+String(eggEnd)+"'> ";
  s+="<button>Uložit</button></form><p>Časy = počet minut po půlnoci, např. 450=07:30, 1080=18:00.</p>";
  s+="<p><a href='/status'>JSON /status</a><a href='/sensors'>Adresy čidel</a><a href='/events'>Události</a></p>";
  if(String(HCC_CAMERA_LOCAL_URL).length()>0){s+="<p>Kamera: <a href='"+String(HCC_CAMERA_LOCAL_URL)+"'>Fotografie vajec</a> (pouze přes LAN/VPN)</p>";}
  s+="<script>setInterval(()=>fetch('/status',{cache:'no-store'}).then(r=>r.json()).then(v=>{document.getElementById('st').textContent=JSON.stringify(v,null,2)}).catch(()=>{}),3000)</script></html>";
  web.sendHeader("Cache-Control","no-store"); web.send(200,"text/html; charset=utf-8",s);
}
static void statusPage(){if(!authenticated())return;web.sendHeader("Cache-Control","no-store");web.send(200,"application/json",statusJson());}
static void sensorsPage(){
  if(!authenticated())return;
  String s=htmlHeader("HCC senzory")+"<h3>Adresy DS18B20</h3><pre>";
  uint8_t addr[8];int n=temperatures.getDeviceCount();
  for(int i=0;i<n;++i) {
    if(!temperatures.getAddress(addr,i))continue;
    s+=String(i)+": {";
    for(int j=0;j<8;++j){if(j)s+=",";s+="0x";if(addr[j]<16)s+="0";s+=String(addr[j],HEX);}
    s+="}\n";
  }
  s+="</pre><p>Pořadí sond se může měnit; přiřazení se ukládá podle unikátní ROM adresy. Umístění před párováním ověř termometrem.</p>";
  s+="<form method='POST' action='/pair'><input type='hidden' name='token' value='"+String(csrf,HEX)+"'>";
  s+="Role: <select name='role'><option value='egg'>VEJCE</option><option value='water'>VODA</option></select>";
  s+="Index: <input name='index' type='number' min='0' max='9' required>";
  s+="<button>Spárovat čidlo</button></form><a href='/'>Zpět</a>";
  web.send(200,"text/html; charset=utf-8",s);
}
static void onPair(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  const String role=web.arg("role");
  const String ix=web.arg("index");
  if(ix.length()!=1 || ix[0]<'0' || ix[0]>'9'){
    web.send(400,"text/plain","Invalid sensor index");return;
  }
  uint8_t addr[8];
  if(!temperatures.getAddress(addr,ix[0]-'0') || !configuredRom(addr)){
    web.send(400,"text/plain","Sensor not found");return;
  }
  if(role=="egg"){
    if(memcmp(addr,waterRom,8)==0){web.send(409,"text/plain","Already assigned to water");return;}
    if(prefs.putBytes("eggrom",addr,8)!=8){web.send(500,"text/plain","Sensor pairing could not be saved");return;}
    memcpy(eggRom,addr,8);
    eggTempOk=false;
    record("Egg DS18B20 paired");
  }else if(role=="water"){
    if(memcmp(addr,eggRom,8)==0){web.send(409,"text/plain","Already assigned to egg");return;}
    if(prefs.putBytes("waterrom",addr,8)!=8){web.send(500,"text/plain","Sensor pairing could not be saved");return;}
    memcpy(waterRom,addr,8);
    waterTempOk=false;
    record("Water DS18B20 paired");
  }else {web.send(400,"text/plain","Invalid role");return;}
  web.sendHeader("Location","/sensors");web.send(303,"text/plain","Paired");
}
static void eventsPage(){if(!authenticated())return;String s="";for(int i=0;i<16;++i){const String& x=events[(eventPtr+i)%16];if(x.length())s+=x+"\n";}web.send(200,"text/plain; charset=utf-8",s);}
static void onSettings(){
  if(!authenticated())return;
  if(!formAuthorized()) {web.send(403,"text/plain","CSRF rejected");return;}
  if(!web.hasArg("open")||!web.hasArg("close")||!web.hasArg("heatstart")||!web.hasArg("heatend")) {web.send(400,"text/plain","Missing input");return;}
  int o=web.arg("open").toInt(),c=web.arg("close").toInt(),hs=web.arg("heatstart").toInt(),he=web.arg("heatend").toInt();
  if(o<0||o>=1440||c<0||c>=1440||o>=c||hs<0||hs>=1440||he<0||he>=1440||hs==he){web.send(400,"text/plain","Invalid timing");return;}
  openMin=o;closeMin=c;eggStart=hs;eggEnd=he;
  prefs.putUShort("open",openMin);prefs.putUShort("close",closeMin);
  prefs.putUShort("eggstart",eggStart);prefs.putUShort("eggend",eggEnd);
  record("Scheduling updated");web.sendHeader("Location","/");web.send(303,"text/plain", "Saved");
}
static void onAction(){
  if(!authenticated())return;
  if(!formAuthorized()){web.send(403,"text/plain","CSRF rejected");return;}
  String cmd=web.arg("do");
  uint16_t min=0;uint32_t key=0;const bool validTime=hcc7::localClock(min,key);
  if(cmd=="stop") {
    pending=hcc::DoorCommand::STOP;
    manualHold=true;
    manualHoldDay=0; // STOP stays active across midnight and restart.
    prefs.putUInt("holdDay",0);
    prefs.putBool("hold",true);
    record("Stop requested; AUTO suspended");
  }
  else if(cmd=="ack"){pendingAck=true;record("Fault ack requested");}
  else if(cmd=="auto"){manualHold=false;manualHoldDay=0;prefs.putBool("hold",false);record("AUTO enabled");}
  else if(cmd=="open"||cmd=="close"){
    if(!HCC_ALLOW_WEB_MOTOR_COMMANDS){web.send(403,"text/plain","Web commands disabled in config.h");return;}
    if(!validTime) {web.send(409,"text/plain","Clock invalid");return;}
    pending=(cmd=="open"?hcc::DoorCommand::OPEN:hcc::DoorCommand::CLOSE);
    manualHold=true;manualHoldDay=key;prefs.putBool("hold",true);prefs.putUInt("holdDay",key);
    record("Remote door command");
  }else{web.send(400,"text/plain","Unknown command");return;}
  web.sendHeader("Location","/");web.send(303,"text/plain","Requested");
}
static void tickDoor(uint32_t now,uint16_t minute,uint32_t key,bool clockOk){
  bool openButton=(digitalRead(PIN_LOCAL_OPEN)==LOW);
  bool closeButton=(digitalRead(PIN_LOCAL_CLOSE)==LOW);
  if(pending!=hcc::DoorCommand::STOP && openButton&&!buttonOpenPrev&&!closeButton){pending=hcc::DoorCommand::OPEN;manualHold=true;manualHoldDay=key;prefs.putBool("hold",true);prefs.putUInt("holdDay",key);record("Local OPEN");}
  if(pending!=hcc::DoorCommand::STOP && closeButton&&!buttonClosePrev&&!openButton){pending=hcc::DoorCommand::CLOSE;manualHold=true;manualHoldDay=key;prefs.putBool("hold",true);prefs.putUInt("holdDay",key);record("Local CLOSE");}
  buttonOpenPrev=openButton;buttonClosePrev=closeButton;
  if(clockOk && manualHold && manualHoldDay!=0 && manualHoldDay!=key){manualHold=false;manualHoldDay=0;prefs.putBool("hold",false);}
  if(clockOk && !manualHold && pending==hcc::DoorCommand::NONE){
    if(lastDoor.state==hcc::DoorState::CLOSED && hcc7::shouldScheduleOpen(minute,openMin,closeMin)) pending=hcc::DoorCommand::OPEN;
    if(lastDoor.state==hcc::DoorState::OPEN && hcc7::shouldScheduleClose(minute,openMin,closeMin)) pending=hcc::DoorCommand::CLOSE;
  }
  hcc::DoorInput x;
  x.raw_open=(digitalRead(PIN_LIMIT_OPEN)==LOW);
  x.raw_closed=(digitalRead(PIN_LIMIT_CLOSED)==LOW);
  x.hard_stop=(digitalRead(PIN_ESTOP_NC)!=LOW);
  x.obstruction=(digitalRead(PIN_OBSTRUCTION_NC)==LOW); // NC edge SLP line: HIGH = healthy, LOW = pressed/wire break
  x.overcurrent=motorDriverFault || motorOverCurrent;
  x.power_ok=(HCC_ACTUATORS_ARMED==0) || (batteryOk && hcc7::batteryCanDrive(batteryV));
  x.movement_authorized=(HCC_ACTUATORS_ARMED!=0)&&x.power_ok&&!x.hard_stop&&!x.obstruction&&!x.overcurrent;
  x.acknowledge_fault=pendingAck;
  x.command=pending;
  x.now_ms=now;
  hcc::DoorState old=lastDoor.state;hcc::DoorFault oldFault=lastDoor.fault;
  lastDoor=door.tick(x);
  moveOutputs(lastDoor.motor_open,lastDoor.motor_close);
  if(old!=lastDoor.state || oldFault!=lastDoor.fault)
    record(String("Door ")+hcc::doorStateName(lastDoor.state)+" / "+hcc::doorFaultName(lastDoor.fault));
  pending=hcc::DoorCommand::NONE;pendingAck=false;
}
void setup(){
  pinMode(PIN_ALARM_HEALTHY,OUTPUT);digitalWrite(PIN_ALARM_HEALTHY,LOW);
  pinMode(PIN_MOTOR_DIR,OUTPUT);digitalWrite(PIN_MOTOR_DIR,LOW);
  pinMode(PIN_MOTOR_PWM,OUTPUT);digitalWrite(PIN_MOTOR_PWM,LOW);
  pinMode(PIN_EGG_HEATER,OUTPUT);digitalWrite(PIN_EGG_HEATER,LOW);
  ledcSetup(0,1000,8);ledcAttachPin(PIN_MOTOR_PWM,0);ledcWrite(0,0);
  pinMode(PIN_LIMIT_OPEN,INPUT_PULLUP);pinMode(PIN_LIMIT_CLOSED,INPUT_PULLUP);
  pinMode(PIN_ESTOP_NC,INPUT_PULLUP);pinMode(PIN_OBSTRUCTION_NC,INPUT);
  pinMode(PIN_DRIVER_FAULT,INPUT_PULLUP);pinMode(PIN_LOCAL_OPEN,INPUT_PULLUP);
  pinMode(PIN_LOCAL_CLOSE,INPUT_PULLUP);pinMode(PIN_EGG_THERMAL_NC,INPUT_PULLUP);
  buttonOpenPrev=digitalRead(PIN_LOCAL_OPEN)==LOW;
  buttonClosePrev=digitalRead(PIN_LOCAL_CLOSE)==LOW;
  pinMode(PIN_WATER_LOW,INPUT); // external pull-up required if used
  analogReadResolution(12);analogSetPinAttenuation(PIN_BAT_ADC,ADC_11db);
  analogSetPinAttenuation(PIN_MOTOR_CURRENT_ADC,ADC_0db);
  Serial.begin(115200);delay(80);
  prefs.begin("hcc7",false);
  openMin=prefs.getUShort("open",HCC_OPEN_TIME_DEFAULT);
  closeMin=prefs.getUShort("close",HCC_CLOSE_TIME_DEFAULT);
  eggStart=prefs.getUShort("eggstart",HCC_EGG_START_DEFAULT);
  eggEnd=prefs.getUShort("eggend",HCC_EGG_END_DEFAULT);
  manualHold=prefs.getBool("hold",false);manualHoldDay=prefs.getUInt("holdDay",0);
  if(prefs.getBytesLength("eggrom")==8)prefs.getBytes("eggrom",eggRom,8);
  if(prefs.getBytesLength("waterrom")==8)prefs.getBytes("waterrom",waterRom,8);
  if(openMin>=closeMin || closeMin>=1440){openMin=HCC_OPEN_TIME_DEFAULT;closeMin=HCC_CLOSE_TIME_DEFAULT;}
  if(eggStart>=1440||eggEnd>=1440||eggStart==eggEnd){eggStart=HCC_EGG_START_DEFAULT;eggEnd=HCC_EGG_END_DEFAULT;}
  Wire.begin(PIN_RTC_SDA,PIN_RTC_SCL); Wire.setClock(100000);
  hcc7::restoreClockFromRtc();
  setenv("TZ",LOCAL_TZ,1);tzset();
  measureBattery();
  lastBattery=millis();
  temperatures.begin();temperatures.setResolution(11);temperatures.setWaitForConversion(false);
  temperatures.requestTemperatures();tempPending=true;lastTempReq=millis();
  csrf=esp_random();
  const bool serviceApConfigured=strlen(HCC_AP_PASS)>=8 &&
    strcmp(HCC_AP_PASS,"CHANGE_THIS_AP_PASSWORD")!=0;
  webConfigured=strlen(HCC_WEB_PASS)>=8 &&
    strcmp(HCC_WEB_PASS,"CHANGE_THIS_WEB_PASSWORD")!=0;
  const bool enableServiceAp=serviceApConfigured && webConfigured;
  WiFi.mode(enableServiceAp?WIFI_AP_STA:WIFI_STA);
  if(enableServiceAp)WiFi.softAP(HCC_AP_SSID,HCC_AP_PASS);
  if(strlen(HCC_WIFI_SSID)>0){WiFi.begin(HCC_WIFI_SSID,HCC_WIFI_PASS);}
  web.on("/",HTTP_GET,indexPage);
  web.on("/status",HTTP_GET,statusPage);
  web.on("/sensors",HTTP_GET,sensorsPage);
  web.on("/events",HTTP_GET,eventsPage);
  web.on("/pair",HTTP_POST,onPair);
  web.on("/action",HTTP_POST,onAction);
  web.on("/settings",HTTP_POST,onSettings);
  web.onNotFound([](){if(!authenticated())return;web.send(404,"text/plain","Not found");});
  if(webConfigured)web.begin();
  record(HCC_ACTUATORS_ARMED?"REV09 outputs enabled":"REV09 bench mode: outputs disabled");
  Serial.println(WiFi.softAPIP());
}
void loop(){
  const uint32_t now=millis();
  // Do not block loop with sensor conversion or LTE connectivity operations.
  if(tempPending && (uint32_t)(now-lastTempReq)>=400){sampleTemperature();tempPending=false;}
  if(!tempPending && (uint32_t)(now-lastTempReq)>=HCC_SENSOR_PERIOD_MS){temperatures.requestTemperatures();tempPending=true;lastTempReq=now;}
  if((uint32_t)(now-lastBattery)>=1000){lastBattery=now;measureBattery();}
  uint16_t minute=0;uint32_t dayKey=0;bool clockOk=hcc7::localClock(minute,dayKey);
  if((uint32_t)(now-lastDoorTime)>=25){
    lastDoorTime=now;sampleMotorSafety();tickDoor(now,minute,dayKey,clockOk);updateHeat(minute,clockOk);
    // HEALTHY optocoupler ON pulls the RUT241 input LOW; any alarm or power
    // loss turns it OFF -> input goes HIGH via external 22k/12V pullup.
    alarmActive=(lastDoor.state==hcc::DoorState::FAULT) ||
      ((uint32_t)now>120000 && !clockOk) ||
      ((uint32_t)now>120000 && lastDoor.state==hcc::DoorState::UNKNOWN) ||
      (HCC_BATTERY_ADC_CALIBRATED && (!batteryOk || batteryV<24.5f)) ||
      (HCC_EGG_HEATER_INSTALLED && !eggTempOk) || motorDriverFault || motorOverCurrent;
    digitalWrite(PIN_ALARM_HEALTHY,alarmActive?LOW:HIGH);
  }
  // Do not let the synchronous HTTP server postpone travel monitoring.
  // While travelling, use the independent physical E-STOP.
  const bool travelling=lastDoor.state==hcc::DoorState::OPENING ||
    lastDoor.state==hcc::DoorState::CLOSING;
  if(travelling){delay(1);return;}
  if(webConfigured)web.handleClient();

  if((uint32_t)(now-lastWifi)>=30000){
    lastWifi=now;
    if(strlen(HCC_WIFI_SSID)>0 && WiFi.status()!=WL_CONNECTED){WiFi.reconnect();}
  }
  if(!ntpStarted && WiFi.status()==WL_CONNECTED){
    configTzTime(LOCAL_TZ,"pool.ntp.org","time.google.com");
    ntpStarted=true;
  }
  if(ntpStarted && sntp_get_sync_status()==SNTP_SYNC_STATUS_COMPLETED){
    rtcBackupPending=true;
    lastRtcBackupAttempt=now-5000u;
  }
  if(rtcBackupPending && (uint32_t)(now-lastRtcBackupAttempt)>=5000u){
    lastRtcBackupAttempt=now;
    if(hcc7::systemTimeValid() && hcc7::writeDS3231Utc(time(nullptr))){
      rtcBackupPending=false;
      record("Confirmed NTP time saved to DS3231");
    }
  }
  delay(1);
}
