#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <sys/time.h>
#include <time.h>
namespace hcc7 {
inline uint8_t bcdToDec(uint8_t v) {return ((v >> 4)*10)+(v&15);}
inline uint8_t decToBcd(uint8_t v) {return (v/10)*16+(v%10);}
// UTC civil date to days since Unix epoch (Gregorian). 2000..2099.
inline int32_t civilDays(int y,unsigned m,unsigned d) {
  y -= m<=2; const int era=(y>=0?y:y-399)/400;
  const unsigned yoe=(unsigned)(y-era*400);
  const unsigned doy=(153*(m+(m>2?-3:9))+2)/5+d-1;
  const unsigned yoeYear=yoe*365+yoe/4-yoe/100+doy;
  return era*146097+(int)(yoeYear)-719468;
}
inline bool readDS3231Utc(time_t& out) {
  Wire.beginTransmission(0x68);Wire.write((uint8_t)0x0F);
  if(Wire.endTransmission(false)!=0 || Wire.requestFrom(0x68,1)!=1)return false;
  if(Wire.read() & 0x80) return false; // oscillator stop flag = invalid clock
  Wire.beginTransmission(0x68);Wire.write((uint8_t)0x00);
  if(Wire.endTransmission(false)!=0 || Wire.requestFrom(0x68,7)!=7)return false;
  uint8_t s=bcdToDec(Wire.read()&0x7f),mi=bcdToDec(Wire.read()&0x7f);
  uint8_t rawh=Wire.read(); if(rawh&0x40) return false; // require 24h mode
  uint8_t hh=bcdToDec(rawh&0x3f); Wire.read();
  uint8_t dd=bcdToDec(Wire.read()&0x3f),mm=bcdToDec(Wire.read()&0x1f);
  int yyyy=2000+bcdToDec(Wire.read());
  if(yyyy<2025||yyyy>2099||mm<1||mm>12||dd<1||dd>31||hh>23||mi>59||s>59)return false;
  out=(time_t)civilDays(yyyy,mm,dd)*86400+hh*3600+mi*60+s;
  return out>1760000000;
}
inline bool writeDS3231Utc(time_t epoch) {
  struct tm u; gmtime_r(&epoch,&u);
  if(u.tm_year<125||u.tm_year>199)return false;
  Wire.beginTransmission(0x68);Wire.write((uint8_t)0x00);
  Wire.write(decToBcd(u.tm_sec));Wire.write(decToBcd(u.tm_min));
  Wire.write(decToBcd(u.tm_hour));Wire.write(decToBcd(u.tm_wday+1));
  Wire.write(decToBcd(u.tm_mday));Wire.write(decToBcd(u.tm_mon+1));
  Wire.write(decToBcd(u.tm_year-100));
  if(Wire.endTransmission()!=0)return false;
  Wire.beginTransmission(0x68);Wire.write((uint8_t)0x0F);
  if(Wire.endTransmission(false)!=0 || Wire.requestFrom(0x68,1)!=1)return false;
  uint8_t status=Wire.read()&~0x80;
  Wire.beginTransmission(0x68);Wire.write((uint8_t)0x0F);Wire.write(status);
  return Wire.endTransmission()==0;
}
inline bool systemTimeValid(){return time(nullptr)>1760000000;}
inline void restoreClockFromRtc(){time_t utc; if(readDS3231Utc(utc)) {struct timeval tv={(long)utc,0};settimeofday(&tv,nullptr);} }
inline bool localClock(uint16_t& minute,uint32_t& dayKey){
  time_t raw=time(nullptr);if(raw<=1760000000) return false;
  struct tm local; if(!localtime_r(&raw,&local))return false;
  minute=(uint16_t)(60*local.tm_hour+local.tm_min);
  dayKey=(uint32_t)(local.tm_year+1900)*1000u+(uint32_t)local.tm_yday;
  return true;
}
}
