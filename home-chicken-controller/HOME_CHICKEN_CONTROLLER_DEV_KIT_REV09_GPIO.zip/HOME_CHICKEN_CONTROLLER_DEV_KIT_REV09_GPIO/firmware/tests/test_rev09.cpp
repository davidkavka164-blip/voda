#include <cassert>
#include <iostream>
#include <cstdint>
#include "../HCC_CONTROLLER_REV09/door_safety.hpp"
#include "../HCC_CONTROLLER_REV09/policy.hpp"
using namespace hcc;
using namespace hcc7;
int main(){
  long n=0;
  DoorController d(12000,80,1800);
  DoorInput x{};x.raw_closed=true;x.power_ok=true;x.movement_authorized=true;
  for(int t=0;t<300;t+=25){x.now_ms=t;d.tick(x);++n;}
  assert(d.result().state==DoorState::CLOSED);++n;
  x.command=DoorCommand::OPEN;x.now_ms=325;
  auto r=d.tick(x); assert(r.motor_open && !r.motor_close);++n;
  x.command=DoorCommand::NONE;
  // Simulated NC edge trip: motor must be off immediately and fault retained.
  x.now_ms=350;x.obstruction=true;x.movement_authorized=false;r=d.tick(x);
  assert(r.state==DoorState::FAULT && r.fault==DoorFault::OBSTRUCTION && !r.motor_open && !r.motor_close);++n;
  x.obstruction=false;x.movement_authorized=true;x.acknowledge_fault=true;x.now_ms=375;
  r=d.tick(x);assert(r.state==DoorState::CLOSED && !r.motor_open);++n;
  // Battery disconnect during movement => latched failure
  x.acknowledge_fault=false;x.command=DoorCommand::OPEN;x.now_ms=400;r=d.tick(x);
  assert(r.motor_open);++n;
  x.command=DoorCommand::NONE;x.power_ok=false;x.now_ms=425;r=d.tick(x);
  assert(r.state==DoorState::FAULT && r.fault==DoorFault::POWER_INVALID && !r.motor_open);++n;
  // Conflict NC wiring: cannot recover
  x.power_ok=true;x.raw_open=true;x.now_ms=450;x.acknowledge_fault=true;
  r=d.tick(x);assert(r.state==DoorState::FAULT && !r.motor_open);++n;
  // Heating outside user window always OFF; thermostat hysteresis uses 2/5C
  EggHeaterPolicy heater;
  HeatInputs z{};z.installed=true;z.armed=true;z.rtc_ok=true;z.sensor_ok=true;
  z.battery_ok=true;z.hard_thermal_ok=true;z.start_min=420;z.end_min=960;z.temp_c=0;
  for(uint16_t m=0;m<1440;++m){
    z.local_min=m;
    bool heating=heater.tick(z);
    assert(heating==(m>=420 && m<960));++n;
  }
  z.local_min=600;z.temp_c=1;assert(heater.tick(z));++n;
  z.temp_c=3;assert(heater.tick(z));++n;
  z.temp_c=5;assert(!heater.tick(z));++n;
  z.temp_c=0;z.sensor_ok=false;assert(!heater.tick(z));++n;
  z.sensor_ok=true;z.battery_ok=false;assert(!heater.tick(z));++n;
  z.battery_ok=true;z.hard_thermal_ok=false;assert(!heater.tick(z));++n;
  std::cout<<"REV09 PASS: "<<n<<" deterministic safety+schedule checks\n";
}
