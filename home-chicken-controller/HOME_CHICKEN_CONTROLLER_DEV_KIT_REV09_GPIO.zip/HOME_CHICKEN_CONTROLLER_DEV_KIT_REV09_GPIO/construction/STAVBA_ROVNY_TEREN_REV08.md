# HOME CHICKEN CONTROLLER — STAVBA REV08 / ROVNÝ TERÉN

**Platné zadání:** pro 10 slepic; technický návrh na rovný terén, skutečnou polohu si zajistí uživatel. Půdorys **2400 × 2400 mm** (hrubých 5,76 m²), zvýšená podlaha **300–400 mm**, vstup pro člověka, tři hnízda, sběr vajec dostupný zvenku, technická skříň mimo vnitřní prostor slepic. Dvě PV 420 Wp mohou být na střeše nebo samostatně — kotvení ještě není povolené k výrobě.

## Rozmístění a pracovní rozměry
- Vnější stěny: pracovní světlá geometrie 2400×2400 mm; po opláštění upravit přesné velikosti otvorů.
- Podlaha: 20mm voděodolná překližka na nosnících, navrch vyjímatelná a omyvatelná povrchová vrstva; bez odkrytých spár a ostrých hran.
- Nosný rám: trámky 100×100 mm, pod ním **9 bodových podpor** (rastr 3×3) na rovném pevném podkladu; patky projektant upřesní podle podloží a zatížení.
- Hřady: dvě délky ~1500 mm mimo oblast hnízd a napáječky, s možností vyjmutí.
- Snášková hnízda: světlá šířka 3×360 mm, oddělení 4×20 mm -> 1160 mm bez dalšího opláštění; rozběhový sklon 12 % a 30 testů odvalování dle REV05.
- Sběrná kazeta: vnitřní délka ~1160 mm, dostupná výklopem zvenku. Izolaci 40mm testovat dle zimního tepelného modelu; nevyhřívat celý kurník.
- Předběžný průlez slepic 300×400 mm; konečné rozměry závisí na plemeni a dvířkovém mechanismu.
- Větrání: dvě nastavitelné chráněné větrací štěrbiny pod stříškou naproti sobě, s pletivem proti predátorům; nesmí vytvářet průvan v úrovni hřadů.
- Střecha: pultová s přesahy (pracovní footprint ~2900×2900 mm), minimální sklon dle zvolené krytiny. **Nosnost FVE, sněhu a větru nemáme staticky doloženou.**

## Materiál z vlastních zásob
Trámky 100×100 mm pro hlavní nosné prvky; desky 25 mm na opláštění; desky 50 mm na detaily; latě 60×40 mm na pomocné rámy; voděodolná překližka 20 mm na podlahu a hnízda. Používat pro návrh a inventuru REV06. **Zákaz finálního rozřezu nosných trámků**, dokud nejsou známy počty/délky a ověřena statika.

## Co lze připravit nyní a co vyžaduje terén
1. Lze vyrobit test jednoho hnízda, přístupový servisní panel, zkušební dvířka bez motoru.
2. Vyžaduje podklad: statické posouzení 9 patek/podlahy/střechy podle místního sněhu, větru a aktuálních rozměrů dřeva.
3. Vyžaduje podklad: výběr krytiny (úhel, přesahy, odvod vody), kotvení proti větru a ochrana proti predátorům.
4. Zahrada je umístěna podle uživatele a stavební režim konkrétního pozemku ověří uživatel.

**Tento dokument dokončuje dispoziční zadání pro rovný terén, neautorizuje statiku ani stavební povolení.**
