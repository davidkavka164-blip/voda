# HCC REV09 – elektrické zapojení podle návrhu REV08 (předrealizační)

## Tři DC napěťové úrovně
- **24V baterie** 25,6V LiFePO4 -> jištěný motor Pololu G2 24v13 (přímo; max 40V), hlavní MPPT. Nevystavovat motor ani pohon přebití.
- **12V regulované** Mean Well DDR-60G-12 -> RUT241 + 12V topná fólie Malapa TF1320 (20 W) přes tepelnou pojistku, teplotní NC spínač a DFRobot DFR0457 MOSFET. Pozor: 24V topná fólie TF1422 má max 27V a NENÍ vhodná pro přímé připojení na nabíjenou LiFePO4!
- **5V regulované** Mean Well DDR-30G-5 -> ESP32 DevKit a zvlášť jištěná ESP32-CAM, vstupy ESP32 max 3,3V.

## GPIO (ESP32 30pin)
|GPIO|Role|Signal|
|---:|---|---|
|32|Horní koncový spínač|Omron D2HW NO->GND, LOW = otevřeno|
|33|Spodní koncový spínač|Omron D2HW NO->GND, LOW = zavřeno|
|18|E-STOP 2. NC kontakt|NC->GND, LOW = zdravé, HIGH = porucha|
|19|Snímek hardwarového SLP blokování|HIGH = kontakt bezpečnostní hrany a E-STOP v pořádku, LOW = porucha; **externí pulldown**|
|23|Pololu G2 /FLT|Open-drain ACTIVE LOW, ESP pullup 3.3V, LOW = chyba|
|25|Pololu G2 DIR|3.3V, směr|
|26|Pololu G2 PWM|LEDC 1kHz, OFF=0, 8bit|
|35|Pololu G2 CS|ADC_0db, ~40mV/A + offset, software monitor (nebezpečnostní certifikace)|
|13|Místní OPEN tlačítko|NO->GND|
|14|Místní CLOSE tlačítko|NO->GND|
|16|DFRobot DFR0457 SIG|3.3V HIGH = heater on, externí pulldown|
|17|NC 40C tepelný spínač stav|LOW = sepnuté; jeho výkonový kontakt musí být fyzicky v sérii s fólií|
|4|DS18B20 datová sběrnice|4k7 pullup na 3.3V, pojmenovat podle ROM webem /sensors|
|21/22|DS3231 I²C|3.3V SDA/SCL, nepoužívat 5V pullupy|
|34|Baterie ADC|100k/10k dělič 1%, 100nF k GND, kalibrovat|
|27|Alarm PC817|aktivní HIGH zdravé / LOW porucha; RUT digitální vstup 12V přes 22k pullup + optočlen|
|39|Voda LOW volitelné|externí pullup 10k ke 3.3V; ve firmware rezervováno|

## Klíčové fyzické bezpečnostní zapojení (Pololu G2 SLP)
ESP32 GPIO ***nesmí*** být jediný zdroj stopnutí. Aktivní LOW vstup **SLP** motorového driveru má externí pulldown 10k na GND. Z 3.3V vede přes proudově omezující ~1k, NC bezpečnostní hranu a 1. NC kontakt E-STOP napájecí signál k SLP. GPIO19 sleduje stejný uzel za kontakty: když je bezpečný, cca 3.0V; když NC vypne / vodič se přeruší, SLP cca 0V, driver vypne i kdyby ESP32 zůstal viset. Je nutné ověřit skutečné zapojení a logické prahy SLP podle konkrétního vydání Pololu #2992, nejlépe s odborníkem. Přívod výkonu motoru se navíc samostatně jistí a odpojuje. **Není to certifikovaný bezpečnostní obvod.** Dvířka musejí být mechanicky odlehčená a mít kluznou spojku/ruční otevření.

**Při startu i v této konfiguraci s povolenými výstupy:** GPIO26 PWM 0, GPIO16 topení LOW; pohyb vyžaduje známou koncovou polohu, platné napětí a bezpečné NC vstupy. Platné hodiny navíc vyžaduje automatika a případný webový povel. Neznámou pozici nelze automaticky doměřovat. Pro plný provoz je nutné fyzické měření bezpečnostních obvodů, kalibrace ADC a ověření odporu/teplot topné podložky.

## Topení
Malapa TF1320 při 12V 1,66A smí být lepena pouze na vhodnou kovovou teplovodnou plochu, bez přímého styku s dřevem/vejci a s tepelnou pojistkou. Její povrch bez odvodu tepla může být >80 °C. Datasheet termostatu KSD9700 často udává jen AC proud: vyžaduje ověření **DC jmenovitého proudu** při 12V/2A, jinak použít DC-rated alternativu. Neprovádět bez dozoru před fyzickým testem.

**DŮLEŽITÉ GPIO17:** výkonový NC termostat topení (12V okruh) a stavový NC kontakt GPIO17 (3,3V okruh) jsou **dva oddělené kontakty/dva termostaty**. Není přípustné přivést 12V topného okruhu na GPIO17.
