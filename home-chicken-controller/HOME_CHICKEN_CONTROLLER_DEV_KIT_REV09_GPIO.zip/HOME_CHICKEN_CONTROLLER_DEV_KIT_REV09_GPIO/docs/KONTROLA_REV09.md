# Ověření REV09

## Provedeno

- Ověřeny kontrolní součty vstupního REV08.
- Oba programy sestaveny a slinkovány na Linuxu pomocí Arduino CLI 1.6.0 a Espressif ESP32 core 1.0.6. Řídicí deska `esp32:esp32:esp32` používá 786 846 B flash. Kamera `esp32:esp32:esp32cam` používá 871 126 B flash.
- Použité externí knihovny jsou OneWire 2.3.8 a DallasTemperature 3.9.0.
- Test stavového automatu a topného režimu na počítači prošel 1 465 kontrolami s ASan a UBSan. Simulovaná ztráta bezpečnostní smyčky současně odebírá povolení pohybu a musí vyvolat specifickou poruchu OBSTRUCTION.
- Výkonové výstupy a regulace topení jsou povolené. Potvrzení kalibrace a vzdálené povely pohybu jsou vypnuté. Web a servisní AP vyžadují nastavená hesla. Čas do RTC se ukládá po potvrzené synchronizaci NTP s českým lokálním časem na uživatelském rozhraní.

## Zkoušky před nasazením

- Nahrání a zkouška na skutečných deskách včetně servisu z Windows, párování čidel, restartu po synchronizaci a odpojeném LTE a kalibrace napětí ve více bodech.
- Samostatné ověření ochrany dvířek proti přiskřípnutí, E‑STOP, ručního uvolnění a restartu mezi koncovými polohami. V klidu ověř, že webový STOP pozastaví AUTO i přes restart a půlnoc. Během jízdy používej nezávislý E‑STOP.
- Ověření samostatného tepelného odpojení při trvale sepnutém výstupu, teploty okolních povrchů a chování při odpojení sond.
- Měření zimního odběru a dobíjení, ověření VPN a SMS na místě, odvalování vajec a několikadenní provoz sestavy bez slepic. Ověř rozměry pozemku, kotvení a statiku se zohledněním místního větru a sněhu.
- Sériové logy a web mají omezenou historii v paměti. Při vícedenním zkušebním provozu zaznamenávej dostupnost a výsledky průběžně.

Sestavení a host test ověřují kód. Fyzické zkoušky, ověření statiky a uvedení kurníku do provozu zbývají.
