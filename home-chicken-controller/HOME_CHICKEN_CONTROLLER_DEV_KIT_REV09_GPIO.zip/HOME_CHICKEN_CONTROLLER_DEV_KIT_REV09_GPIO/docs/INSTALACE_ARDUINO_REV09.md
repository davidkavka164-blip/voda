# HCC REV09 – otevření v Arduino IDE 1.8.19 / ESP32 core 1.0.6

## Knihovny
V Arduino IDE v **Nástroje → Vývojová deska → ESP32 Dev Module** zvol instalovanou podporu **esp32 by Espressif Systems 1.0.6**. Do **Správce knihoven** přidej **OneWire 2.3.8** a **DallasTemperature 3.9.0**. `WiFi`, `WebServer`, `Wire`, `Preferences`, LEDC a `esp_camera.h` dodává jádro ESP32. Pro kameru vyber **AI Thinker ESP32-CAM**.

Rozbal archiv. V Arduino IDE otevři `firmware/HCC_CONTROLLER_REV09/HCC_CONTROLLER_REV09.ino`. Vedle `.ino` musí zůstat `config.h`, `secrets.h`, `door_safety.hpp`, `policy.hpp`, `rtc_ds3231.hpp`. Arduino IDE normálně ukáže **záložky** pro soubory místo celé složky; to je správně.

## Před zapnutím fyzických výstupů
1. Nejprve sestav program pro **samotný ESP32 bez připojeného motoru a topné fólie**. Uprav `secrets.h`: SSID domácího/route­rového Wi‑Fi, přístupové údaje a nové silné heslo servisního AP. Nepřipojuj webový server přímo do veřejného internetu.
2. Ověř web lokálně přes servisní AP `HCC-SERVICE-REV09`. Heslo určuje `HCC_AP_PASS` v `secrets.h`. Testovací stránka `/status` má přístup HTTP Basic (uživatel/heslo v `secrets.h`).
3. Připoj obě DS18B20 na 3,3 V, GPIO4 a pull-up 4k7; v `/sensors` spáruj skutečné ROM adresy. Pokud je čidlo nedostupné, topení má zůstat OFF.
4. Připoj DS3231 na SDA21/SCL22 a 3,3V pull-up. Zkontroluj čas Evropa/Praha a přechod zimního/letního času; RTC uchovává UTC.
5. Zkontroluj napěťový dělič na GPIO34 multimetrem, měření při různém napětí a korekci `HCC_BATTERY_ADC_CORRECTION`. Výchozí hodnota 1.000 není skutečná kalibrace.
6. Před motorovým testem připoj a **proměř** hardwarové E-STOP, bezpečnostní hranu, /SLP a skutečnou ochranu proti přiskřípnutí. Bez mechanické/elektrické ochrany dvířka nezkoušej na slepicích.
7. Zkontroluj **dva oddělené tepelné NC kontakty** – výkonový 12V a 3,3V stavový GPIO17. Dolož DC rating teplotní ochrany, tepelnou pojistku a kovovou roznášecí plochu. Bez toho topení nepřipojuj.

Tato konfigurace má v kódu povolený motor i topení. Při prvním nahrání oba fyzicky odpoj. Kalibraci děliče prováděj s odpojenými výkonovými zátěžemi. Položka `battery_voltage_estimate` zobrazuje odhad ještě před potvrzením kalibrace. Po porovnání s multimetrem ve více bodech a úpravě korekce můžeš potvrdit kalibraci nastavením `HCC_BATTERY_ADC_CALIBRATED=1`. Pro první výkonovou zkoušku připoj jen jednu zátěž a postupuj podle přejímacího návodu.

Servisní AP a web vyžadují nahrazení vzorových hesel. Při pohybu dvířek se HTTP požadavky odloží. Okamžité zastavení zajistí fyzický E‑STOP. Webový STOP v klidu pozastaví AUTO i přes půlnoc a restart. Obnovíš ho tlačítkem **Zapnout AUTO** nebo místním povelem, který nastaví běžný režim ručního pozastavení do dalšího dne.

## Kamera
Otevři **zvlášť** `firmware/HCC_CAM_REV09/HCC_CAM_REV09.ino` s volbou AI Thinker ESP32-CAM a vlastním `WiFi` SSID/heslem a HTTP Basic přístupem. Fotografie `/jpg` jsou dostupné pouze přes zabezpečenou LAN/VPN. Kamera má vlastní stabilní 5V větev.

## Mobilní přístup přes LTE
RUT241 pracuje jako Wi‑Fi přístupový bod a LTE router. **WireGuard ze vzdáleného telefonu obvykle potřebuje dosažitelný VPN uzel**, protože mobilní SIM bývá za CGNAT. Vhodná architektura je RUT241 jako odchozí VPN klient k dostupnému domácímu/routerovému serveru, nebo jinému zabezpečenému dostupnému uzlu. Dosažitelnost konkrétního domácího připojení a veřejné IP je nutné před instalací ověřit. Nikdy neotvírat ESP32 port 80 do veřejné sítě.

## Stav ověření
Oba programy sestaveny na Linuxu s Arduino CLI 1.6.0, ESP32 core 1.0.6 a výše uvedenými knihovnami. Na Windows a na fyzických deskách zbývá ověřit nahrání a chování sestavy.
